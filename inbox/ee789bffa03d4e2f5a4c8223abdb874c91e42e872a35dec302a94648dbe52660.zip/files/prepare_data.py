"""Extract numeric facts from the pinned public conductivity notebook.

Usage: python prepare_data.py /path/from/fetch/Conductivity.ipynb --out DIR
Does not execute or copy notebook code, prose, or images.
"""
import argparse,csv,hashlib,json
from pathlib import Path
EXPECTED='67b80936d0c6c22f2ab86734fe9537bb2a194ab83e894a4a719e9df53c1cd7ea'

def extract(path,out):
    raw=path.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=EXPECTED:raise ValueError('Source hash differs from pinned input')
    txt=''.join(json.loads(raw)['cells'][9]['source']);rows=[]
    for line in txt.splitlines():
        s=[x.strip() for x in line.strip('|').split('|')]
        if len(s)>9 and s[0] in ['Inner Compact','Spongiform','Outer Compact'] and s[3]=='Akhtari et al., 2002':
            rows.append(dict(tissue=s[0],conductivity_S_m=s[1],frequency_Hz=s[6],sample_key=s[7]+'_'+s[8]))
    out.mkdir(parents=True,exist_ok=True)
    with (out/'conductivity_rows.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    materials=[dict(id='dannhauer_reference',sigma=[.0064,.02865,.0064],origin='Dannhauer et al. 2011 Table I; assigned model values')]
    for sample in ['Female_17','Male_61','Male_75']:
      for freq in ['10','90']:
        vals=[next(float(r['conductivity_S_m']) for r in rows if r['sample_key']==sample and r['frequency_Hz']==freq and r['tissue']==t) for t in ['Inner Compact','Spongiform','Outer Compact']]
        materials.append(dict(id='catalog_'+sample.lower()+'_'+freq,sigma=vals,origin='McCann catalog Akhtari 2002 rows grouped by reported sample and frequency; geometry assigned'))
    (out/'materials.json').write_text(json.dumps(materials,indent=2)+'\n')
    print('Extracted',len(rows),'numeric rows and',len(materials),'assigned material sets')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('notebook',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args();extract(a.notebook,a.out)
