#!/usr/bin/env bash
set -euo pipefail
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1 MPLBACKEND=Agg
sci_source_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
sci_output_dir=${1:-$(mktemp -d /tmp/sci-skull-reproduction.XXXXXX)}
mkdir -p "$sci_output_dir"
/opt/sci/bin/python "$sci_source_dir/run.py" --out "$sci_output_dir"
/opt/sci/bin/python "$sci_source_dir/independent.py" --results "$sci_output_dir" --out "$sci_output_dir/independent.json"
/opt/sci/bin/python "$sci_source_dir/stress.py" --results "$sci_output_dir"
/opt/sci/bin/python "$sci_source_dir/compare.py" "$sci_output_dir"
