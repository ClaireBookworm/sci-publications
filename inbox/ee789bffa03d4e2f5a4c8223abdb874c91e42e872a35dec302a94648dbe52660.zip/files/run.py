"""Reproduce finite-electrode skull reduction benchmark, without network access."""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ[key]='1'
import argparse, csv, json, time, resource, sys, hashlib
from pathlib import Path
import numpy as np
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from skull import layers, reduce_skull, denominator, gains, harmonics, sensor_matrix, error_certificate

ROOT=Path(__file__).resolve().parent


def montage():
    data=np.genfromtxt(ROOT/'biosemi64.txt',dtype=None,encoding='utf8',skip_header=1)
    names=np.array([r[0] for r in data[:64]])
    theta=np.deg2rad([r[1] for r in data[:64]])
    phi=np.deg2rad([r[2] for r in data[:64]])
    xyz=np.c_[np.sin(theta)*np.cos(phi),np.sin(theta)*np.sin(phi),np.cos(theta)]
    return names,xyz


def fibonacci(n):
    z=1-2*(np.arange(n)+.5)/n
    p=np.arange(n)*np.pi*(3-np.sqrt(5))
    return np.c_[np.sqrt(1-z*z)*np.cos(p),np.sqrt(1-z*z)*np.sin(p),z]


def write_csv(path,rows):
    with path.open('w') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)


def main(out):
    t0=time.perf_counter(); out.mkdir(parents=True,exist_ok=True)
    mats=json.loads((ROOT/'materials.json').read_text())
    names,xyz=montage()
    Y,deg,orders=harmonics(xyz,20)
    ell=np.arange(1,41)
    modal=[]; stats=[]; example=None
    for material in mats:
      for t in [3.,5.,6.,12.]:
       for f in [.25,.5,.75]:
        for inner in [.2,.5,.8]:
         model=layers(material['sigma'],t,f,inner)
         dr=denominator(model,ell)
         gref=gains(model,np.arange(1,21))
         select=deg<=12
         A=sensor_matrix(Y[:,select],gref[deg[select]-1])
         norm=np.linalg.norm(A,2)
         for method in ['planar','spherical']:
          reduced=reduce_skull(model,method)
          ds=denominator(reduced,ell)
          rel=dr/ds-1
          gs=gains(reduced,np.arange(1,21))
          E=sensor_matrix(Y[:,select],(gs-gref)[deg[select]-1])
          cert,q,qn=error_certificate(A,E)
          row=dict(material=material['id'],thickness_mm=t,spongy_fraction=f,inner_fraction=inner,method=method,
                   modal_error_12=float(np.max(np.abs(rel[:12]))),modal_error_20=float(np.max(np.abs(rel[:20]))),
                   modal_error_40=float(np.max(np.abs(rel))),rank=cert['rank'],null_leakage=cert['null_leakage'],
                   operator_error=float(np.linalg.norm(E,2)/norm))
          for floor,cap in zip(cert['floors'],cert['caps']):row['cap_'+str(floor)]=cap
          stats.append(row)
          for l,e,r,s in zip(ell,rel,dr,ds):
           modal.append(dict(material=material['id'],thickness_mm=t,spongy_fraction=f,inner_fraction=inner,
                             method=method,degree=int(l),relative_error=float(e),reference_denominator=float(r),reduced_denominator=float(s)))
          if material['id']=='dannhauer_reference' and t==6 and f==.5 and inner==.5 and method=='planar':
           example=(A,E,q,qn,gref,gs,model,reduced)
    write_csv(out/'grid.csv',stats);write_csv(out/'modes.csv',modal)
    A,E,q,qn,gr,gs,model,reduced=example
    norm=np.linalg.norm(A,2)
    cert,_,_=error_certificate(A,E)
    # Construct nearby observable sources, with bounded unit source norm.
    U,s,Vh=np.linalg.svd(A,full_matrices=False)
    v=Vh[0]
    cancellation=[]
    for eps in [1.,.1,.01,.001,.0001,0.]:
        z=qn+eps*v;z/=np.linalg.norm(z)
        true=np.linalg.norm(A@z);err=np.linalg.norm(E@z)
        cancellation.append(dict(epsilon=eps,true_over_operator_norm=float(true/norm),
                                 error_over_operator_norm=float(err/norm),relative_sensor_error=float(err/true),
                                 source_norm=float(np.linalg.norm(z))))
    write_csv(out/'cancellation.csv',cancellation)
    # Bandwidth, source depth and layout falsification controls.
    controls=[]
    for layout,points in [('biosemi64',xyz),('fibonacci64',fibonacci(64)),('fibonacci128',fibonacci(128))]:
      YY,dd,_=harmonics(points,20)
      for depth in [.6,.8,.98]:
       gg=gains(model,np.arange(1,21),depth)
       hh=gains(reduced,np.arange(1,21),depth)
       for band in [4,7,8,12,20]:
        sel=dd<=band
        AA=sensor_matrix(YY[:,sel],gg[dd[sel]-1]);EE=sensor_matrix(YY[:,sel],(hh-gg)[dd[sel]-1])
        cc,_,_=error_certificate(AA,EE)
        controls.append(dict(layout=layout,source_fraction=depth,band=band,source_dimension=int(sel.sum()),
                             rank=cc['rank'],null_leakage=cc['null_leakage'],zero_floor_cap=cc['zero_floor_cap'],
                             cap_001=cc['caps'][2],modal_error=float(np.max(np.abs(hh[:band]/gg[:band]-1)))))
    write_csv(out/'controls.csv',controls)
    # Uniform layer and scalar gain controls distinguish generic rank from actual leakage.
    uniform=layers([.01,.01,.01])
    uniform_error=float(np.max(np.abs(denominator(uniform,ell)/denominator(reduce_skull(uniform,'planar'),ell)-1)))
    scalar,_,_=error_certificate(A,.02*A)
    witness_error=np.linalg.norm(E@q)/np.sqrt(np.linalg.norm(A@q)**2+(.01*norm)**2*np.linalg.norm(q)**2)
    summary=dict(heads=len(stats)//2,grid_rows=len(stats),modal_rows=len(modal),reference_example=cert,
                 witness_attainment=float(witness_error),
                 null_residual=float(np.linalg.norm(A@qn)/norm),null_error=float(np.linalg.norm(E@qn)/norm),
                 full_scalp_modal_error_12=float(np.max(np.abs(gs[:12]/gr[:12]-1))),
                 full_scalp_modal_error_20=float(np.max(np.abs(gs/gr-1))),
                 uniform_layer_relative_error=uniform_error,scalar_gain_control=scalar,
                 grid_cap_001_min=float(min(r['cap_0.01'] for r in stats)),
                 grid_cap_001_max=float(max(r['cap_0.01'] for r in stats)),
                 grid_null_leakage_min=float(min(r['null_leakage'] for r in stats)),
                 grid_null_leakage_max=float(max(r['null_leakage'] for r in stats)),
                 prediction_symmetric_5mm_error20=float(max(r['modal_error_20'] for r in stats if r['material']=='dannhauer_reference' and r['thickness_mm']==5 and r['inner_fraction']==.5 and r['method']=='planar')),
                 source_basis='Real orthonormal spherical harmonics l=1..K; radial moment per solid angle at r=source_fraction*78 mm',
                 memory_limit_GiB=3.,cpu_threads=1)
    np.savez_compressed(out/'witness.npz',A=A,E=E,q=q,qnull=qn,xyz=xyz,names=names,
                        degrees=deg[deg<=12],orders=orders[deg<=12],reference_gain=gr,reduced_gain=gs)
    plot(out,stats,controls,cancellation,gr,gs)
    summary['versions']=dict(python=sys.version.split()[0],numpy=np.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__)
    summary['wall_seconds']=time.perf_counter()-t0
    summary['peak_rss_MiB']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024
    summary['cpu_seconds']=resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    assert uniform_error<1e-12
    assert summary['null_residual']<1e-12 and summary['null_error']>1e-8
    assert abs(witness_error-cert['caps'][2])<1e-10
    assert scalar['null_leakage']<1e-12
    assert np.max(np.array(scalar['caps'])) <= .02000000001
    assert summary['peak_rss_MiB']<3072
    print(json.dumps({k:summary[k] for k in ['heads','reference_example','null_residual','null_error','full_scalp_modal_error_12','prediction_symmetric_5mm_error20','wall_seconds','peak_rss_MiB']},indent=2))


def plot(out,stats,controls,cancel,gr,gs):
    fig,axs=plt.subplots(2,2,figsize=(10,7),layout='constrained')
    a=axs[0,0]
    a.plot(np.arange(1,21),100*(gs/gr-1),marker='o',ms=3)
    a.set(xlabel='Spatial degree',ylabel='Modal error (%)',title='A. Whole scalp: same source')
    a.axhline(0,c='gray',lw=.5)
    a=axs[0,1]
    for band in [4,7,8,12,20]:
      cc=[c for c in controls if c['layout']=='biosemi64' and c['source_fraction']==.98 and c['band']==band][0]
      # Recompute curves only for the focal case.
      data=np.load(out/'witness.npz'); YY,dd,_=harmonics(data['xyz'],20);sel=dd<=band
      AA=sensor_matrix(YY[:,sel],gr[dd[sel]-1]);EE=sensor_matrix(YY[:,sel],(gs-gr)[dd[sel]-1])
      floors=np.logspace(-4,-.5,40);c,_,_=error_certificate(AA,EE,tuple(floors),None)
      a.loglog(floors,100*np.array(c['caps']),label=f'K={band}')
    a.set(xlabel='Source floor / operator norm',ylabel='Sharp error bound (%)',title='B. Finite sensors: source norm floor')
    a.legend(fontsize=8,ncol=2)
    a=axs[1,0]
    a.loglog([r['true_over_operator_norm'] for r in cancel[:-1]],
             [100*r['relative_sensor_error'] for r in cancel[:-1]],'o-')
    a.set(xlabel='True sensor RMS / operator norm',ylabel='Relative sensor error (%)',title='C. Unit source patterns near sensor silence')
    a=axs[1,1]
    for method,c in [('planar','C0'),('spherical','C1')]:
      rr=[r for r in stats if r['method']==method]
      a.scatter([100*r['modal_error_12'] for r in rr],[100*r['cap_0.01'] for r in rr],s=9,alpha=.6,label=method,c=c)
    a.set(xlabel='Whole-scalp modal bound (%)',ylabel='1% source-floor sensor bound (%)',title='D. 252 assigned heads, two reductions')
    a.legend(fontsize=8)
    fig.savefig(out/'results.png',dpi=160);plt.close(fig)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=ROOT/'results')
    main(p.parse_args().out)
