"""Radial resistive EEG solver. New implementation of established shell equations."""
import numpy as np
from scipy.special import sph_harm_y

BRAIN_RADIUS = 0.078
BRAIN_SIGMA = 0.33


def layers(skull_sigma, thickness_mm=6., spongy_fraction=.5, inner_fraction=.5):
    """Return (inner radius, outer radius, radial sigma, tangential sigma), SI."""
    t = thickness_mm / 1000
    d = t * spongy_fraction
    compact = t - d
    bounds = [.078, .080, .080 + compact*inner_fraction,
              .080 + compact*inner_fraction+d, .080+t, .085+t]
    sigmas = [1.79, *skull_sigma, .43]
    return [(a,b,s,s) for a,b,s in zip(bounds[:-1],bounds[1:],sigmas)]


def reduce_skull(model, method):
    """Planar or exact spherical radial-resistance averages. Tangential mean is planar."""
    bone = model[1:4]
    a, b = bone[0][0], bone[-1][1]
    t = b-a
    sr = t/sum((y-x)/r for x,y,r,_ in bone)
    if method == 'spherical':
        sr = (1/a-1/b)/sum((1/x-1/y)/r for x,y,r,_ in bone)
    elif method != 'planar':
        raise ValueError(method)
    st = sum((y-x)*s for x,y,_,s in bone)/t
    return [model[0], (a,b,sr,st), model[-1]]


def denominator(model, degrees):
    """Positive regular auxiliary field: v(rb)=1, F(rb)=sigma_b*rb*l.

    Returns F(R)/(sigma_b*rb). T=1/F(R) maps the fixed Wronskian source load
    to scalp potential. No source or sensor geometry enters this function.
    """
    ell = np.asarray(degrees, dtype=float)
    if np.any(ell < 1):
        raise ValueError('Degree zero is a reference and is excluded')
    v, flux = np.ones_like(ell), ell.copy()
    for a,b,sr,st in model:
        x, y = a/BRAIN_RADIUS, b/BRAIN_RADIUS
        p = (np.sqrt(1+4*ell*(ell+1)*st/sr)-1)/2
        z = flux/(sr/BRAIN_SIGMA*x)
        plus = ((p+1)*v+z)/(2*p+1)
        minus = (p*v-z)/(2*p+1)
        hp, hm = (y/x)**p, (y/x)**(-p-1)
        v = hp*plus + hm*minus
        flux = sr/BRAIN_SIGMA*y*(p*hp*plus-(p+1)*hm*minus)
    return flux


def gains(model, degrees, source_fraction=.98):
    """Radial dipole moment per unit solid angle, in real orthonormal harmonics.

    Physical gain: l*(r_source/rb)**(l-1)/(sigma_b*rb**2*denominator).
    """
    ell = np.asarray(degrees)
    return ell*source_fraction**(ell-1)/(BRAIN_SIGMA*BRAIN_RADIUS**2*denominator(model,ell))


def harmonics(xyz, max_degree):
    xyz = np.asarray(xyz)
    xyz = xyz/np.linalg.norm(xyz,axis=1)[:,None]
    theta = np.arccos(np.clip(xyz[:,2],-1,1))
    phi = np.arctan2(xyz[:,1],xyz[:,0])
    out, deg, orders = [], [], []
    for ell in range(1,max_degree+1):
        for m in range(-ell,ell+1):
            if m < 0:
                h = np.sqrt(2)*(-1.)**m*sph_harm_y(ell,-m,theta,phi).imag
            elif m > 0:
                h = np.sqrt(2)*(-1.)**m*sph_harm_y(ell,m,theta,phi).real
            else:
                h = sph_harm_y(ell,0,theta,phi).real
            out.append(h); deg.append(ell); orders.append(m)
    return np.array(out).T, np.array(deg), np.array(orders)


def sensor_matrix(Y, gain):
    """Mean reference and RMS sensor norm. Euclidean q norm is source L2 norm."""
    Y = Y-Y.mean(axis=0)
    return Y*gain[None,:]/np.sqrt(len(Y))


def error_certificate(A, E, floors=(.1,.03,.01,.003,.001), witness_floor=.01):
    """Sharp ||Eq|| / sqrt(||Aq||^2+(eta*||A||*||q||)^2).

    Uses complete right singular vectors, including null directions. Returns
    floor-normalized error and an attaining source. No normal matrix is formed.
    """
    U,s,Vh = np.linalg.svd(A,full_matrices=True)
    scale=s[0]
    rank=int(np.sum(s > 1e-12*scale))
    ss=np.zeros(A.shape[1]); ss[:len(s)]=s
    EV=E@Vh.T
    null=EV[:,rank:]
    leakage=np.linalg.norm(null,2)/scale if null.size else 0.
    caps=[]; witness=None
    for eta in floors:
        inv=1/np.sqrt(ss**2+(eta*scale)**2)
        C=EV*inv[None,:]
        if eta == witness_floor:
            _, se, ve = np.linalg.svd(C,full_matrices=False)
            q=Vh.T@(inv*ve[0]); q/=np.linalg.norm(q)
            witness=q
            cap=se[0]
        else:
            cap=np.linalg.norm(C,2)
        caps.append(float(cap))
    if rank == A.shape[1]:
        zero_cap=float(np.linalg.norm(EV/ss[None,:],2))
    else:
        zero_cap=None  # Infinite if nonzero leakage; no finite ratio is asserted.
    qnull=None
    if null.size:
        _,_,nv=np.linalg.svd(null,full_matrices=False)
        qnull=Vh[rank:].T@nv[0]
    return dict(rank=rank,source_dimension=A.shape[1],operator_norm=float(scale),
                null_leakage=float(leakage),zero_floor_cap=zero_cap,
                floors=list(floors),caps=caps), witness, qnull
