# Field model and sharp finite-sensor error rule

## Fixed physical problem

The brain is a uniform isotropic ball with radius rb=0.078 m and conductivity sb=0.33 S/m. All sources are inside that ball. Outside it, a 2-mm fluid shell, the skull, and a 5-mm scalp are concentric. Fluid conductivity is 1.79 S/m. Scalp conductivity is 0.43 S/m. The outer surface is insulated. Conductivity is real, positive and independent of time. Interfaces have no contact impedance. Skull anisotropy, when used, is diagonal in the local radial and tangential directions, with equal conductivities in both tangential directions.

This is a conduction model of EEG volume currents. It is not a calculation of propagating electromagnetic waves. It neglects displacement current, induction, dielectric dispersion, tissue anisotropy in the brain, openings in the skull, and anatomical variation along a shell.

For a source-free harmonic of degree l>=1, potential u and conductive derivative F obey

    F = r^2 sigma_r du/dr
    du/dr = F/(r^2 sigma_r)
    dF/dr = l(l+1) sigma_t u.

F has the opposite sign to outward physical current. A constant shell has independent solutions r^p and r^(-p-1), where p(p+1)=l(l+1) sigma_t/sigma_r. Continuity of u and F gives the exact shell transfer. `skull.denominator` propagates an auxiliary solution v(rb)=1 and Fv(rb)=sb rb l. Its final scaled derivative is d_l=Fv(R)/(sb rb).

The Wronskian W=u Fv-Fu v is constant outside the source. Since Fu(R)=0, u(R)=W/Fv(R). For a singular brain solution u=B(r/rb)^(-l-1) plus a regular solution, W=(2l+1) sb rb B. Thus u(R)=(2l+1)B/d_l. The independent interface solver imposes the singular coefficient B=1 and solves all boundary conditions at once. This supplies an independent computation of d_l.

A radial current dipole of moment p at r0 on the polar axis gives an infinite-medium degree-l singular coefficient p l r0^(l-1)/(4 pi sb rb^(l+1)). The spherical-harmonic addition theorem gives, for a radial moment density q per unit solid angle on radius r0, the scalp harmonic gain

    g_l = l (r0/rb)^(l-1)/(sb rb^2 d_l).

The real source harmonics are orthonormal under solid-angle integration. Therefore ||q||_2 is the L2 norm of this radial moment density. Sources have either sign. The source class is a smooth dipole sheet at a fixed radius; it is not a collection of independent cortical neurons. There is no degree-zero source in this study. Degree zero of voltage is an arbitrary reference. A source cutoff K is a physical restriction of the supplied benchmark, not a certified truncation of arbitrary human currents.

## Established skull reductions

For compact, spongy, compact layers with thicknesses t_i, radial conductivity uses either the planar harmonic mean

    sr_planar = sum(t_i)/sum(t_i/sigma_i)

or exact spherical radial resistance matching

    sr_spherical = (1/a-1/b)/sum[(1/a_i-1/b_i)/sigma_i].

Both use st=sum(t_i sigma_i)/sum(t_i). These are established averaging principles. The spherical version and its whole-scalp checks are especially close to SCI 012557da. They are baselines here, not new methods.

Let h_l be the reduced-model gain. On the complete scalp surface, Parseval's identity gives

    ||(H-G)q||_L2 / ||Gq||_L2 <= max_(1<=l<=K) |h_l/g_l-1|.

This is sharp: a single harmonic at the largest-error degree attains the bound. It applies to the same source q in both models, without a fitted source amplitude. It does not imply the same relative bound after sampling at a finite electrode array.

## Finite electrodes and cancellation

At N sensor directions, let Y contain the real harmonics. Let P=I-11^T/N implement the discrete mean reference. Define

    S=P Y/sqrt(N), A=S diag(g_l), E=S diag(h_l-g_l).

The Euclidean norm of Aq is sensor RMS voltage after the mean reference. In general S is not an isometry. A source can be silent at the sensors although its complete-scalp field is nonzero.

If there is a q0 with Aq0=0 but Eq0!=0, no finite constant c satisfies ||Eq||<=c||Aq|| for all sources. To prove the limit without division by zero, choose v with Av!=0, and put q_e=(q0+e v)/||q0+e v||. The sensor error tends to a nonzero value while the true sensor signal tends to zero as e tends to zero. Rank loss alone is insufficient: for E=cA, the error preserves every silent source and the relative error is |c|.

If ker(A) is contained in ker(E), the zero-floor bound is finite and equals ||E A^dagger|| on the observable source quotient. In particular, an injective A gives a finite bound. The code reports its value when A has full column rank. A null scalar in result JSON for other cases means that a finite value was not computed, not that rank counting alone proved infinity.

## A useful bound with an explicit source norm

For alpha>0, the sharp constant is

    C_alpha = sup_(q!=0) ||Eq|| / sqrt(||Aq||^2+alpha^2 ||q||^2)
            = || E (A^T A+alpha^2 I)^(-1/2) ||_2.

This is the largest generalized singular value. It follows by changing coordinates with the positive definite square root of A^T A+alpha^2 I. The code uses all right singular vectors of A and scales them by 1/sqrt(s_i^2+alpha^2); it does not form A^T A. The independent calculation solves the generalized symmetric eigenproblem for E^T E and A^T A+alpha^2 I. A right singular vector supplies an attaining source.

We report eta=alpha/||A||_2. Eta is dimensionless. It is a declared source penalty, not a measurement noise estimate. If ||q||<=Q and ||Aq||>=V, then

    ||Eq||/||Aq|| <= C_alpha sqrt[1+(alpha Q/V)^2].

Users need independent bounds Q and V to turn C_alpha into a relative measured-signal guarantee. A 15% floor-normalized bound is not itself a 15% relative voltage bound.

For unobserved source components the worst error grows at least as ||E P_null||/alpha. For every q in ker(A), the denominator is alpha||q||. At small alpha this term controls the benchmark. This explains why decreasing a source penalty can increase sensitivity to an otherwise small forward-model error.

All proofs above are finite-dimensional exact-arithmetic statements for the declared source band and fixed operators. The numerical values are checked floating-point evaluations, not interval-arithmetic certificates. The claimed existence of nonzero leakage is supported by independent operators, controls, explicit source vectors, and a leakage magnitude many orders above numerical residuals. No claim is made about source-location error or any particular inverse algorithm.
