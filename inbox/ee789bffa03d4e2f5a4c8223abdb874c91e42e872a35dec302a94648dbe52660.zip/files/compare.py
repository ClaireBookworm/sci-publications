"""Compare a fresh calculation with the bundled scientific results."""
import argparse,csv,json
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent

def main(fresh):
    report={}
    for file in ['grid.csv','modes.csv','controls.csv','cancellation.csv','position_stress.csv']:
      ref=list(csv.DictReader((ROOT/'results'/file).open()));got=list(csv.DictReader((fresh/file).open()))
      assert len(ref)==len(got),(file,len(ref),len(got))
      maximum=0.
      for a,b in zip(ref,got):
       assert a.keys()==b.keys()
       for key in a:
        # Relative error at exact sensor silence is undefined; compare its finite outputs instead.
        if key in ['relative_sensor_error','fixed_pattern_relative_error'] and (a.get('epsilon')=='0.0' or a.get('angle_SD_degrees')=='0.0'):continue
        try:
          x,y=float(a[key]),float(b[key])
          err=abs(x-y)/max(1.,abs(x))
          maximum=max(maximum,err)
        except ValueError:assert a[key]==b[key],(file,key)
      assert maximum<1e-8,(file,maximum)
      report[file]={'rows':len(ref),'max_difference_scaled_by_max_1_abs_reference':maximum,'tolerance':1e-8}
    print(json.dumps(report,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('fresh',type=Path);main(p.parse_args().fresh)
