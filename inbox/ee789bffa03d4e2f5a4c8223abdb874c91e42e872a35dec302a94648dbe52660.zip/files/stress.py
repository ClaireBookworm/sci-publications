"""Source and electrode perturbation controls for the stored cancellation pattern."""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
import csv,json,argparse
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from skull import harmonics,sensor_matrix,error_certificate
ROOT=Path(__file__).resolve().parent


def main(folder):
    d=np.load(folder/'witness.npz');q=d['qnull'];xyz=d['xyz'];gr=d['reference_gain'][:12];gs=d['reduced_gain'][:12]
    rng=np.random.default_rng(20261112);rows=[]
    for angle in [.0,.1,.5,1.,2.]:
      for repeat in range(10):
        v=rng.normal(size=xyz.shape);v-=np.sum(v*xyz,axis=1)[:,None]*xyz
        # Two independent tangential components each with this angular SD.
        points=xyz+np.deg2rad(angle)*v;points/=np.linalg.norm(points,axis=1)[:,None]
        Y,deg,_=harmonics(points,12)
        A=sensor_matrix(Y,gr[deg-1]);E=sensor_matrix(Y,(gs-gr)[deg-1]);norm=np.linalg.norm(A,2)
        true=np.linalg.norm(A@q)/norm;err=np.linalg.norm(E@q)/norm
        cert,_,_=error_certificate(A,E)
        rows.append(dict(angle_SD_degrees=angle,repeat=repeat,fixed_pattern_true=true,
                         fixed_pattern_error=err,fixed_pattern_relative_error=err/max(true,1e-300),
                         recomputed_cap_001=cert['caps'][2],recomputed_null_leakage=cert['null_leakage']))
    with (folder/'position_stress.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    # The source and field maps make the retained source class explicit.
    phi=np.linspace(-np.pi,np.pi,180);z=np.linspace(-.999,.999,90)
    xyz_grid=np.stack(np.broadcast_arrays(np.sqrt(1-z[:,None]**2)*np.cos(phi),np.sqrt(1-z[:,None]**2)*np.sin(phi),z[:,None]+0*phi),axis=-1).reshape(-1,3)
    Y,deg,_=harmonics(xyz_grid,12)
    vals=[Y@q,Y@(gr[deg-1]*q),Y@((gs-gr)[deg-1]*q)]
    fig,axs=plt.subplots(1,3,figsize=(12,3.5),layout='constrained')
    for ax,v,title in zip(axs,vals,['Radial source pattern','Reference scalp field','Change from skull reduction']):
        v=v.reshape(len(z),len(phi));cap=np.max(np.abs(v))
        im=ax.pcolormesh(np.rad2deg(phi),z,v/cap,cmap='RdBu_r',vmin=-1,vmax=1,shading='auto')
        ax.scatter(np.rad2deg(np.arctan2(xyz[:,1],xyz[:,0])),xyz[:,2],s=4,c='black')
        ax.set(xlabel='Azimuth (degrees)',ylabel='cos(polar angle)',title=title)
        ax.text(.02,.02,f'Panel peak: {cap:.4g}',transform=ax.transAxes,fontsize=8)
    fig.colorbar(im,ax=axs,shrink=.75,label='Value / panel peak');fig.savefig(folder/'witness.png',dpi=160);plt.close(fig)
    summary=[]
    for a in [.0,.1,.5,1.,2.]:
      rr=[r for r in rows if r['angle_SD_degrees']==a]
      summary.append(dict(angle_SD_degrees=a,
                          fixed_pattern_relative_error_range=[min(r['fixed_pattern_relative_error'] for r in rr),max(r['fixed_pattern_relative_error'] for r in rr)],
                          recomputed_cap_001_range=[min(r['recomputed_cap_001'] for r in rr),max(r['recomputed_cap_001'] for r in rr)]))
    (folder/'stress_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--results',type=Path,default=ROOT/'results');main(p.parse_args().results)
