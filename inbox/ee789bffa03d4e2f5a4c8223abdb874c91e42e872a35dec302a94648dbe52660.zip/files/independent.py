"""Independent field/interface and generalized-eigenvalue checks.

Does not import the primary field, harmonic, or certificate routines.
"""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ[key]='1'
import argparse, csv, json, time, resource
from pathlib import Path
import numpy as np
from scipy import linalg, special
from scipy.integrate import solve_ivp
import mne
from mne.bem import _fwd_eeg_get_multi_sphere_model_coeffs
ROOT=Path(__file__).resolve().parent
RB=.078; SB=.33


def make_model(sigma,t,f,inner):
    t=t/1000; d=t*f; c=t-d
    b=[RB,.080,.080+c*inner,.080+c*inner+d,.080+t,.085+t]
    return [(a,z,s,s) for a,z,s in zip(b[:-1],b[1:],[1.79,*sigma,.43])]


def reduce(model,method):
    a,b=model[1][0],model[3][1]
    radial=sum((y-x)/sr for x,y,sr,st in model[1:4])
    radial=(b-a)/radial
    if method=='spherical':
        radial=(1/a-1/b)/sum((1/x-1/y)/sr for x,y,sr,st in model[1:4])
    tangent=sum((y-x)*st for x,y,sr,st in model[1:4])/(b-a)
    return [model[0],(a,b,radial,tangent),model[-1]]


def interface(model,ell):
    n=1+2*len(model)
    M=np.zeros((n,n)); rhs=np.zeros(n)
    def basis(j,r):
        a,b,sr,st=model[j]
        p=(-1+np.sqrt(1+4*ell*(ell+1)*st/sr))/2
        u=np.array([(r/a)**p,(r/a)**(-p-1)])
        flux=sr/SB*(r/RB)*u*np.array([p,-p-1])
        return u,flux
    for j,(a,b,sr,st) in enumerate(model):
        u,F=basis(j,a)
        if j==0:
            M[0,0]=1; M[1,0]=ell
            rhs[0]=-1;rhs[1]=ell+1
        else:
            u0,F0=basis(j-1,a)
            M[2*j,1+2*(j-1):3+2*(j-1)]=u0
            M[2*j+1,1+2*(j-1):3+2*(j-1)]=F0
        M[2*j,1+2*j:3+2*j]=-u
        M[2*j+1,1+2*j:3+2*j]=-F
    u,F=basis(len(model)-1,model[-1][1])
    M[-1,-2:]=F
    c=np.linalg.solve(M,rhs)
    residual=np.linalg.norm(M@c-rhs)/(np.linalg.norm(M)*np.linalg.norm(c)+np.linalg.norm(rhs))
    scalp=u@c[-2:]
    return (2*ell+1)/scalp, residual


def integrate(model,ell):
    y=np.array([1.,float(ell)])
    for a,b,sr,st in model:
        def fun(x,y):
            return np.array([SB/(sr*x*x)*y[1],ell*(ell+1)*st/SB*y[0]])
        r=solve_ivp(fun,[a/RB,b/RB],y,method='DOP853',rtol=2e-12,atol=2e-13)
        assert r.success
        y=r.y[:,-1]
    return y[1]


def real_Y(xyz,K):
    z=xyz[:,2]/np.linalg.norm(xyz,axis=1)
    phi=np.arctan2(xyz[:,1],xyz[:,0]);YY=[];degrees=[]
    for ell in range(1,K+1):
      for m in range(-ell,ell+1):
        mm=abs(m)
        N=np.sqrt((2*ell+1)/(4*np.pi)*np.exp(special.gammaln(ell-mm+1)-special.gammaln(ell+mm+1)))
        h=N*special.lpmv(mm,ell,z)
        if m>0:h=h*np.sqrt(2)*(-1.)**m*np.cos(m*phi)
        if m<0:h=h*np.sqrt(2)*(-1.)**m*np.sin(mm*phi)
        YY.append(h);degrees.append(ell)
    return np.array(YY).T,np.array(degrees)


def run(result_dir,out):
    t0=time.perf_counter()
    mats={m['id']:m['sigma'] for m in json.loads((ROOT/'materials.json').read_text())}
    rows=list(csv.DictReader((result_dir/'modes.csv').open()))
    field_error=0.;resid=0.;reference_cache={};n=0
    for r in rows:
        key=(r['material'],float(r['thickness_mm']),float(r['spongy_fraction']),float(r['inner_fraction']),int(r['degree']))
        mat,t,f,i,ell=key
        model=make_model(mats[mat],t,f,i)
        if key not in reference_cache:
            d,rr=interface(model,ell)
            reference_cache[key]=d;resid=max(resid,rr)
        d=reference_cache[key]
        ds,rr=interface(reduce(model,r['method']),ell);resid=max(resid,rr)
        field_error=max(field_error,abs(d/float(r['reference_denominator'])-1),abs(ds/float(r['reduced_denominator'])-1))
        n+=2
    # MNE is an independently maintained isotropic harmonic series, not its dipole approximation.
    mne_error=0.
    for material in mats.values():
      model=make_model(material,6,.5,.5); R=model[-1][1]
      mm=dict(layers=[dict(rel_rad=RB/R,sigma=SB)]+[dict(rel_rad=b/R,sigma=sr) for a,b,sr,st in model])
      coeff=_fwd_eeg_get_multi_sphere_model_coeffs(mm,41)
      for ell,fn in enumerate(coeff,1):
        d,_=interface(model,ell)
        ours=ell*(.43/SB)*(R/RB)**(ell+1)/d
        mne_error=max(mne_error,abs(ours/fn-1))
    # Direct adaptive ODE checks anisotropic reductions including high degrees.
    ode_error=0.
    for sig in [mats['dannhauer_reference'],mats['catalog_female_17_10']]:
      for t in [3,12]:
       for method in ['planar','spherical']:
        model=reduce(make_model(sig,t,.75,.2),method)
        for ell in [1,4,12,20,40]:
          d,_=interface(model,ell)
          ode_error=max(ode_error,abs(integrate(model,ell)/d-1))
    data=np.load(result_dir/'witness.npz')
    Y,deg=real_Y(data['xyz'],12)
    model=make_model(mats['dannhauer_reference'],6,.5,.5);red=reduce(model,'planar')
    gains=[];gains_red=[]
    for ell in range(1,13):
        d,_=interface(model,ell);ds,_=interface(red,ell)
        gains.append(ell*.98**(ell-1)/(SB*RB**2*d));gains_red.append(ell*.98**(ell-1)/(SB*RB**2*ds))
    Y-=Y.mean(0)
    A=Y*np.array(gains)[deg-1]/8
    E=Y*(np.array(gains_red)-gains)[deg-1]/8
    matrix_error=max(np.linalg.norm(A-data['A'])/np.linalg.norm(A),np.linalg.norm(E-data['E'])/np.linalg.norm(E))
    summary=json.loads((result_dir/'summary.json').read_text());norm=np.linalg.norm(A,2)
    ge_errors=[];attainment=[]
    for eta,expected in zip(summary['reference_example']['floors'],summary['reference_example']['caps']):
        H=A.T@A+(eta*norm)**2*np.eye(A.shape[1])
        w,v=linalg.eigh(E.T@E,H,subset_by_index=[A.shape[1]-1,A.shape[1]-1],driver='gvx')
        bound=np.sqrt(w[0]);q=v[:,0]
        attained=np.linalg.norm(E@q)/np.sqrt(q@H@q)
        ge_errors.append(abs(bound/expected-1));attainment.append(abs(attained/bound-1))
    # Field nullspace leakage built afresh from interface equations and Legendre polynomials.
    _,s,Vh=np.linalg.svd(A,full_matrices=True);rank=int(np.sum(s>1e-12*s[0]))
    null=Vh[rank:].T
    _,sn,Vn=np.linalg.svd(E@null,full_matrices=False);qn=null@Vn[0]
    null_res=float(np.linalg.norm(A@qn)/norm);leak=float(np.linalg.norm(E@qn)/norm)
    # Independent montage comparison against the installed MNE data and reader.
    positions=mne.channels.make_standard_montage('biosemi64').get_positions()['ch_pos']
    coords=np.array([positions[str(name)] for name in data['names']]);coords/=np.linalg.norm(coords,axis=1)[:,None]
    montage_error=float(np.max(np.abs(coords-data['xyz'])))
    # Gauss-Legendre quadrature confirms orthogonality and whole-surface norm.
    z,w=np.polynomial.legendre.leggauss(30);phi=2*np.pi*np.arange(64)/64
    points=np.stack(np.broadcast_arrays(np.sqrt(1-z[:,None]**2)*np.cos(phi),np.sqrt(1-z[:,None]**2)*np.sin(phi),z[:,None]+0*phi),axis=-1).reshape(-1,3)
    YY,dd=real_Y(points,12)
    weights=np.repeat(w,64)*2*np.pi/64
    gram=YY.T@(weights[:,None]*YY)
    orth_error=float(np.linalg.norm(gram-np.eye(len(dd)),2))
    q=data['qnull'];u=YY@(np.array(gains)[dd-1]*q);du=YY@((np.array(gains_red)-gains)[dd-1]*q)
    scalp_error=float(np.sqrt(np.sum(weights*du**2)/np.sum(weights*u**2)))
    report=dict(interface_comparisons=n,max_interface_relative_error=field_error,max_interface_backward_residual=resid,
                mne_coefficients=280,max_mne_relative_error=mne_error,max_ode_relative_error=ode_error,
                max_sensor_matrix_relative_error=matrix_error,max_generalized_eigenvalue_relative_difference=max(ge_errors),
                max_independent_attainment_relative_error=max(attainment),independent_rank=rank,
                independent_null_residual=null_res,independent_null_leakage=leak,
                null_leakage_relative_difference=abs(leak/summary['null_error']-1),
                montage_max_coordinate_difference=montage_error,quadrature_orthogonality_error=orth_error,
                null_pattern_full_scalp_relative_error=scalp_error,
                wall_seconds=time.perf_counter()-t0,peak_rss_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
                cpu_seconds=resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,
                mne_version=mne.__version__,tolerances=dict(interface=1e-10,mne=1e-10,ode=1e-9,matrix=1e-10,generalized=1e-7,null_residual=1e-12,orthogonality=1e-10))
    out.write_text(json.dumps(report,indent=2)+'\n')
    assert field_error<1e-10 and resid<1e-12 and mne_error<1e-10 and ode_error<1e-9
    assert matrix_error<1e-10 and max(ge_errors)<1e-7 and null_res<1e-12
    assert montage_error<1e-12 and orth_error<1e-10
    assert scalp_error<summary['full_scalp_modal_error_12']+1e-12
    assert report['peak_rss_MiB']<3072
    print(json.dumps(report,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--results',type=Path,default=ROOT/'results');p.add_argument('--out',type=Path,default=ROOT/'results/independent.json')
    a=p.parse_args();run(a.results,a.out)
