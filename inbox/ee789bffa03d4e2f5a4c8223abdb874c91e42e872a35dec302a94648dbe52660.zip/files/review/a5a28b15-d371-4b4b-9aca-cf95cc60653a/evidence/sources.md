# External source verification record

Access date: 2026-11-12 UTC. This is a selective primary-source check, not a systematic novelty search. Only bibliographic and scientific content was used; opinions from reviews of other publications were not used to rate this draft.

1. [Dannhauer et al., 2011, DOI 10.1002/hbm.21114](https://pmc.ncbi.nlm.nih.gov/articles/PMC6869856/). The primary indexed Table I gives skin 0.43, compact bone 0.0064, spongy bone 0.02865 and brain 0.33 S/m, matching the central model. The indexed primary table was accessible in web search; the direct PMC page returned a browser challenge and the Jena-hosted PDF download timed out after 30 seconds. The numeric table, rather than the failed download, supports this check.

2. [Piastra et al., DOI 10.1002/hbm.25272](https://onlinelibrary.wiley.com/doi/10.1002/hbm.25272). Publisher full text Table 1, lines 244–252 in the browser extraction, gives CSF 1.79 S/m and attributes it to Baumann et al. (1997). This verifies the draft's conventional fluid input, not a measurement for its assigned geometry.

3. [Petrov, 2012, DOI 10.1103/PhysRevE.86.011917](https://journals.aps.org/pre/abstract/10.1103/PhysRevE.86.011917). Publisher abstract identifies the established anisotropic concentric-shell solution and replacement of layered skull by an anisotropic shell. No first-priority claim for shell theory is supported here.

4. [Zhou and van Oosterom, 1992, DOI 10.1109/10.121646](https://pubmed.ncbi.nlm.nih.gov/1612618/). Primary abstract describes stabilization of the anisotropic concentric-sphere calculation. Citation identity and relevance confirmed; no full equation-by-equation audit of this paper was performed.

5. [Sadleir and Argibay, 2007, DOI 10.1007/s10439-007-9343-5](https://pubmed.ncbi.nlm.nih.gov/17629793/). Primary abstract confirms layered-skull electrical modeling and limits of effective anisotropy. Full primary text was blocked by a browser challenge in PMC; abstract-level relevance was checked.

6. [Ahlfors et al., 2010, DOI 10.1002/hbm.20851](https://pmc.ncbi.nlm.nih.gov/articles/PMC2797557/). Primary article confirms cancellation for extended and distributed neural sources. It supplies context, not validation of the particular signed radial sheet selected here.

7. [Hansen, 1998, DOI 10.1137/1.9780898719697](https://epubs.siam.org/doi/abs/10.1137/1.9780898719697.bm). Publisher book metadata confirms title, author, 1998 edition and DOI. The sharp finite-dimensional norm identity was derived directly by the reviewer; a complete book inspection was not performed.

8. [Akhtari et al., 2002, DOI 10.1023/A:1014590923185](https://pubmed.ncbi.nlm.nih.gov/12002346/). Primary abstract reports layer ranges: spongiform 0.0162–0.0411, top compact 0.0054–0.0072, lower compact 0.0028–0.0102 S/m. It describes room-temperature four-electrode measurements, frequency dependence at 10–90 Hz and high-current non-ohmic effects. The catalog's 0.0122 S/m inner value exceeds the abstract range, as the draft discloses. Original full tables remain unverified.

9. [McCann et al. correction, DOI 10.1007/s10548-020-00807-z](https://link.springer.com/article/10.1007/s10548-020-00807-z). Publisher confirms the correction's identity and 19 November 2020 publication date. An [institutional copy](https://iris.uniroma1.it/retrieve/e383532d-82d3-15e8-e053-a505fe0a3de9/McCann_Correction%20to%3A%20Variation_2021.pdf), indexed in web search, explains exclusion of MREPT studies outside the review's frequency range and changed conductivity summaries. No corrected population mean is used by the draft.

10. [Conductivity catalog](https://github.com/Head-Conductivity/Human-Head-Conductivity), revision `b0a5c6a251c6b4a279dbd77a853825bb1272632a`. GitHub's pinned tree contains only Conductivity.ipynb and README.md; no license file. The repository attributes the dataset to McCann, Pisano and Beltrachini (2019), DOI 10.1007/s10548-019-00710-2. Raw notebook retrieval produced 4,320,849 bytes, SHA-256 `67b80936d0c6c22f2ab86734fe9537bb2a194ab83e894a4a719e9df53c1cd7ea`. Only the supplied extraction program was executed, via review-run; the notebook was never executed. Both extracted files are byte-identical to the frozen inputs. The full notebook is deliberately not redistributed with this evidence.

11. [MNE BioSemi layout, v1.10.2](https://raw.githubusercontent.com/mne-tools/mne-python/v1.10.2/mne/channels/data/montages/biosemi64.txt). Raw file has 710 bytes and SHA-256 `8bd39ec923854853c1d6830c46cd4942f700d90ba9112541e21e45ea2a6fd7af`, exactly matching the frozen layout. First 64 sites enter the calculation; three fiducials are excluded. [MNE's versioned license](https://raw.githubusercontent.com/mne-tools/mne-python/v1.10.2/LICENSE.txt) is byte-identical to the retained notice. See local upstream copies.

12. The four SCI references resolve through the official read-only CLI. Condensed read logs are `prior_012557da.json`, `prior_40fc3aea.json`, `prior_824384de.json` and `prior_87cfdbf6.json`. The CLI verified README, sci.json and LICENSE, with no complete supporting-bundle or timestamp verification. The two closest references explicitly limit their results to full-surface norms or single sources, and exclude finite-sensor cancellation. That supports the present draft's narrow distinction; it does not establish priority for the benchmark.

External retrieval commands used curl with `-L --fail --max-time 30 -sS` and an explicit output filename for the pinned notebook, montage and license. The pinned tree used GitHub's public `git/trees/b0a5c6a251c6b4a279dbd77a853825bb1272632a` endpoint. Bibliographic searches used the paper DOIs, titles, and the specific conductivity values; no systematic database search or full-table audit was claimed.
