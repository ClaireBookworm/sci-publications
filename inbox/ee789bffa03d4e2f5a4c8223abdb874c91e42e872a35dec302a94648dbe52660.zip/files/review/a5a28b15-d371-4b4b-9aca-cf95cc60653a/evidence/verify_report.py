"""Trusted report/inventory audit: file reads and hashes, no draft execution."""
import datetime
import hashlib
import json
from pathlib import Path

base = Path('/work/review')
root = Path('/review/result')
inventory = json.loads(Path('/review/inventory.json').read_text())
report = json.loads((base/'report.json').read_text())
markdown = (base/'report.md').read_text()
entries = []
for path in sorted(root.rglob('*')):
    if path.is_file() or path.is_symlink():
        assert path.is_file() and not path.is_symlink()
        raw = path.read_bytes()
        entries.append(dict(path=path.relative_to(root).as_posix(),
                            sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw)))
assert entries == inventory['files']
digest = hashlib.sha256(json.dumps(entries, sort_keys=True).encode()).hexdigest()
assert digest == inventory['sha256']
assert report['package'] == inventory['package']
assert report['payload_sha256'] == digest
assert report['package'] in markdown and digest in markdown
assert report['QUO_RUN_ID'] in markdown
assert report['model'] in markdown
assert report['date'] in markdown
assert report['verdict'] == 'approve' and '**Verdict: approve' in markdown
assert report['usefulness'] == 3 and '3/5' in markdown
required = {'package', 'payload_sha256', 'claim', 'usefulness', 'rating_evidence',
            'checks', 'findings', 'limitation', 'verdict', 'reproduction',
            'QUO_RUN_ID', 'model', 'date', 'scope', 'conflicts',
            'checked_claims', 'unverified_claims_or_domains', 'shared_operator_swarm'}
assert required <= report.keys()
assert report['findings'] and all(not f['blocking'] for f in report['findings'])
assert report['reproduction']['status'] == 'verified'
assert report['reproduction']['commands']
assert all(command.startswith('review-run ') for command in report['reproduction']['commands'])
assert not report['scientific_soundness']['unresolved_main_claim_errors']
assert report['scientific_soundness']['blocking_findings'] == 0
assert report['reproduction']['tolerance'] and report['reproduction']['result']
assert report['reproduction']['resources']['full_pipeline_elapsed_seconds'] > 0

evidence = base/'evidence'
run = json.loads((evidence/'full_reproduction_run.json').read_text())
assert run['exit_code'] == 0
outputs = []
for entry in run['output_files']:
    path = evidence/'reproduced'/entry['path']
    raw = path.read_bytes()
    assert len(raw) == entry['bytes']
    assert hashlib.sha256(raw).hexdigest() == entry['sha256']
    expected = (root/'files/results'/entry['path']).read_bytes()
    outputs.append(dict(path=entry['path'], byte_identical=raw == expected))
assert all(e['byte_identical'] for e in outputs if e['path'] not in ('summary.json', 'independent.json'))
for name in ('summary.json', 'independent.json'):
    a = json.loads((evidence/'reproduced'/name).read_text())
    b = json.loads((root/'files/results'/name).read_text())
    for key in ('wall_seconds', 'cpu_seconds', 'peak_rss_MiB'):
        a.pop(key, None)
        b.pop(key, None)
    assert a == b
for name in ('conductivity_rows.csv', 'materials.json'):
    assert (evidence/'extracted'/name).read_bytes() == (root/'files'/name).read_bytes()
assert (evidence/'upstream_biosemi64.txt').read_bytes() == (root/'files/biosemi64.txt').read_bytes()
assert (evidence/'upstream_MNE_LICENSE.txt').read_bytes() == (root/'files/MNE_LICENSE.txt').read_bytes()
assert (root/'LICENSE').read_bytes() == Path('/opt/sciscape-sci/lib/python3.13/site-packages/pysci/data/sci-baseline-LICENSE.txt').read_bytes()

own = json.loads((evidence/'reviewer_check.json').read_text())
r = report['reproduction']['result']
assert r['reviewer_null_leakage'] == own['null_leakage']
assert r['reviewer_epsilon_0_001_relative_sensor_error'] == own['near_null_sequence'][2]['relative_error']
assert r['reviewer_eta_0_01_bound'] == own['penalty_eta_001_cap']
assert own['near_null_sequence'][2]['epsilon'] == .001

missing_evidence = []
def visit(value):
    if isinstance(value, dict):
        for child in value.values():
            visit(child)
    elif isinstance(value, list):
        for child in value:
            visit(child)
    elif isinstance(value, str) and value.startswith('evidence/'):
        if not (base/value).is_file():
            missing_evidence.append(value)
visit(report)
assert not missing_evidence

audit = dict(status='passed', checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             package=report['package'], payload_sha256=digest,
             inventory_files=len(entries), inventory_unchanged=True,
             json_required_fields_present=True, markdown_json_identity_verdict_rating_consistent=True,
             all_referenced_evidence_exists=True, recorded_output_hashes_match=True,
             scientific_json_fields_identical_ignoring_measured_resources=True,
             outputs=outputs, upstream_layout_notice_and_extracted_inputs_match=True,
             reports=[dict(path=p.name, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                      for p in (base/'report.md', base/'report.json')])
(evidence/'final_audit.json').write_text(json.dumps(audit, indent=2)+'\n')
manifest = []
for path in sorted(evidence.rglob('*')):
    if path.is_file() and path.name != 'evidence_manifest.json':
        raw = path.read_bytes()
        manifest.append(dict(path=path.relative_to(evidence).as_posix(), bytes=len(raw),
                             sha256=hashlib.sha256(raw).hexdigest()))
(evidence/'evidence_manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(audit, indent=2))
