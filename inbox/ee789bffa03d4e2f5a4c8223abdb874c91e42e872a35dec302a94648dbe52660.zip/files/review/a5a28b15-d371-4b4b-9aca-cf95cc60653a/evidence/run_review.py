import datetime
import hashlib
import json
import os
import pathlib
import resource
import subprocess
import time

root = pathlib.Path('/work/reproduction')
out = root / 'full'
command = ['bash', '/review/result/files/reproduce.sh', str(out)]
start = datetime.datetime.now(datetime.timezone.utc)
before = resource.getrusage(resource.RUSAGE_CHILDREN)
t0 = time.perf_counter()
with (root / 'full_reproduction.log').open('w') as log:
    process = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
elapsed = time.perf_counter() - t0
after = resource.getrusage(resource.RUSAGE_CHILDREN)
record = {
    'command': ['review-run', '/opt/sci/bin/python', '/work/reproduction/run_review.py'],
    'child_command': command,
    'started_utc': start.isoformat(),
    'exit_code': process.returncode,
    'elapsed_seconds': elapsed,
    'cpu_user_seconds': after.ru_utime - before.ru_utime,
    'cpu_system_seconds': after.ru_stime - before.ru_stime,
    'peak_rss_KiB': after.ru_maxrss,
    'peak_rss_MiB': after.ru_maxrss / 1024,
    'rlimit_cpu': resource.getrlimit(resource.RLIMIT_CPU),
    'rlimit_as': resource.getrlimit(resource.RLIMIT_AS),
    'isolation': 'review-run: read-only frozen payload, no network, clean environment',
}
files = []
for path in sorted(out.rglob('*')):
    if path.is_file():
        raw = path.read_bytes()
        files.append({'path': str(path.relative_to(out)), 'bytes': len(raw),
                      'sha256': hashlib.sha256(raw).hexdigest()})
record['output_files'] = files
(root / 'full_reproduction_run.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
raise SystemExit(process.returncode)
