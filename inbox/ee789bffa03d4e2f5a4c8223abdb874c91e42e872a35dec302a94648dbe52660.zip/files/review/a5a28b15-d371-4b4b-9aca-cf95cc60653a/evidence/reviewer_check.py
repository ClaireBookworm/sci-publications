"""Reviewer-written check. No draft code is imported or executed here.

Integrate the physical outer Neumann solution inward (RK45), recover its
singular brain coefficient, and independently assemble finite sensor maps.
"""
import os
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
import csv
import json
import math
import pathlib
import resource
import time
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import eigh
from scipy.special import gammaln, lpmv

started = time.perf_counter()
root = pathlib.Path('/review/result/files')
rb, sigma_b = 0.078, 0.33
rtol, atol = 2e-11, 2e-13
tolerances = dict(gain_relative=2e-9, matrix_relative=2e-9,
                  central_absolute=2e-8, null_residual_relative=2e-10,
                  eigen_bound_absolute=2e-8, analytic_uniform_relative=2e-9)

def physical_gain(shells, ell, source_fraction=0.98):
    # u(R)=1, F(R)=0; f=F/(sigma_b*rb), x=r/rb.
    u_f = [1.0, 0.0]
    for a, b, sr, st in reversed(shells):
        def equation(x, y):
            return [sigma_b*y[1]/(sr*x*x), ell*(ell+1)*st*y[0]/sigma_b]
        solution = solve_ivp(equation, (b/rb, a/rb), u_f,
                             method='RK45', rtol=rtol, atol=atol)
        assert solution.success
        u_f = solution.y[:, -1]
    # B=(ell*u(rb)-f(rb))/(2*ell+1), with u(R)=1.
    denominator = ell*u_f[0] - u_f[1]
    return ell*source_fraction**(ell-1)/(sigma_b*rb*rb*denominator)

shells = [(.078, .080, 1.79, 1.79), (.080, .0815, .0064, .0064),
          (.0815, .0845, .02865, .02865), (.0845, .086, .0064, .0064),
          (.086, .091, .43, .43)]
thicknesses = np.array([.0015, .003, .0015])
conductivities = np.array([.0064, .02865, .0064])
sr = thicknesses.sum()/np.sum(thicknesses/conductivities)
st = np.sum(thicknesses*conductivities)/thicknesses.sum()
reduced = [shells[0], (.080, .086, sr, st), shells[-1]]
g = np.array([physical_gain(shells, ell) for ell in range(1, 13)])
h = np.array([physical_gain(reduced, ell) for ell in range(1, 13)])

rows = [line.split() for line in (root/'biosemi64.txt').read_text().splitlines()[1:65]]
theta = np.deg2rad([float(row[1]) for row in rows])
phi = np.deg2rad([float(row[2]) for row in rows])
xyz = np.column_stack((np.sin(theta)*np.cos(phi), np.sin(theta)*np.sin(phi), np.cos(theta)))
polar_z = xyz[:, 2]
azimuth = np.arctan2(xyz[:, 1], xyz[:, 0])
columns, degrees = [], []
for ell in range(1, 13):
    for order in range(-ell, ell+1):
        m = abs(order)
        norm = np.sqrt((2*ell+1)/(4*np.pi)*np.exp(gammaln(ell-m+1)-gammaln(ell+m+1)))
        y = norm*lpmv(m, ell, polar_z)
        if order < 0:
            y = y*np.sqrt(2)*(-1.0)**m*np.sin(m*azimuth)
        elif order > 0:
            y = y*np.sqrt(2)*(-1.0)**m*np.cos(m*azimuth)
        columns.append(y)
        degrees.append(ell)
Y = np.column_stack(columns)
degree = np.array(degrees)-1
S = (Y - Y.mean(axis=0))/8
A = S*g[degree]
E = S*(h-g)[degree]
frozen = np.load(root/'results/witness.npz', allow_pickle=False)
assert all(frozen[k].dtype.kind != 'O' for k in frozen.files)
gain_difference = max(np.max(np.abs(g/frozen['reference_gain'][:12]-1)),
                      np.max(np.abs(h/frozen['reduced_gain'][:12]-1)))
matrix_difference = max(np.linalg.norm(A-frozen['A'])/np.linalg.norm(A),
                        np.linalg.norm(E-frozen['E'])/np.linalg.norm(E))
assert gain_difference < tolerances['gain_relative']
assert matrix_difference < tolerances['matrix_relative']
U, singular, Vh = np.linalg.svd(A, full_matrices=True)
operator_norm = singular[0]
rank = int(np.sum(singular > 1e-12*operator_norm))
null = Vh[rank:].T
null_leakage = np.linalg.norm(E@null, 2)/operator_norm
q = frozen['qnull']
q_residual = np.linalg.norm(A@q)/operator_norm
q_error = np.linalg.norm(E@q)/operator_norm
whole_scalp = np.linalg.norm((h-g)[degree]*q)/np.linalg.norm(g[degree]*q)
H = A.T@A+(.01*operator_norm)**2*np.eye(A.shape[1])
eigenvalue, eigenvector = eigh(E.T@E, H, subset_by_index=[167, 167])
cap = float(np.sqrt(eigenvalue[-1]))
attained = float(np.linalg.norm(E@eigenvector[:, -1])/np.sqrt(eigenvector[:, -1]@H@eigenvector[:, -1]))
# Choose the exact same explicit perturbing source as the draft from its A.
v = np.linalg.svd(frozen['A'], full_matrices=False)[2][0]
sequence = []
for epsilon in (.1, .01, .001, .0001):
    qe = q + epsilon*v
    qe /= np.linalg.norm(qe)
    signal = np.linalg.norm(A@qe)/operator_norm
    error = np.linalg.norm(E@qe)/operator_norm
    sequence.append(dict(epsilon=epsilon, signal=signal, absolute_error=error,
                         relative_error=error/signal))
assert rank == 63
assert q_residual < tolerances['null_residual_relative']
assert abs(null_leakage-.0015178613192250582) < tolerances['central_absolute']
assert abs(whole_scalp-.003483893188554295) < tolerances['central_absolute']
assert abs(cap-.15191581569881435) < tolerances['eigen_bound_absolute']
assert abs(sequence[2]['relative_error']-1.5179622151930292) < tolerances['central_absolute']
assert abs(attained-cap) < tolerances['eigen_bound_absolute']

# Boundary case derived directly from an insulating homogeneous sphere:
# g_l = r0**(l-1)/(sigma*R**(l+1)). The source norm is per solid angle.
uniform_errors = []
R = .091
for ell in range(1, 41):
    actual = physical_gain([(rb, R, sigma_b, sigma_b)], ell)
    analytic = (.98*rb/R)**(ell-1)/(sigma_b*R*R)
    uniform_errors.append(abs(actual/analytic-1))
assert max(uniform_errors) < tolerances['analytic_uniform_relative']

# A scalar gain perturbation must preserve every null vector; its finite
# penalty bound is exactly c/sqrt(1+eta**2), even for rank-deficient A.
scalar_caps = []
for eta in (.1, .01, .001):
    Hs = A.T@A+(eta*operator_norm)**2*np.eye(A.shape[1])
    w = eigh((.02*A).T@(.02*A), Hs, subset_by_index=[167, 167], eigvals_only=True)
    actual = np.sqrt(w[-1])
    analytic = .02/np.sqrt(1+eta*eta)
    assert abs(actual-analytic) < 2e-10
    scalar_caps.append(dict(eta=eta, computed=float(actual), analytic=float(analytic)))

# One harmonic degree has one scalar relative gain error, so all within-
# degree cancellation survives the model change. Multiple degrees matter.
one_degree = degree == 11
A12, E12 = A[:, one_degree], E[:, one_degree]
single_degree_scalar_residual = np.linalg.norm(E12-(h[11]/g[11]-1)*A12)/np.linalg.norm(E12)
assert single_degree_scalar_residual < 1e-10

# Projection sensitivity: a residual can be removed with norm <= r/s_min.
# This is a floating-point stability diagnostic, not interval certification.
smallest_observable = singular[rank-1]/operator_norm
correction_norm_bound = q_residual/smallest_observable
leakage_correction_bound = np.linalg.norm(E, 2)/operator_norm*correction_norm_bound

random = np.random.default_rng(178924)
random_sources = random.normal(size=(168, 2000))
ratios = np.linalg.norm(E@random_sources, axis=0)/np.linalg.norm(A@random_sources, axis=0)

grid = list(csv.DictReader((root/'results/grid.csv').open()))
grid_results = {}
for method in ('planar', 'spherical'):
    values = [float(row['cap_0.01']) for row in grid if row['method'] == method]
    grid_results[method] = dict(rows=len(values), minimum=min(values), maximum=max(values),
                                count_over_005=sum(x>.05 for x in values))
assert grid_results['planar']['count_over_005'] == 227
assert grid_results['spherical']['count_over_005'] == 170

result = dict(
    status='verified', method='Reviewer-written inward Neumann RK45 solver and generalized eigenproblem; no draft imports',
    ode_rtol=rtol, ode_atol=atol, tolerances=tolerances,
    gain_max_relative_difference=float(gain_difference), matrix_max_relative_difference=float(matrix_difference),
    rank=rank, source_dimension=168, operator_norm=float(operator_norm),
    null_leakage=float(null_leakage), stored_witness_residual=float(q_residual),
    stored_witness_error=float(q_error), stored_witness_whole_scalp_error=float(whole_scalp),
    penalty_eta_001_cap=cap, independently_attained_cap=attained,
    near_null_sequence=sequence,
    homogeneous_sphere_analytic_max_relative_error=float(max(uniform_errors)),
    scalar_gain_analytic_controls=scalar_caps,
    single_degree_scalar_residual=float(single_degree_scalar_residual),
    smallest_observable_singular_relative=float(smallest_observable),
    null_projection_norm_correction_bound=float(correction_norm_bound),
    leakage_correction_upper_bound_relative_operator=float(leakage_correction_bound),
    random_source_control=dict(seed=178924, count=2000, distribution='iid normal harmonic coefficients; synthetic, not physiology',
                               median=float(np.median(ratios)), maximum=float(max(ratios)),
                               q95=float(np.quantile(ratios,.95))),
    grid_summary=grid_results, npz_members=[dict(name=k, dtype=str(frozen[k].dtype), shape=list(frozen[k].shape)) for k in frozen.files],
    wall_seconds=time.perf_counter()-started,
    peak_rss_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
    cpu_seconds=resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime)
pathlib.Path('/work/reproduction/reviewer_check.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
