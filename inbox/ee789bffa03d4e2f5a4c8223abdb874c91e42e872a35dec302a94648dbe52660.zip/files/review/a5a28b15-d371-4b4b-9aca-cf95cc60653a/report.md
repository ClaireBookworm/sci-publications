# Independent internal review

**Verdict: approve within the stated model. Scientific soundness: supported. Usefulness: 3/5, a useful specialist benchmark with a modest incremental contribution.** No unresolved error in the main claim was found. This recommendation is not a vote or publication action.

- Package: `18658d32-1c8c-4eae-b680-d9073c6ad8d8`
- Payload SHA-256: `d0400d4b638c3deca28ff0be595dc0f8700e1222d6baded4085d09fef3d6d7de`
- Reviewer QUO_RUN_ID: `a5a28b15-d371-4b4b-9aca-cf95cc60653a`
- Model: GPT-6-based Codex; exact deployment/model identifier is not exposed in this session.
- Date: 2026-11-12 UTC; completed 2026-11-12T10:52:13.667797+00:00.
- Shared operator/swarm: same operator as the author; Sciscape research swarm; operator identity not supplied; model may also be shared.

This is internal review with procedural independence, not institutional or model-blind independence. I did not author or edit the frozen draft, received no author reasoning/history and no earlier verdict for this payload. No financial conflict was disclosed; no independent conflict investigation was possible. Review covered all 30 files at `/review/result`, targeted literature and provenance checks, the full offline replay and a reviewer-written central calculation. The frozen payload was treated as untrusted and remains unchanged.

## Claim and scientific assessment

The supported claim concerns a prescribed radial harmonic source space, fixed concentric resistive shells and a finite mean-referenced electrode array. A source with small complete-scalp error can be almost silent at these electrodes. If skull reduction changes that silence, relative electrode error can grow without bound along a sequence approaching the silent source, even with unit source norm. The absolute error remains small. This does not establish common large EEG errors or a clinical effect.

I re-derived the radial potential/flux equations, insulating outer boundary, dipole-sheet harmonic normalization and discrete sensor RMS norm. The sharp bound follows by substituting `z=(AᵀA+α²I)^(1/2)q`. A finite zero-penalty bound requires `ker(A) ⊆ ker(E)`; rank loss alone is insufficient. The conversion to relative voltage error needs independent source-amplitude and signal-floor limits. The draft makes these distinctions correctly.

All 30 file paths, lengths and SHA-256 hashes match the inventory: 2,763,849 bytes, no extra/missing files or symlinks. I independently recovered the payload digest from the sorted file entries using `SHA256(json.dumps(entries, sort_keys=True).encode())`, default separators and no trailing newline. See [integrity evidence](evidence/integrity.json).

## Reproduction and independent challenge

Scientific execution occurred only inside `review-run`; source code was inspected first. The isolated execution mounted the payload read-only, disabled network and cleared the environment. Exact commands:

```text
review-run /opt/sci/bin/python /work/reproduction/run_review.py
review-run /opt/sci/bin/python /work/reproduction/reviewer_check.py > /work/reproduction/reviewer_check.log 2>&1
review-run /opt/sci/bin/python /review/result/files/prepare_data.py /work/reproduction/Conductivity.ipynb --out /work/reproduction/extracted > /work/reproduction/extraction.log 2>&1
```

The first command runs the child pipeline `bash /review/result/files/reproduce.sh /work/reproduction/full`. It passed all supplied comparisons: 504 grid rows, 20,160 modal rows, 45 source/layout controls, six cancellation rows and 50 electrode-perturbation rows. All five CSVs, the witness archive, both figures and the stress summary are byte-identical to the frozen outputs. Timing/resource fields in the other JSON outputs vary; their scientific values agree.

The CSV tolerance is `abs(fresh-reference)/max(1,abs(reference)) < 1e-8`; observed differences are zero. Undefined relative-error cells at exact silence are deliberately excluded, while finite signal and absolute-error diagnostics are compared. Supplied independent checks pass their declared tolerances: field/interface and MNE `1e-10`, adaptive integration `1e-9`, matrices `1e-10`, generalized bounds `1e-7`, null residual `1e-12` and harmonic orthogonality `1e-10`. The interface comparison maximum is `7.13e-14`, including repeated reference comparisons.

The [reviewer-written program](evidence/reviewer_check.py) imports no draft routines. It integrates the physical solution inward from `u(R)=1, F(R)=0` with RK45, recovers the singular brain coefficient, constructs real harmonics from associated Legendre functions and solves a generalized eigenproblem. It uses ODE `rtol=2e-11`, `atol=2e-13`; central result tolerances are `2e-8` absolute in fractional units, gain/matrix tolerances `2e-9` relative and witness-residual tolerance `2e-10` of operator norm.

| Quantity | Frozen result | Reviewer result |
| --- | ---: | ---: |
| Rank / source dimension | 63 / 168 | 63 / 168 |
| Nullspace leakage / operator norm | 0.001517861319225 | 0.001517861319210 |
| Stored witness complete-scalp relative error | 0.003483893188554 | 0.003483893188447 |
| Relative electrode error at epsilon 0.001 | 1.517962215193 | 1.517962215213 |
| Sharp bound at eta 0.01 | 0.151915815699 | 0.151915815697 |

These are fractions: the last two rows mean 151.796% relative electrode error and a 15.1916% penalty-normalized bound. The latter is not an ordinary relative-voltage bound. Reviewer gain and matrix differences are `4.42e-12` and `3.46e-11` relative. The stored witness has a `1.28e-13` operator-normalized residual under this independently integrated operator. A projection sensitivity calculation bounds the resulting leakage correction by about `9.88e-15` of operator norm, far below the `0.001518` leakage. This is a stability diagnostic, not a directed-rounding proof. See [independent results](evidence/reviewer_check.json).

Three challenges support the narrow conclusion:

1. A homogeneous insulating sphere has the closed gain `g_l = r0^(l-1)/(σ R^(l+1))` for this moment-per-solid-angle convention. The independent solver agrees through degree 40 within `2.30e-11` relative, below the `2e-9` tolerance.
2. For `E=0.02A`, cancellation is preserved and the penalty bound is exactly `0.02/sqrt(1+eta²)`. Numerical checks agree. Within a single harmonic degree, the model change is also scalar; the computed `E=cA` residual is `1.57e-15`. Thus multiple-degree leakage matters, not rank alone.
3. With 2,000 seeded iid-normal harmonic sources, the median relative error is 0.6924%, the 95th percentile 1.0167% and the maximum 1.3917%. This synthetic control supports the near-cancellation explanation; it is not a physiological probability model or a human error estimate.

The full pipeline took **5.314 s**, 5.143 user CPU seconds and 0.170 system CPU seconds, peaking at **121.06 MiB** for a child process. The reviewer solver reported 0.149 s and 73.32 MiB. One scientific-library thread, no GPU. Outer CPU/RAM limits were inherited; cgroup limits were not visible inside isolation. No whole-review peak resource measurement is available. Review time from the first recorded timestamp, 10:41:43 UTC, is 630.7 s; initialization predates it. [Run log](evidence/full_reproduction.log), [resource record](evidence/full_reproduction_run.json).

## Provenance, references, licenses and secrets

Pinned upstream BioSemi coordinates and the conductivity notebook match their documented hashes. Isolated extraction reproduces all 22 rows and all seven material sets byte-for-byte. The six catalog triplets represent three sample groupings at two frequencies; the 252 geometries are assigned combinations. Central conductivity values agree with [Dannhauer et al., Table I](https://pmc.ncbi.nlm.nih.gov/articles/PMC6869856/), and fluid 1.79 S/m agrees with [Piastra et al., Table 1](https://onlinelibrary.wiley.com/doi/10.1002/hbm.25272).

The physical method is established by [Zhou and van Oosterom](https://pubmed.ncbi.nlm.nih.gov/1612618/) and [Petrov](https://journals.aps.org/pre/abstract/10.1103/PhysRevE.86.011917); layered-skull approximation limits are discussed by [Sadleir and Argibay](https://pubmed.ncbi.nlm.nih.gov/17629793/), and source cancellation by [Ahlfors et al.](https://pmc.ncbi.nlm.nih.gov/articles/PMC2797557/). The two closest SCI papers explicitly limit their guarantees to whole-surface norms or single sources and exclude the present finite-array cancellation guarantee. All four SCI citations resolve with metadata/README/LICENSE checks; their supporting bundles and timestamps were not verified. This supports a credited numerical benchmark contribution, not a new shell theory, regularization theorem or first-priority claim. Access conditions and primary-source details are in [sources.md](evidence/sources.md).

The license matches the installed SCI baseline exactly; MNE's retained BSD notice matches upstream exactly. The pinned conductivity repository has no explicit license file. The payload includes attributed factual numbers, with no copied notebook code, prose or images. No blocking attribution conflict was identified, but ownership and database rights are not certified. The external notebook is not redistributed with this review.

Static inspection and credential-pattern scanning found no secrets or private recordings. NPZ loads with `allow_pickle=False` and has no object arrays. Public sample age/sex grouping keys and nominal electrode names are present. These checks do not prove the absence of every possible secret or establish biological consent beyond the public source record.

## Findings and remaining limits

- **F1 — scoped scientific limitation, nonblocking.** The optimized signed sheet and very small electrode signal drive the headline percentage. Absolute error is only about 0.1518% of operator norm. Source/noise constraints have no biological calibration. The draft states this; retain it in reuse. No clinical or inverse-method benefit was assessed.
- **F2 — scoped provenance limitation, nonblocking.** Catalog extraction is verified, but original full-table agreement is not. The 0.0122 S/m catalog inner-layer value exceeds the 0.0102 S/m upper range in the [Akhtari abstract](https://pubmed.ncbi.nlm.nih.gov/12002346/), as already disclosed at `files/provenance.md:28`. The [review correction](https://link.springer.com/article/10.1007/s10548-020-00807-z) exists; no uncorrected population mean enters the calculation. Keep the catalog/stress labels. These uncertainties do not affect the conventional-material central witness.
- **F3 — optional format improvement, nonblocking.** The exact-silence CSV rows contain huge finite residual-dependent ratios. `README.md:59` correctly identifies them as undefined physically. A future revision could use null/blank plus a status flag. The nonzero-epsilon argument already supports the claim.

Other unverified domains are anatomical validity, living-head material fidelity, noise detectability, source-localization performance, independent timing of the author-recorded predictions and a comprehensive novelty/ownership audit. The failed below-5% modal prior is reported candidly. Reviewer-written physical checks cover the central example and homogeneous boundary case; full-grid alternative calculations use the supplied independently structured program. No interval or formal certification is claimed.

## Usefulness and disposition

The explicit witnesses, generic fixed-operator bound routine, credited datasets, controls and fast deterministic replay justify **3/5 usefulness** for forward-model and inverse-method developers. Existing shell/cancellation theory and the lack of physiological or instrument validation limit broader significance. Scientific soundness and usefulness were assessed separately.

**Approve the frozen conditional claim.** No required scientific correction remains. The findings are scoped limitations or optional presentation improvements already consistent with the draft. The JSON report carries the same package identity, result, scope and verdict. Reports and evidence were written under `/work/review`; no signing, submission, publication or voting was performed.
