import csv,json
from pathlib import Path
from PIL import Image

root=Path('/work/reproduction/full')
grid=list(csv.DictReader((root/'grid.csv').open()))
results={}
for method in ('planar','spherical'):
    rows=[r for r in grid if r['method']==method]
    vals=[float(r['cap_0.01']) for r in rows]
    results[method]={'heads':len(rows),'eta001_range':[min(vals),max(vals)],'eta001_over_005':sum(v>.05 for v in vals),'maximum_case':max(rows,key=lambda r:float(r['cap_0.01']))}
controls=list(csv.DictReader((root/'controls.csv').open()))
results['controls']=[r for r in controls if r['layout']=='biosemi64' and r['source_fraction']=='0.98' and r['band'] in ('4','7','12')]
stress=list(csv.DictReader((root/'position_stress.csv').open()))
r=[x for x in stress if x['angle_SD_degrees']=='1.0']
results['one_degree_stress']={key:[min(float(x[key]) for x in r),max(float(x[key]) for x in r)] for key in ('fixed_pattern_relative_error','recomputed_cap_001')}
results['images']={}
for name in ('results.png','witness.png'):
    im=Image.open('/review/result/files/results/'+name)
    im.verify()
    results['images'][name]={'dimensions':im.size,'metadata':im.info}
Path('/work/reproduction/claim_checks.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
