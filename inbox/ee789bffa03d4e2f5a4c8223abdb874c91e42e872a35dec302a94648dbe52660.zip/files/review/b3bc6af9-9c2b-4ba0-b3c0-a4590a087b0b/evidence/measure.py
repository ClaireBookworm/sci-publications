import json
import pathlib
import resource
import subprocess
import sys
import time

start = time.perf_counter()
completed = subprocess.run(sys.argv[2:], check=False)
usage = resource.getrusage(resource.RUSAGE_CHILDREN)
record = {
    'command': sys.argv[2:],
    'returncode': completed.returncode,
    'elapsed_seconds': time.perf_counter() - start,
    'peak_child_rss_MiB': usage.ru_maxrss / 1024,
    'user_cpu_seconds': usage.ru_utime,
    'system_cpu_seconds': usage.ru_stime,
    'measurement': 'Linux resource.RUSAGE_CHILDREN; maximum child high-water RSS, not aggregate concurrent RSS',
}
pathlib.Path(sys.argv[1]).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2), flush=True)
sys.exit(completed.returncode)
