"""Reviewer-authored checks; imports no draft Python module. Run only via review-run."""
import os
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
import csv
import hashlib
import json
from pathlib import Path
import time
import numpy as np
from scipy.integrate import solve_ivp
from scipy.special import lpmv, gammaln
from scipy.linalg import eigh

START = time.perf_counter()
ROOT = Path('/review/result/files')
OUT = Path('/work/reproduction')
RB, SB = .078, .33

def model(sig=(.0064, .02865, .0064), thickness=.006):
    bounds = (RB, .080, .080+thickness/4, .080+3*thickness/4, .080+thickness, .085+thickness)
    return [(a/RB, b/RB, s, s) for a,b,s in zip(bounds[:-1], bounds[1:], (1.79,*sig,.43))]

def planar(m):
    bone = m[1:4]
    a,b = bone[0][0],bone[-1][1]
    sr = (b-a)/sum((y-x)/r for x,y,r,t in bone)
    st = sum((y-x)*t for x,y,r,t in bone)/(b-a)
    return [m[0], (a,b,sr,st), m[-1]]

def inward_gain(m, degrees, depth=.98):
    """Integrate inward from insulating scalp u=1, f=0; recover singular coefficient.

    f=F/(sigma_brain*r_brain). At r_brain, (2*l+1)*B=l*u-f.
    This reverses both direction and boundary construction of the draft solver.
    """
    ans = []
    for ell in degrees:
        state = [1., 0.]
        for a,b,sr,st in reversed(m):
            def ode(x,y):
                return [SB/sr*y[1]/x**2, ell*(ell+1)*st/SB*y[0]]
            sol = solve_ivp(ode,(b,a),state,method='DOP853',rtol=2e-13,atol=2e-14)
            assert sol.success
            state = sol.y[:,-1]
        denominator = ell*state[0]-state[1]
        ans.append(ell*depth**(ell-1)/(SB*RB**2*denominator))
    return np.array(ans)

def real_basis(points, K=12):
    phi=np.arctan2(points[:,1], points[:,0]);z=points[:,2]
    columns=[];degrees=[]
    for l in range(1,K+1):
        for m in range(-l,l+1):
            k=abs(m)
            norm=np.sqrt((2*l+1)/(4*np.pi)*np.exp(gammaln(l-k+1)-gammaln(l+k+1)))
            c=norm*lpmv(k,l,z)
            if m: c=c*np.sqrt(2)*(-1.)**m*(np.sin(k*phi) if m<0 else np.cos(k*phi))
            columns.append(c);degrees.append(l)
    return np.array(columns).T,np.array(degrees)

def eig_cap(A,E,eta):
    alpha=eta*np.linalg.norm(A,2)
    H=A.T@A+alpha**2*np.eye(A.shape[1])
    return np.sqrt(max(eigh(E.T@E,H,eigvals_only=True,subset_by_index=(A.shape[1]-1,A.shape[1]-1))[0],0))

m=model();mr=planar(m)
g=inward_gain(m,range(1,13));h=inward_gain(mr,range(1,13))
records=[line.split() for line in (ROOT/'biosemi64.txt').read_text().splitlines()[1:65]]
theta=np.deg2rad([float(r[1]) for r in records]);phi=np.deg2rad([float(r[2]) for r in records])
points=np.column_stack((np.sin(theta)*np.cos(phi),np.sin(theta)*np.sin(phi),np.cos(theta)))
Y,degree=real_basis(points);Y-=Y.mean(axis=0)
A=Y*g[degree-1]/8;E=Y*(h-g)[degree-1]/8
stored=np.load(ROOT/'results/witness.npz',allow_pickle=False)
norm=np.linalg.norm(A,2)
_,s,Vh=np.linalg.svd(A,full_matrices=True)
rank=int(np.sum(s>s[0]*1e-12));Z=Vh[rank:].T
_,_,Vn=np.linalg.svd(E@Z,full_matrices=False)
qn=Z@Vn[0];v=Vh[0]
leak=np.linalg.norm(E@qn)/norm
nullres=np.linalg.norm(A@qn)/norm
qstored=stored['qnull']
scalp=np.linalg.norm((h-g)[degree-1]*qstored)/np.linalg.norm(g[degree-1]*qstored)
sequence=[]
for eps in (1e-1,1e-2,1e-3,1e-4,1e-5,1e-6):
    q=(qn+eps*v)/np.linalg.norm(qn+eps*v)
    signal=np.linalg.norm(A@q)/norm;error=np.linalg.norm(E@q)/norm
    sequence.append({'epsilon':eps,'signal_over_operator_norm':signal,'absolute_error_over_operator_norm':error,'relative_error':error/signal})

# Analytic homogeneous sphere: g_l = depth^(l-1)*(rb/R)^(l+1)/(sigma*rb^2).
homogeneous=[(1.,1.2,SB,SB)]
hg=inward_gain(homogeneous,range(1,21))
analytic=np.array([.98**(l-1)*(1/1.2)**(l+1)/(SB*RB**2) for l in range(1,21)])
homogeneous_error=float(np.max(np.abs(hg/analytic-1)))

# Boundary: with exact whole-sphere quadrature, sampling is an isometry.
z,w=np.polynomial.legendre.leggauss(16);phi=2*np.pi*np.arange(32)/32
pts=np.stack(np.broadcast_arrays(np.sqrt(1-z[:,None]**2)*np.cos(phi),np.sqrt(1-z[:,None]**2)*np.sin(phi),z[:,None]+phi*0),axis=-1).reshape(-1,3)
Q,dd=real_basis(pts);weights=np.repeat(w,32)*2*np.pi/32
Q=np.sqrt(weights)[:,None]*Q
AQ=Q*g[dd-1];EQ=Q*(h-g)[dd-1]
_,sq,vq=np.linalg.svd(AQ,full_matrices=False)
quadrature_cap=np.linalg.norm((EQ@vq.T)/sq[None,:],2)
modal=np.max(np.abs(h/g-1))

# Analytic scalar-gain error preserves nullspaces; no infinite relative error.
scalar_leak=np.linalg.norm((.02*A)@Z,2)/norm
scalar_bound=eig_cap(A,.02*A,.01)
scalar_expected=.02/np.sqrt(1+.01**2)

summary=json.loads((ROOT/'results/summary.json').read_text())
caps=[eig_cap(A,E,eta) for eta in summary['reference_example']['floors']]
cap_rel=float(np.max(np.abs(np.array(caps)/summary['reference_example']['caps']-1)))
gain_rel=float(max(np.max(abs(g/stored['reference_gain'][:12]-1)),np.max(abs(h/stored['reduced_gain'][:12]-1))))
matrix_error=float(max(np.linalg.norm(A-stored['A'])/np.linalg.norm(A),np.linalg.norm(E-stored['E'])/np.linalg.norm(E)))

# Inspect every numeric CSV field, avoiding the draft comparator's NaN blind spot.
numeric_count=0
for file in ('grid.csv','modes.csv','controls.csv','cancellation.csv','position_stress.csv'):
    for row in csv.DictReader((ROOT/'results'/file).open()):
        for value in row.values():
            try: number=float(value)
            except ValueError: continue
            assert np.isfinite(number),(file,value)
            numeric_count+=1
for key in stored.files:
    if stored[key].dtype.kind in 'fci': assert np.isfinite(stored[key]).all(),key

report={
    'method':'Reviewer-authored inward adaptive ODE from insulating scalp; fresh Legendre harmonics; generalized eigenproblem. No draft modules imported.',
    'tolerances':{'gain_relative':1e-9,'matrix_relative':1e-8,'bound_relative':1e-7,'null_residual_over_operator_norm':1e-12,'homogeneous_gain_relative':1e-9,'quadrature_cap_absolute':1e-10,'scalar_cap_absolute':1e-10},
    'gain_max_relative_difference':gain_rel,'matrix_relative_difference':matrix_error,
    'rank':rank,'dimension':A.shape[1],'null_residual_over_operator_norm':nullres,
    'null_leakage_over_operator_norm':leak,'stored_null_pattern_scalp_error':scalp,
    'eta':summary['reference_example']['floors'],'caps':caps,'cap_max_relative_difference':cap_rel,
    'epsilon_sequence':sequence,'homogeneous_analytic_max_relative_error':homogeneous_error,
    'whole_sphere_quadrature_gram_error':float(np.linalg.norm(Q.T@Q-np.eye(len(dd)),2)),
    'whole_sphere_quadrature_zero_penalty_cap':float(quadrature_cap),'whole_sphere_modal_error':float(modal),
    'scalar_gain_null_leakage':float(scalar_leak),'scalar_gain_eta_001_bound':float(scalar_bound),'scalar_gain_analytic_bound':scalar_expected,
    'finite_numeric_csv_fields':numeric_count,'wall_seconds':time.perf_counter()-START,
}
(OUT/'reviewer_check.json').write_text(json.dumps(report,indent=2)+'\n')
assert gain_rel<1e-9 and matrix_error<1e-8 and cap_rel<1e-7
assert nullres<1e-12 and leak>1e-4
assert abs(leak/summary['null_error']-1)<1e-7
assert homogeneous_error<1e-9
assert abs(quadrature_cap-modal)<1e-10
assert scalar_leak<1e-12 and abs(scalar_bound-scalar_expected)<1e-10
assert .003483<scalp<.003485
assert all(abs(row['epsilon']*row['relative_error']/leak-1)<.01 for row in sequence)
print(json.dumps(report,indent=2))
