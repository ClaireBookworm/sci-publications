"""Assemble reviewer reports from saved evidence; does not execute payload code."""
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path('/work/review')
E = ROOT / 'evidence'
inventory = json.loads((E/'inventory.json').read_text())
audit = json.loads((E/'inventory_check.json').read_text())
env = json.loads((E/'reviewer_environment.json').read_text())
own = json.loads((E/'reviewer_check.json').read_text())
resources = json.loads((E/'full_resource.json').read_text())
ownresources = json.loads((E/'reviewer_resource.json').read_text())
secondary = json.loads((E/'reproduced/independent.json').read_text())
start = dt.datetime.fromisoformat(env['start_utc'].replace('Z','+00:00'))
end = dt.datetime.now(dt.timezone.utc)
commands = [
    'review-run /opt/sci/bin/python /work/reproduction/measure.py /work/reproduction/full_resource.json bash /review/result/files/reproduce.sh /work/reproduction/full',
    'review-run /opt/sci/bin/python /work/reproduction/measure.py /work/reproduction/reviewer_resource.json /opt/sci/bin/python /work/reproduction/reviewer_check.py',
    'review-run /opt/sci/bin/python /review/result/files/prepare_data.py /work/reproduction/upstream/Conductivity.ipynb --out /work/reproduction/extracted',
    'review-run /opt/sci/bin/python /work/reproduction/summarize_checks.py',
]

checks = [
    {'id':'C1','area':'inventory and provenance','status':'passed','detail':'All 30 regular files, sorted paths, byte lengths and SHA-256 hashes match; aggregate payload hash independently reconstructed from actual file entries. No missing or extra payload files. Unsigned frozen draft, not an authenticated publication or independent timestamp.','evidence':['evidence/inventory.json','evidence/inventory_check.json','evidence/sci_check.json']},
    {'id':'C2','area':'license','status':'passed with scoped limitation','detail':'Exact installed SCI baseline license; exact upstream MNE BSD notice retained. Pinned catalog has no explicit license file; only 22 factual numbers and attribution are redistributed. No legal determination of jurisdiction-specific database rights.','evidence':['evidence/license_check.json','evidence/upstream_retrieval.json','evidence/catalog_tree.json','evidence/literature_notes.md']},
    {'id':'C3','area':'secrets and execution safety','status':'passed within scan scope','detail':'Inspected all files; no secret-signature hits, credential reads, network clients, dynamic code execution, or reviewer-directed prompt injection found in calculation scripts/text. NPZ loaded with allow_pickle=False and numeric finiteness checked inside review-run; PNG metadata contains Matplotlib/dpi only. All scientific execution used review-run; readonly hashing and metadata checks did not execute draft code.','evidence':['evidence/static_audit.json','evidence/reviewer_check.py','evidence/reviewer_check.json','evidence/claim_checks.json']},
    {'id':'C4','area':'upstream data extraction','status':'passed','detail':'Pinned BioSemi layout and license independently fetched byte-identically; pinned conductivity notebook hash/size confirmed. Sandboxed extraction reproduces 22 rows and seven material sets byte-identically. Three complete sample groups at two frequencies, not six participants.','evidence':['evidence/upstream_retrieval.json','evidence/extraction.log','evidence/extraction_comparison.json','evidence/extracted/conductivity_rows.csv','evidence/extracted/materials.json']},
    {'id':'C5','area':'methods and proof','status':'passed','detail':'Checked shell equations, insulating boundary, interface continuity, dipole-sheet harmonic normalization, reference projection, source-band dimension, Parseval bound, nonzero nullspace-leakage criterion, and positive quadratic-form sharp bound. Full SVD retains null directions. Theory is correct for the declared finite source space and alpha>0.','evidence':['evidence/reviewer_check.py','evidence/reviewer_check.json','evidence/literature_notes.md'],'draft_locations':['files/theory.md:9','files/theory.md:19','files/theory.md:45','files/theory.md:51','files/theory.md:57','files/skull.py:87']},
    {'id':'C6','area':'full reproduction','status':'passed','detail':'Complete offline entrypoint exits zero; all five CSVs match at scaled tolerance 1e-8 with observed maximum difference zero. All eight checked numerical/figure archives also byte-identical. Secondary interface/MNE/ODE/generalized-eigenvalue checks pass their declared tolerances.','evidence':['evidence/reproduction.log','evidence/reproduction_hashes.json','evidence/full_resource.json','evidence/reproduced/independent.json']},
    {'id':'C7','area':'independent reviewer calculation and challenge','status':'passed','detail':'No draft Python modules imported. Inward ODE with scalp boundary data, fresh harmonics and generalized eigenvalues reproduce the central result. Homogeneous analytic reference, scalar-gain control, dense whole-sphere quadrature, and smaller-epsilon continuation all support the claimed finite-array mechanism.','evidence':['evidence/reviewer_check.py','evidence/reviewer_check.json','evidence/reviewer_check.log','evidence/reviewer_resource.json']},
    {'id':'C8','area':'conclusions, uncertainty and literature','status':'passed within stated scope','detail':'Grid extrema/counts, degree-4 finite bound, degree-7 rank, failed 5-mm prediction, and electrode perturbation ranges agree. Figures were visually inspected and regenerated exactly. Primary literature supports established shell theory and cancellation; practical inverse robustness is a competing perspective. Verified SCI reads support stated prior-work exclusions; first priority not established.','evidence':['evidence/claim_checks.json','evidence/literature_notes.md','evidence/prior_012557da.json','evidence/prior_40fc3aea.json','evidence/prior_824384de.json','evidence/prior_87cfdbf6.json','evidence/reproduced/summary.json']},
]

findings = [
    {'id':'F1','severity':'limitation','blocks_approval':False,'finding':'The large relative error is an optimized near-silence effect with small absolute leakage, within a prescribed radial harmonic sheet. It is not an estimate of ordinary EEG error or inverse localization failure.','evidence':['README.md:45','README.md:59','README.md:85','evidence/reviewer_check.json'],'recommendation':'Retain the current absolute-error and source-class qualifications. Justify Q, V and alpha externally before using the bound in an application.'},
    {'id':'F2','severity':'limitation','blocks_approval':False,'finding':'Pinned catalog extraction is reproducible, but some layer entries differ from the original abstract ranges; individual original measurement tables and database reuse rights were not resolved. The source repository has no explicit license file.','evidence':['files/provenance.md','evidence/upstream_retrieval.json','evidence/extraction_comparison.json','evidence/catalog_tree.json','evidence/literature_notes.md'],'recommendation':'Keep these entries labeled as attributed parameter alternatives and preserve the existing disclosure. Audit original tables before treating them as validated measured head parameters. The conventional central result does not depend on these entries.'},
    {'id':'F3','severity':'context','blocks_approval':False,'finding':'Scientific soundness exceeds the strength of the practical contribution: shell theory, cancellation and the generalized norm are established; the new value is the checked finite-array example and reusable benchmark.','evidence':['README.md:17','evidence/literature_notes.md','evidence/reviewer_check.json'],'recommendation':'Optional: cite Stenroos and Hauk (2013) on minimum-norm robustness and Graichen et al. (2025) on spatial sampling to further contextualize practical transfer. No novelty-first or clinical conclusion is warranted.'},
]

report = {
    'package':inventory['package'],
    'payload_sha256':inventory['sha256'],
    'QUO_RUN_ID':env['review_run_id'],
    'model':'gpt-6.1-sol (environment QUO_AGENT; exact runtime weights not independently attested)',
    'date':end.isoformat(timespec='seconds'),
    'shared_operator_swarm':{'operator_shared_with_author':True,'swarm':'Sciscape research swarm','author_model':'Codex; exact model not independently verified; shared model possible','independence':'Separate internal reviewer did not author frozen draft; no earlier verdict for this package supplied or sought; no contact with author. Not external institutional replication.'},
    'scope':'Internal review of all 30 frozen payload files; provenance, licenses, references, secrets, equations, implementation, central numerical reproduction, analytic/boundary challenges, uncertainty and specialist usefulness. Readonly external literature and source retrieval; no signing, submission, publication or vote.',
    'conflicts':['Shared operator and research swarm with author.','Model-family and training-data correlation possible; reviewer model environment-declared gpt-6.1-sol, author exact model unknown.','Reviewer authored new checking code after seeing frozen implementation; equations and scientific task are necessarily shared.'],
    'claim':'For the stated concentric resistive head, K=12 radial dipole sheet and mean-referenced BioSemi64 layout, skull averaging changes a sensor-null source into nonzero output. A stored pattern has 0.348389% complete-scalp relative field error and 0.151786% sensor leakage relative to ||A||. Bounded sources near it have unbounded relative sensor error as their reference output approaches zero. C_alpha is a sharp source-penalized bound, not a relative-voltage bound without additional Q,V constraints.',
    'scientific_soundness':{'assessment':'supported within declared model','blocking_errors':0,'basis':'Analytic derivation, full exact replay, reviewer-authored independent ODE/eigenproblem, homogeneous analytic reference, scalar-gain control and whole-sphere sampling boundary all agree. Floating-point validation, not interval proof or anatomical validation.'},
    'usefulness':3,
    'rating_evidence':[
        '3/5: useful specialist benchmark and calculator for forward-model developers, with explicit source witnesses and reusable fixed-operator bound.',
        'Strong reproducibility: exact five-CSV replay, public pinned layout and data extraction, author secondary checks, and new reviewer calculation.',
        'Incremental theory and a deliberately optimized source; no typical-source probability, instrument-noise calibration, patient anatomy, or demonstrated inverse-algorithm gain. These limit practical impact separately from mathematical validity.',
    ],
    'checks':checks,
    'checked_claims':[
        '30-file inventory and aggregate payload hash, exact baseline/MNE notices, pinned upstream hashes, byte-identical extraction.',
        'Rank 63 for 168 K=12 coefficients; independent null leakage 0.0015178613192254945 of ||A|| and residual 1.5321105222712955e-16.',
        'Stored null pattern whole-scalp error 0.003483893188553087; epsilon=0.001 relative sensor error 1.5179622151934242; eta=0.01 sharp penalized bound 0.15191581569882834.',
        '252 assigned heads, 504 reduction rows, 20,160 modal rows; cap ranges and counts above 5% match README.',
        'Degree-4 finite zero-penalty cap 0.04523468055160449; degree-7 rank 58 of 63; one-degree perturbation and failed conventional 5-mm prediction match stored results.',
        'All 148,889 parsed numeric CSV fields and numeric witness arrays are finite; zero-epsilon ratio is treated as undefined scientific quantity despite finite floating-point diagnostic.',
    ],
    'unverified_claims':[
        'Historical order of topic selection, scope change and predictions; author record is not independent preregistration.',
        'Individual catalog conductivities against original full Akhtari measurement tables; current source values and extraction were verified, measurement correctness was not.',
        'First priority, exhaustive absence of related work, complete supporting bundles of cited SCI publications, original full Zhou/Petrov derivations and Hansen book.',
        'Independent institutional/operator validation, author exact runtime model, real subject parameters, physiological source prior, actual noise floor and inverse localization usefulness.',
        'Absence of every possible secret or malicious binary content beyond the scoped text/import/array/image checks; downstream legal rights for factual catalog reuse.',
    ],
    'reproduction':{
        'status':'verified',
        'commands':commands,
        'isolation':'Every scientific calculation invoked through review-run: network disabled, frozen payload readonly, isolated writable /work/reproduction, cleared environment/credentials; no draft module executed by host reviewer Python.',
        'tolerance':{'csv_scaled_absolute':1e-8,'csv_metric':'abs(fresh-reference)/max(1,abs(reference)); undefined exact-silence ratios excluded','reviewer_gain_relative':1e-9,'reviewer_matrix_relative':1e-8,'reviewer_bound_relative':1e-7,'null_residual_over_operator_norm':1e-12,'homogeneous_relative':1e-9,'whole_sphere_cap_absolute':1e-10,'scalar_cap_absolute':1e-10,'secondary_solver':secondary['tolerances']},
        'result':{'exit_code':0,'all_five_csv_max_scaled_difference':0.0,'all_eight_checked_archives_and_figures_byte_identical':True,'reviewer_gain_max_relative_difference':own['gain_max_relative_difference'],'reviewer_matrix_relative_difference':own['matrix_relative_difference'],'reviewer_bound_max_relative_difference':own['cap_max_relative_difference'],'null_leakage_over_operator_norm':own['null_leakage_over_operator_norm'],'null_residual_over_operator_norm':own['null_residual_over_operator_norm'],'full_scalp_error':own['stored_null_pattern_scalp_error'],'epsilon_001_relative_sensor_error':own['epsilon_sequence'][2]['relative_error'],'eta001_cap':own['caps'][2],'secondary_interface_max_relative_error':secondary['max_interface_relative_error']},
        'challenge':{'inward_ODE':'Starts u=1,F=0 at insulated scalp, propagates inward, extracts singular brain coefficient; no primary solver imported.','homogeneous_sphere_gain_formula':'g_l=depth^(l-1)*(rb/R)^(l+1)/(sigma*rb^2)','homogeneous_max_relative_error':own['homogeneous_analytic_max_relative_error'],'scalar_E_equals_002A_null_leakage':own['scalar_gain_null_leakage'],'scalar_gain_cap_analytic_difference':abs(own['scalar_gain_eta_001_bound']-own['scalar_gain_analytic_bound']),'dense_whole_sphere_zero_penalty_cap':own['whole_sphere_quadrature_zero_penalty_cap'],'modal_bound':own['whole_sphere_modal_error'],'epsilon_sequence_extended_to':1e-6,'interpretation':'Effect disappears as predicted for nullspace-preserving errors or isometric whole-sphere sampling; optimized near-silence relative error is not a generic practical failure rate.'},
        'resources':{'full_reproduction':resources,'reviewer_independent':ownresources,'threads':1,'GPU':False,'limits':'review-run inherited outer limits; cgroup CPU/RAM limits were not visible. /proc rlimits saved in reviewer_environment.json. Measured child peaks below 3 GiB; no aggregate reviewer-session peak available.'},
        'instrumentation_note':'Initial wrapper attempt could not start /usr/bin/time because it is absent. It executed no scientific calculation. Successful retry used reviewer-authored Python subprocess/resource measurement; initial log retained.',
        'evidence':['evidence/reproduction.log','evidence/reviewer_check.log','evidence/reviewer_check.json','evidence/reviewer_resource.json','evidence/full_resource.json','evidence/extraction.log','evidence/claim_checks.json','evidence/reproduction_hashes.json'],
    },
    'findings':findings,
    'limitation':[
        'Internal review with shared operator/swarm and potentially shared model; no independent experimental validation.',
        'Fixed positive real concentric conductivities, prescribed smooth source space, nominal sensor positions and mean reference; no anatomical uncertainty guarantee or source localization claim.',
        'Worst-source ratio can be dominated by a tiny reference signal; alpha is a declared source penalty requiring external justification.',
        'Catalog entries and rights caveats remain explicitly disclosed; central example uses separately checked conventional parameters.',
        'Targeted primary-literature check, not systematic review; numerical validation uses ordinary floating point.',
    ],
    'timing':{'started_utc':start.isoformat(timespec='seconds'),'finished_utc':end.isoformat(timespec='seconds'),'elapsed_seconds':(end-start).total_seconds(),'total_review_peak_resources':'Not available; measured reproduction subprocess peaks recorded separately.'},
    'inventory_verification':{'file_count':30,'all_files_match':audit['all_files_match'],'aggregate_payload_matches_inventory':audit['aggregate_payload_matches_inventory'],'recomputed_payload_sha256':audit['recomputed_payload_sha256'],'algorithm':audit['aggregate_hash_algorithm'],'evidence':'evidence/inventory_check.json'},
    'verdict':'approve',
    'verdict_reason':'No unresolved error in the main conditional mathematical or numerical claim. Approval is scoped to the frozen benchmark and its stated model; usefulness is moderate, assessed separately. Findings are limitations or optional context, not blocking corrections.',
    'actions':'Reports and evidence only. Frozen payload unchanged. No signing, submission, publication or vote.',
}
(ROOT/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')

md=f'''**Internal scientific review: approve within the stated model. Usefulness: 3/5.**

Package `{inventory['package']}`; payload SHA-256 `{inventory['sha256']}`. Title: *Small scalp field errors can give large electrode errors in a skull model*. Reviewed all 30 files frozen at `/review/result` against `/review/inventory.json`.

Reviewer QUO_RUN_ID: `{env['review_run_id']}`. Model: `gpt-6.1-sol`, as declared by QUO_AGENT; runtime weights are not independently attested. Date: {end.date()} UTC. Review began {start.strftime('%H:%M:%S')} UTC and was completed {end.strftime('%H:%M:%S')} UTC; elapsed {(end-start).total_seconds():.1f} seconds. This is an internal Sciscape research-swarm review with the same operator as the author and possible model correlation. The author identifies itself as Codex, without independently verified exact model. I did not author this frozen draft, seek its earlier verdict, or communicate with its author. This is separate checking, not external institutional replication.

The main claim is scientifically supported. For this assigned resistive concentric head, radial source sheet and mean-referenced BioSemi64 layout, a small complete-scalp error can coexist with a large relative electrode error near a silent source. The draft correctly distinguishes this ratio from small absolute leakage and from a source-penalized matrix bound. No unresolved error in that conditional claim blocks approval. No claim about typical human error or source-localization accuracy is approved.

The full offline calculation passed in `review-run`. The five numerical CSVs had maximum scaled difference zero, within the declared tolerance `abs(fresh-reference)/max(1,abs(reference)) < 1e-8`. Grid, modes, controls, cancellation, position stress, witness archive and both figures were also byte-identical. Exact-silence floating-point ratios were excluded as scientific relative-error estimates. All 148,889 parsed numeric CSV fields and numeric witness arrays were finite. The replay covered 252 assigned heads, 504 reduction rows, 20,160 modal rows and 50 perturbed layouts. See [reproduction log](evidence/reproduction.log), [output hashes](evidence/reproduction_hashes.json) and [fresh secondary checks](evidence/reproduced/independent.json).

I wrote a separate check importing no draft Python module. It integrates the physical ODE inward from an insulated scalp, extracts the singular brain coefficient, constructs fresh Legendre harmonics and evaluates the sharp bound with a generalized eigenproblem. This reverses the draft's auxiliary-field boundary construction. The maximum gain difference was {own['gain_max_relative_difference']:.3g} relative, matrix difference {own['matrix_relative_difference']:.3g}, and sharp-bound difference {own['cap_max_relative_difference']:.3g}; tolerances were 1e-9, 1e-8 and 1e-7 respectively. Source-null residual had to be below 1e-12 of the operator norm. See [reviewer code](evidence/reviewer_check.py) and [results](evidence/reviewer_check.json).

| Central quantity | Independent reviewer result |
| --- | ---: |
| Sensor rank / source dimension | 63 / 168 |
| Null-source residual / operator norm | {own['null_residual_over_operator_norm']:.8g} |
| Null leakage / operator norm | {100*own['null_leakage_over_operator_norm']:.9f}% |
| Stored null pattern complete-scalp relative error | {100*own['stored_null_pattern_scalp_error']:.9f}% |
| Relative sensor error at epsilon=0.001 | {100*own['epsilon_sequence'][2]['relative_error']:.6f}% |
| Absolute error / operator norm at epsilon=0.001 | {100*own['epsilon_sequence'][2]['absolute_error_over_operator_norm']:.9f}% |
| Sharp penalized bound at eta=0.01 | {100*own['caps'][2]:.9f}% |

The analytic argument also checks out. With H=AᵀA+alpha²I positive definite, changing variables by H^(1/2) gives the stated sharp norm. A source q0 with Aq0=0 but Eq0 nonzero makes the ratio diverge along normalized q0+epsilon*v as epsilon approaches zero. Numerical rank alone would not suffice; the reconstructed leakage is about thirteen orders larger than its residual. The reviewer sequence extends to epsilon=1e-6 and follows the expected inverse-epsilon growth. The exact-silence ratio remains undefined.

Three challenges support the mechanism and delimit it. First, a homogeneous isotropic sphere has analytic gain `depth^(l-1)*(rb/R)^(l+1)/(sigma*rb^2)`; inward ODE gains agreed through degree 20 to {own['homogeneous_analytic_max_relative_error']:.3g} relative. Second, E=0.02A preserves the nullspace: leakage was {own['scalar_gain_null_leakage']:.3g}, and its eta=0.01 bound matched `0.02/sqrt(1+eta^2)` to {abs(own['scalar_gain_eta_001_bound']-own['scalar_gain_analytic_bound']):.3g} absolute. Third, a weighted 512-point whole-sphere quadrature makes sampling an isometry on the declared source band. Its zero-penalty cap was {100*own['whole_sphere_quadrature_zero_penalty_cap']:.9f}%, equal to the modal bound within 1e-10 absolute. Thus finite sampling and a model error that changes silent sources matter; a small denominator does not establish common or large absolute measurement error.

The full grid ranges and counts agree with the text: planar eta=0.01 caps 1.833361–57.846476%, with 227/252 above 5%; spherical caps 0.907311–70.244124%, with 170/252 above 5%. Degree 4 has full column rank and a finite 4.523468% zero-penalty bound. Degree 7 has numerical rank 58 of 63. The fixed witness loses exact silence under electrode perturbation, while recomputed worst-source bounds remain similar; the 1-degree ranges are 17.359456–33.592217% and 15.100816–15.217280% respectively. The disclosed failed 5-mm modal-error prediction also reproduces. See [claim checks](evidence/claim_checks.json). These are deterministic grid and seeded sensitivity statements, not population or continuous uncertainty estimates.

Provenance and payload integrity passed. All file paths, byte lengths and hashes match, with no extra or missing files. I independently reconstructed the aggregate payload digest using UTF-8 `json.dumps(sorted actual file entries, sort_keys=True)` with default separators and no trailing newline; it matches the inventory digest above. The unsigned draft passes the read-only SCI structural check. The baseline license is byte-identical to the installed SCI license, and both the pinned BioSemi file and MNE BSD notice match independent upstream retrieval. The pinned notebook hash and size match; its sandboxed extraction gives byte-identical 22-row and seven-material files. See [inventory check](evidence/inventory_check.json), [structural check](evidence/sci_check.json), [retrieval records](evidence/upstream_retrieval.json), [license check](evidence/license_check.json) and [extraction comparison](evidence/extraction_comparison.json).

The main conductivities match Table 1 of [Dannhauer et al.](https://pmc.ncbi.nlm.nih.gov/articles/PMC6869856/); an author manuscript was read when PMC browser access was challenged. The conventional CSF value is supported by [Piastra et al.](https://pmc.ncbi.nlm.nih.gov/articles/PMC7856654/). [The conductivity-review correction](https://orca.cardiff.ac.uk/id/eprint/136420/1/10548_2020_807_OnlinePDF.pdf) was checked; the draft avoids its uncorrected aggregate means. Some catalog values still exceed the original [Akhtari abstract](https://pubmed.ncbi.nlm.nih.gov/12002346/) ranges. Extraction fidelity is verified, individual original measurement tables are not. The central cancellation example uses the separately checked conventional set.

Literature supports a modest contribution. [Zhou and van Oosterom](https://pubmed.ncbi.nlm.nih.gov/1612618/), [Petrov](https://journals.aps.org/pre/abstract/10.1103/PhysRevE.86.011917) and [Sadleir and Argibay](https://pmc.ncbi.nlm.nih.gov/articles/PMC2496996/) establish the relevant shell and averaging framework. [Ahlfors et al.](https://pmc.ncbi.nlm.nih.gov/articles/PMC2797557/) already demonstrate anatomical source cancellation. Verified CLI reads of the two close SCI studies confirm that their whole-scalp guarantees exclude finite-array near-cancellation; their numerical supporting bundles were not re-audited. [Stenroos and Hauk](https://pmc.ncbi.nlm.nih.gov/articles/PMC3915841/) provide a competing practical perspective: some minimum-norm localization results can remain robust to skull-conductivity errors. This does not contradict the present worst-source forward ratio, but prevents extrapolation to an inverse-method failure. [Graichen et al.](https://pmc.ncbi.nlm.nih.gov/articles/PMC12467547/) further establish sampling and coverage context. Full source-specific checks and access limitations are in [literature notes](evidence/literature_notes.md).

Usefulness is **3/5**, assessed separately from soundness. A solver developer can reuse the explicit operators, source witnesses and bounded-source calculation as a regression benchmark or fixed-model error-budget tool. The theory is standard and the striking ratio is deliberately optimized. There is no physiological calibration of the source penalty, anatomical validation, actual-noise comparison or demonstrated inverse-algorithm improvement. Those limits reduce practical impact without invalidating the scoped calculation.

Nonblocking findings are:

1. **F1 — scope:** Small absolute leakage and optimized near-silence explain the large ratio. Preserve the existing qualifications; justify source norm, minimum signal and penalty externally before application.
2. **F2 — data/rights limitation:** The catalog has no explicit license file and its full original measurement tables remain unchecked. Keep the factual numeric subset attributed and explicitly labeled as parameter alternatives. No notebook prose, code or images are attached here, and no legal determination about database rights is made. This does not affect the conventional central example.
3. **F3 — context:** The advance is a reproducible finite-array benchmark rather than new shell, cancellation or regularization theory. Adding the Stenroos/Hauk and Graichen comparisons would be useful optional context.

Secret-pattern scanning and manual import/code review found no credentials, private keys, network access in scientific scripts, dynamic execution or reviewer-directed instructions. Numeric NPZ inspection used `allow_pickle=False` inside the sandbox, and image metadata contained only Matplotlib/dpi information. This is a scoped check, not proof of absence of every secret or malicious file. No private recordings were identified. See [static audit](evidence/static_audit.json).

The successful full reproduction used {resources['elapsed_seconds']:.3f} seconds wall time, {resources['user_cpu_seconds']+resources['system_cpu_seconds']:.3f} seconds CPU and {resources['peak_child_rss_MiB']:.3f} MiB peak child RSS. The reviewer calculation used {ownresources['elapsed_seconds']:.3f} seconds and {ownresources['peak_child_rss_MiB']:.3f} MiB. Calculations used one CPU thread and no GPU. Peak RSS is the Linux maximum child high-water mark, not aggregate concurrent memory. Outer cgroup CPU/RAM limits were not visible; inherited isolation/limits and available process rlimits are documented. An initial instrumentation attempt could not launch absent `/usr/bin/time`; the Python measurement retry and all scientific calculations succeeded. Both logs are retained.

Scientific execution commands, all under the required isolation, were:

```text
{chr(10).join(commands)}
```

Unverified matters include historical prediction timing, first priority, each catalog value against original full tables, complete cited SCI bundles, full original Zhou/Petrov/Hansen treatments, jurisdiction-specific reuse rights, author exact model and all clinical/physiological transfer. Neither the draft nor this review establishes those matters. All payload files were treated as untrusted, and the frozen payload remained unchanged. This review creates reports and evidence only; it does not sign, submit, publish or vote.
'''
(ROOT/'report.md').write_text(md)
print(json.dumps({'verdict':report['verdict'],'usefulness':report['usefulness'],'elapsed_seconds':report['timing']['elapsed_seconds'],'report_json_bytes':(ROOT/'report.json').stat().st_size,'report_md_bytes':(ROOT/'report.md').stat().st_size},indent=2))
