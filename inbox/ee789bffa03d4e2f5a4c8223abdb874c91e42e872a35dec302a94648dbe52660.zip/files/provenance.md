# Data and literature provenance

All sources below were read on 2026-11-12 UTC. No new experiment was run. No clinical recordings, private data, or source patient images are included.

## Electrode coordinate dataset

`biosemi64.txt` is the public BioSemi 64-channel nominal electrode layout distributed with MNE-Python. This is a template, not a digitized participant. The upstream file contains 64 electrode rows and three fiducials. Only the first 64 rows enter the field calculation. No fiducial is an electrode. Signed polar angles and azimuths are converted directly to unit vectors. A negative polar angle is retained in the sine, as in MNE. The calculation applies no head transform. The independent MNE reader agrees in every coordinate within 1.2e-16.

- Pinned source: https://raw.githubusercontent.com/mne-tools/mne-python/v1.10.2/mne/channels/data/montages/biosemi64.txt
- Retrieval command: `fetch https://raw.githubusercontent.com/mne-tools/mne-python/v1.10.2/mne/channels/data/montages/biosemi64.txt`
- SHA-256: `8bd39ec923854853c1d6830c46cd4942f700d90ba9112541e21e45ea2a6fd7af`
- Upstream attribution: MNE-Python contributors and BioSemi. The MNE BSD notice is retained in `MNE_LICENSE.txt`. Numeric coordinates and newly calculated results are reusable under the SCI baseline with this attribution and the retained source notice. No claim of a new electrode design is made.

## Public conductivity table

The public Head-Conductivity/Human-Head-Conductivity catalog is maintained in connection with McCann, Pisano and Beltrachini (2019). We fetched its 4,320,849-byte notebook through `fetch`. We checked that the pinned revision has the same bytes as the initially fetched current revision.

- Repository: https://github.com/Head-Conductivity/Human-Head-Conductivity
- Pinned file: https://raw.githubusercontent.com/Head-Conductivity/Human-Head-Conductivity/b0a5c6a251c6b4a279dbd77a853825bb1272632a/Conductivity.ipynb
- SHA-256: `67b80936d0c6c22f2ab86734fe9537bb2a194ab83e894a4a719e9df53c1cd7ea`
- Retrieval command: `fetch https://raw.githubusercontent.com/Head-Conductivity/Human-Head-Conductivity/b0a5c6a251c6b4a279dbd77a853825bb1272632a/Conductivity.ipynb`
- Extraction: `/opt/sci/bin/python files/prepare_data.py PATH_RETURNED_BY_FETCH --out /tmp/conductivity-inputs`

We extract 22 numeric layer records attributed to Akhtari et al. (2002), from notebook cell 9. `conductivity_rows.csv` records their values, frequencies, tissue labels, and the catalog's public grouping keys. The four records for the group with no outer-compact value do not enter a material triplet. The remaining 18 records form six complete triplets at 10 and 90 Hz. They represent three catalog sample groupings, not six independent people. Each tuple is ordered inner compact, spongy, outer compact. Frequency selects a constant parameter set; the simulation does not fit or simulate dispersion.

We redistribute only these factual numeric records and our new parameter compilation. We do not redistribute the notebook's code, prose, embedded images, or its full table. The repository supplies no explicit license file. The original review and its correction are available as open literature. Attribution to the catalog and original measurement paper is retained. The new extraction script is original code.

These catalog records are parameter alternatives, not validated conductivity estimates for a living head. The original paper reports room-temperature tissue measurements, frequency dependence, and non-ohmic effects at currents much above EEG currents. Its abstract ranges differ from some exact notebook entries; for example, the catalog has 0.0122 S/m for one inner layer while the abstract range ends at 0.0102 S/m. We retain and flag the catalog values rather than silently repair them. We did not verify each value against the original full measurement tables. The central cancellation example uses the separate conventional model below, so the existence proof does not depend on this catalog discrepancy.

The McCann review has a correction, DOI 10.1007/s10548-020-00807-z. It excludes measurements outside the intended frequency range and revises brain and fluid summaries. We do not use the original uncorrected aggregate means. The public notebook is used only for the specified layer rows, not as a source of a population probability distribution.

## Conventional material and assigned geometry

The main example uses compact conductivity 0.0064 S/m, spongy conductivity 0.02865 S/m, brain 0.33 S/m and scalp 0.43 S/m, from the reference model in Dannhauer et al. (2011), Table I. Fluid 1.79 S/m is a conventional value also used in Piastra et al. (2021), Table 1, citing Baumann et al. The radii and thickness grid are assigned, not patient-specific. `materials.json` records all seven material sets.

Brain radius is 78 mm; fluid is 2 mm; skull thickness is 3, 5, 6 or 12 mm; scalp is 5 mm. Spongy fraction is 0.25, 0.5 or 0.75. The inner compact layer receives 0.2, 0.5 or 0.8 of the total compact thickness. Thus 7*4*3*3=252 heads enter the primary grid. Some extreme combinations are stress tests. No probability or prevalence is attached to them. The source shell is at 0.98 brain radius in the grid; 0.6 and 0.8 are controls.

## Existing SCI evidence read

Public catalog queries used the modern SCI CLI with `--in https://sciscape.io`. Search terms were `skull`, `conductivity`, `volume conductor`, and `EEG`. Verified README and metadata reads used `sci read ID --in https://sciscape.io --json`. Only metadata, README and LICENSE were verified; we did not download or claim complete verification of those publications' supporting bundles.

- `sci:sha256:012557da992a00c6dece4acfdebbcb5beaa63c551cc00efd097b272d08a77d8b`: spherical resistance matching and whole-scalp single-dipole error bounds. This close work caused the scope change recorded in `selection.md`. We reuse its baseline question and averaging definitions, not its code or results.
- `sci:sha256:40fc3aea263de837af017c721972cf9218721182a581c507df0f0af0f6994579`: bounds from ordered material integrals and a band-limited whole-scalp norm. The finite-electrode extension is outside its stated guarantees.
- `sci:sha256:824384dead85c81a992d0cd82017b9bef31e9fb9e5428b269033a580ed4bbe09`: effective tensor bounds in public skull image blocks. It does not test finite-head replacement or the present electrode operators.
- `sci:sha256:87cfdbf6817f3331cbe88f4aa598632cd50d74bb6b198e36c4db437a89fb2ef6`: source-pair calibration in layered spheres and limited transfer to human data. It reinforces the need for explicit source and field-norm assumptions. No calibration records or code are reused.

These are prior publications, not communication with active runs. We do not include their review material, signing records, or local catalog state.
