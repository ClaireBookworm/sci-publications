# Equations and scope

All calculations use SI units. The conductivity equation is

`div(sigma grad V) = div J_p`.

J_p is the impressed current density. Conductivity is positive, real, and constant within each concentric layer. Potential and radial conductivity flux are continuous. Radial flux is zero at the outer scalp. The surface mean of V is zero. This is a resistive model; it does not model electromagnetic induction, tissue capacitance, or traveling electrical waves. It does model how a brain current field reaches the scalp under these assumptions.

**Independent implementation.** The original code here was written from boundary conditions. Inward state propagation, exact modal norms, scalar gain fitting, and the rational dependence on one shell conductivity are established. Closely related exact formulas already appear in [SCI b07d5452](https://sciscape.io/p/b07d5452ab8dbe43f0deba82d4d951e10227aef5c46d2794930dea925c642eb0). No code or arrays from that package were copied. The modal CSF-omission obstruction and this specific public-data comparison are the results of this package.

**Transfer coefficient.** For angular degree n >= 1, each source-free layer has the radial solution

`f(r) = A (r/b)^n + B (b/r)^(n+1)`.

Here b is that layer's outer radius. Set q = sigma r df/dr. At b,

`A = ((n+1) f + q/sigma)/(2n+1)`

`B = (n f - q/sigma)/(2n+1)`.

At the inner radius a, set U = A (a/b)^n and W = B (b/a)^(n+1). The new state is

`f(a) = U + W`

`q(a) = sigma [n U - (n+1) W]`.

Start with f(R) = 1, q(R) = 0 at the scalp radius R. Carry the continuous state inward through the outer layers. At the brain boundary r_b, the brain's singular coefficient is `(sigma_b n f - q)/(sigma_b (2n+1))`. Thus the surface transfer for a singular coefficient normalized at R is

`H_n = sigma_b (2n+1) (R/r_b)^(n+1) / (sigma_b n f(r_b) - q(r_b))`.

This normalization makes H_n identical across the four- and three-layer models for the same uniform brain source moment. It also gives the uniform-conductor limit H_n = (2n+1)/n. Degree zero is a gauge and is omitted.

The second solver fixes the singular brain coefficient, solves all potential and flux continuity equations at once, and adds the two outer-layer coefficients. It uses row scaling and a local power basis. It does not use inward propagation. Both methods use binary64 arithmetic. Large degrees or extreme radius ratios can overflow; checks cover the stated geometry and degrees through 512, with direct boundary comparisons through 80.

**Dipoles and exact angular norms.** Let a dipole lie on the z-axis at radius d. Put rho = d/R, u = cos(theta), and let phi be azimuth. Apart from the common factor p/(4 pi sigma_b R^2), the radial and tangential surface fields are

`V_rad = sum_n H_n n rho^(n-1) P_n(u)`

`V_tan = sum_n H_n rho^(n-1) sqrt(1-u^2) cos(phi) P'_n(u)`.

P_n is the Legendre polynomial. The code uses recurrences for both P_n and its derivative, including at the poles. Arbitrary source positions and moments follow by rotation and linearity. Finite source-sink pairs use the potential series directly, with signed source coefficients `(d/R)^n P_n`, without a point-dipole approximation.

Orthogonality gives the mean-square weights

`w_rad,n = n^2 rho^(2n-2)/(2n+1)`

`w_tan,n = n(n+1) rho^(2n-2)/(2(2n+1))`.

For test transfer G and reference H, relative full-sphere RMS error is

`E^2 = sum_n w_n (g G_n - H_n)^2 / sum_n w_n H_n^2`.

Known moment means g = 1. A free source gain gives

`g = sum_n w_n G_n H_n / sum_n w_n G_n^2`.

The field is average-referenced over the complete scalp. Source moment cancels in every relative error. At d = 0, only n = 1 remains. A free gain then makes skull conductivity unidentifiable from the single map; the reported center gain-fit conductivity is only a chosen representative. The output flags this limit.

**Why one scalar cannot match the tested modes.** For complete scalp fields with degrees 1 through L, write their source coefficients as a_nm. Both models preserve degree and order. Therefore

`V_4,nm = H_4,n a_nm; V_3,nm = H_3,n a_nm`.

The exact largest relative field error over this finite field space is

`max_(1<=n<=L) |H_3,n/H_4,n - 1|`.

A single degree attains it. This is an operator bound over arbitrary signed source patterns, not a statement that an isolated dipole has this error. A high-degree pattern can require strong cancellation of its lower degrees. There is no source-current or noise constraint in this operator comparison.

For the three-layer model, fix the two outer skull radii and all conductivities except skull conductivity kappa. Direct expansion of the state transfer gives

`H_3,n(kappa) = C_n / (a_n kappa + b_n + c_n/kappa)`.

All four coefficients in the present geometry are positive. The derivative has the sign of `c_n - a_n kappa^2`. The explicit coefficients are in certificate.py. This reciprocal affine-conductivity form is prior work, including SCI b07d5452 cited above.

For the 1 mm CSF, K=40 reference, modes 4 and 20 both increase throughout kappa in [0.00001, 0.1] S/m. Their turning points are 0.15831679 and 0.29905269 S/m. Error at most 14% imposes these necessary conditions:

- Mode 4: kappa >= 0.005123679760944 S/m.
- Mode 20: kappa <= 0.005111357867629 S/m.

The gap is 0.0000123218933155 S/m. The intervals are disjoint. This rules out a 14% fit to every retained mode on the entire stated conductivity interval. It is stronger than a failed optimizer search. We evaluate the algebraic roots in double precision, with root absolute tolerance 1e-16 S/m; no directed-rounding certificate is claimed. The large gap relative to solver differences makes the test decisive at the reported precision.

Balancing the two active errors gives kappa = 0.005116012032827 S/m and maximum error 0.140997062655585. Direct evaluation checks that the other 18 degrees stay inside those extrema. An independent grid-bracketed optimizer gives 0.140997107584936, a difference of 4.49e-8 in relative error. The two monotone active constraints also give the minimax interpretation: decreasing kappa increases the negative mode-4 error, and increasing kappa increases the positive mode-20 error.

**A model-specific exact correction.** Multiplication of each three-layer surface harmonic by `H_4,n/H_3,n` gives the four-layer surface field for every brain source in this concentric model. This follows directly from the diagonal transfer and is not a new inverse principle. The correction needs the true geometry and tissue values and complete harmonic coefficients. Finite, noisy electrodes do not supply those coefficients without a sampling and regularization model. This calculation does not estimate the missing CSF from EEG.

**Fits and controls.** Scalar fits search [0.00001, 0.1] S/m. A 129-point log grid brackets a local bounded search; endpoints and the center-calibrated value are also compared. Fit tolerance is 1e-11 in log conductivity. This is a numerical best fit over the stated interval, not a general uniqueness theorem for every dipole. The modal minimax search uses 1001 log points, followed by local refinement. The two-mode obstruction has a separate analytic justification above.

The sensitivity grid varies CSF thickness at fixed inner skull radius. For a source held 0.5 mm below the brain surface, changing fluid thickness also changes source radius and distance to scalp. The separate fixed-40-mm source control holds source radius constant. No grid statistic is a distribution over human anatomy. The recorded 256-to-512 changes are observed numerical refinement errors, not rigorous infinite-series remainder bounds.
