#!/opt/sci/bin/python
"""Rerun central calculations with global boundary equations, not recurrence.

Compare against one run.py output directory. Degrees 1--128 are enough
for these dipoles; the separate truncation check bounds their remainder.
"""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[name]='1'
import sys
sys.dont_write_bytecode = True
import argparse
import csv
import json
import resource
import time
from pathlib import Path
import numpy as np
from scipy.optimize import brentq, minimize_scalar
from sphere import Head, transfer_boundary_system
from certificate import rational_three, obstruction


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compare',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args(); start=time.perf_counter(); cpu=time.process_time()
    L=128; n=np.arange(1,L+1,dtype=float)
    def three(s): return Head((.080,.085,.090),(.33,float(s),.33))
    metrics=[]; sigma_diffs=[]; error_diffs=[]
    with (args.compare/'source_errors.csv').open() as f:
        old=list(csv.DictReader(f))
    # The central reference and the conductivity extremes at 1 mm CSF.
    for k in [20,40,80]:
        head=Head((.079,.080,.085,.090),(.33,1.65,.33/k,.33))
        truth=transfer_boundary_system(head,L)
        s=brentq(lambda x:transfer_boundary_system(three(x),1)[0]-truth[0],1e-5,.1,xtol=1e-15,rtol=1e-14)
        test=transfer_boundary_system(three(s),L)
        for o in ['radial','tangential']:
            # Independently write the angular integrals.
            w=(.0785/.09)**(2*n-2)/(2*n+1)
            w*=n*n if o=='radial' else n*(n+1)/2
            e=float(np.sqrt(np.dot(w,(test-truth)**2)/np.dot(w,truth**2)))
            baseline=next(r for r in old if float(r['thickness_m'])==.001 and int(r['k'])==k and r['site']=='depth_0.5mm' and r['orientation']==o)
            ds=abs(s-float(baseline['center_fit_sigma']))
            de=abs(e-float(baseline['center_fit_error']))
            sigma_diffs.append(ds); error_diffs.append(de)
            metrics.append({'k':k,'orientation':o,'center_fit_sigma':s,'field_error':e,
                'sigma_abs_difference':ds,'field_error_abs_difference':de})
        if k==40:
            E=lambda log_s:np.max(np.abs(transfer_boundary_system(three(np.exp(log_s)),20)/truth[:20]-1))
            # Balanced active extrema are modes 4 and 20. Solve their equality
            # directly, independently of run.py's minimax optimizer.
            balance=lambda x:(transfer_boundary_system(three(x),20)/truth[:20]-1)[[3,19]].sum()
            balanced=brentq(balance,.004,.006,xtol=1e-15)
            extrema=transfer_boundary_system(three(balanced),20)/truth[:20]-1
            assert np.max(np.abs(extrema))<=.14101
            obstruction_dense=obstruction(truth[:20])
            crit=[float(rational_three(j)[-1]) for j in [4,20]]
            # Wide margins relative to rounding make the no-fit test decisive.
            assert crit[0]>.15 and crit[1]>.29
    assert max(sigma_diffs)<1e-12
    assert max(error_diffs)<1e-10
    result={'status':'PASS','independent_method':'Global interface continuity equations; independent Parseval weights; balanced modal roots',
        'harmonic_cutoff':L,'cases':metrics,'max_sigma_abs_difference_S_per_m':max(sigma_diffs),
        'max_field_error_abs_difference':max(error_diffs),'tolerances':{'sigma_absolute':1e-12,'field_error_absolute':1e-10},
        'balanced_minimax_sigma':float(balanced),'balanced_minimax_error':float(np.max(np.abs(extrema))),
        'two_mode_obstruction':obstruction_dense,
        'resources':{'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,
            'peak_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,'threads':1,'gpu_used':False}}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__': main()
