# Reproduction and numerical record

Run from the SCI directory:

```sh
bash files/reproduce.sh /tmp/csf-reproduce
```

The command runs these scientific programs in sequence:

```sh
/opt/sci/bin/python files/run.py --out /tmp/csf-reproduce --external
/opt/sci/bin/python files/rerun.py --compare /tmp/csf-reproduce --output /tmp/csf-reproduce/central_rerun.json
```

The first program computes the full sensitivity grid, checks limits and independent public references, and writes the figure and results. The second recomputes central fits with global boundary equations and independently written field-norm sums. Both exit nonzero on failed acceptance checks. The output directory can be anywhere writable; the draft need not be modified. `PYTHONDONTWRITEBYTECODE=1` prevents cache files in the source directory. Each script limits numerical threads to one. No GPU job is used, so gpu-run is not needed.

For an offline result, omit `--external`. This reproduces the central theory and synthetic grid but does not repeat the independent public-array comparison. External reproduction requires the provided `fetch` command and access to raw.githubusercontent.com. Three commit-pinned downloads total 4,150,062 bytes. Every file is checked against a pinned SHA-256 and byte count before use. Cached fetch downloads may make the timing much shorter than a new network download.

**Dependencies.** The measured environment used `/opt/sci/bin/python`, Python 3.12.16, NumPy 2.2.6, SciPy 1.15.3, and Matplotlib 3.10.9. requirements.txt records the numerical package versions. No MNE, FEM mesh package, or GPU library is needed. The external FEM comparison uses published numeric arrays; it does not rerun their original mesh solve.

**Tolerances and outputs.** run.py writes 270 source rows, 600 modal rows, 18 series-refinement rows, 16 public-reference comparisons, one figure, data provenance, and report.json. These are deterministic scientific outputs except for resource readings. The center root has absolute tolerance 1e-15 S/m and relative tolerance 1e-14. Per-source fits use a 129-point log grid and bounded refinement with tolerance 1e-11 in log conductivity. The modal minimax fit uses 1001 grid points and tolerance 1e-12. All fits compare endpoints; source fits also compare the center-calibrated candidate. The separate obstruction roots use 1e-16 S/m absolute tolerance.

| Acceptance check | Threshold | Final observed value |
| --- | ---: | ---: |
| Global interface transfer, degrees 1–80 | relative 1e-9 | 2.78e-15 |
| Homogeneous sphere | relative 1e-12 | 1.78e-15 |
| Rational three-layer formula | relative 1e-12 | 6.67e-16 |
| Equal fluid and brain conductivity | relative 1e-12 | 2.16e-14 |
| Exactly zero fluid thickness | relative 1e-12 | 0 |
| 1e-12 m near-zero fluid layer vs zero | relative 1e-6 | 1.25e-8 |
| Series change, degree 256 to 512 | relative RMS 1e-6 | 1.49e-14 |
| Spatial quadrature vs spectral error | absolute error-ratio 1e-10 | 7.71e-16 |
| Finite-pair derivative vs point dipole | relative 1e-7 | 3.00e-10 |
| Archived analytic fields | relative RMS 1e-7 | 2.49e-14 |
| Archived finite-element fields | relative RMS 0.005 | 0.001064 |
| Separate central-fit conductivity | absolute 1e-12 S/m | 3.13e-17 S/m |
| Separate central-field error ratio | absolute 1e-10 | 3.29e-15 |

The archived analytic tolerance and the first boundary and series targets were recorded before the first solver calculation. Other validation settings are implementation checks, not an externally preregistered design. The FEM 0.5% acceptance threshold was set after a pilot comparison. Actual residuals, rather than a pass flag alone, are reported. A source outside the brain is explicitly rejected.

The series check sums the additional modal energy through degree 512. It is an observed refinement check, not a rigorous bound on every later degree. In the tested shallow fields, stopping at degree 64 instead gives a largest difference of 0.0003153 relative RMS; degree 128 gives 1.220e-7. The modal two-degree obstruction itself has no series-truncation dependence.

**One failed control and its correction.** An initial near-zero-layer check substituted a finite thickness of 1e-10 m for exactly zero and demanded coefficient agreement below 1e-6 through degree 256. It failed: the largest difference is about 1.2473e-6. High degrees remain sensitive to a finite thickness, even when that thickness is small. The final checks distinguish exact collapse from a near-zero layer and set that latter thickness to 1e-12 m. They report both limits and do not treat a finite layer as mathematically absent. The main 1 mm result did not change.

**Repetition and resource use.** Two full final calculations used separate output directories and the same source hashes. Six scientific outputs were byte-identical: source_errors.csv, modes.csv, convergence.csv, external_comparison.csv, provenance.json, and summary.png. Both complete runs included public reference checks. results/reproduction.json gives the executed commands, source hashes, output hashes, and resource readings. The complete-run wall times were 4.310 and 4.299 seconds; process CPU times were 4.219 and 4.205 seconds. Peak resident memory was 98.46 and 97.00 MiB. A preliminary complete calculation had a peak of 349.29 MiB, still below the 3 GiB working-memory limit. Timings include cached data access and plotting, but not the separate literature search. Resource reporting uses perf_counter, process_time, and getrusage(RUSAGE_SELF). Peak RSS describes the numerical Python process, not a whole-system measurement.

The separate central calculation took about 0.010 seconds of process CPU time with 61.6 MiB peak RSS. It recomputed all three center-fit conductivities and six shallow radial/tangential errors with degree 128. Its largest scalar conductivity difference is 3.13e-17 S/m, and its largest absolute field-error-ratio difference is 3.29e-15. It also independently balanced the active degree-4 and degree-20 errors. The balance gives 14.0997063% versus 14.0997108% from the grid-bracketed minimax optimizer; that difference is an optimizer precision effect, not uncertainty in the 14% obstruction.

**Limits of reproduction.** CPU rounding and library versions can change final digits, optimizer choices in nearly flat free-gain fits, PNG rendering, and resource readings. The numeric acceptance tolerances allow useful independent reruns. A successful run validates this assigned resistive-sphere calculation. It does not establish human head geometry, tissue properties, an electrode sampling model, or source localization accuracy.
