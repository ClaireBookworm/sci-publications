#!/bin/sh
set -eu
export PYTHONDONTWRITEBYTECODE=1
out_dir=${1:-/tmp/csf-reproduce}
code_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
/opt/sci/bin/python "$code_dir/run.py" --out "$out_dir" --external
/opt/sci/bin/python "$code_dir/rerun.py" --compare "$out_dir" --output "$out_dir/central_rerun.json"
