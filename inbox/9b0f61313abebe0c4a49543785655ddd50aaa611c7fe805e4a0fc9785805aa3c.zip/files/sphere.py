"""Isotropic concentric EEG conductor. Original implementation; SI units.

H[n-1] maps the n-th singular potential coefficient, normalized at the
outer radius, to the outer-surface coefficient. The n=0 gauge is omitted.
"""
from dataclasses import dataclass
import numpy as np


@dataclass(frozen=True)
class Head:
    radii: tuple
    sigma: tuple

    def __post_init__(self):
        r, s = np.asarray(self.radii), np.asarray(self.sigma)
        if len(r) != len(s) or len(r) < 1 or np.any(np.diff(r) <= 0):
            raise ValueError('Radii must increase and match conductivities')
        if not np.all(np.isfinite(r)) or not np.all(np.isfinite(s)) or np.any(r <= 0) or np.any(s <= 0):
            raise ValueError('Finite positive radii and conductivities required')

    @property
    def radius(self):
        return self.radii[-1]


def transfer(head, lmax=256):
    """Inward continuation of v=1 and sigma*r*dv/dr=0 from insulated scalp.

    No linear solve. Shell traversal is exact for each retained harmonic.
    Intended numerical domain: degrees <=512 and the supplied head range.
    Extreme radius ratios or much larger degrees can overflow.
    """
    n = np.arange(1, lmax + 1, dtype=float)
    v = np.ones(lmax)
    s = np.zeros(lmax)
    for j in range(len(head.radii) - 1, 0, -1):
        sig = head.sigma[j]
        a = ((n + 1) * v + s / sig) / (2 * n + 1)
        b = (n * v - s / sig) / (2 * n + 1)
        t = head.radii[j - 1] / head.radii[j]
        u, w = a * t ** n, b * t ** (-n - 1)
        v, s = u + w, sig * (n * u - (n + 1) * w)
    sig = head.sigma[0]
    src = (head.radius / head.radii[0]) ** (n + 1)
    return (2 * n + 1) * sig * src / (sig * n * v - s)


def transfer_boundary_system(head, lmax=80):
    """Independent global continuity equations in a local power basis.

    Unknowns: regular brain coefficient, then two coefficients per shell.
    Brain singular coefficient is fixed. Each row is scaled before solve.
    This formulation does not call the inward-continuation routine.
    """
    m = len(head.radii)
    out = []
    for n in range(1, lmax + 1):
        mat = np.zeros((2 * m - 1, 2 * m - 1))
        rhs = np.zeros(2 * m - 1)
        src = (head.radius / head.radii[0]) ** (n + 1)
        def idx(j, b=False):
            return 0 if j == 0 else 2 * j - 1 + int(b)
        for j in range(m - 1):
            t = head.radii[j] / head.radii[j + 1]
            u, w = t ** n, t ** (-n - 1)
            a, c = 2 * j, 2 * j + 1
            mat[a, idx(j)] = 1
            mat[c, idx(j)] = head.sigma[j] * n
            if j:
                mat[a, idx(j, True)] = 1
                mat[c, idx(j, True)] = -head.sigma[j] * (n + 1)
            else:
                rhs[a] = -src
                rhs[c] = head.sigma[0] * (n + 1) * src
            mat[a, idx(j + 1)] = -u
            mat[a, idx(j + 1, True)] = -w
            mat[c, idx(j + 1)] = -head.sigma[j + 1] * n * u
            mat[c, idx(j + 1, True)] = head.sigma[j + 1] * (n + 1) * w
        if m == 1:
            mat[-1, 0], rhs[-1] = n, (n + 1) * src
        else:
            mat[-1, idx(m - 1)] = n
            mat[-1, idx(m - 1, True)] = -(n + 1)
        scale = np.maximum(np.max(np.abs(mat), axis=1), np.abs(rhs))
        x = np.linalg.solve(mat / scale[:, None], rhs / scale)
        out.append(x[0] + src if m == 1 else x[-2] + x[-1])
    return np.array(out)


def weights(depth_radius, outer_radius, lmax, orientation='radial'):
    """Full-sphere mean-square weights; dipole magnitude prefactor omitted."""
    if not 0 <= depth_radius < outer_radius:
        raise ValueError('Source radius must be inside outer sphere')
    n = np.arange(1, lmax + 1, dtype=float)
    q = (depth_radius / outer_radius) ** (2 * n - 2)
    if orientation == 'radial':
        return n * n / (2 * n + 1) * q
    if orientation == 'tangential':
        return n * (n + 1) / (2 * (2 * n + 1)) * q
    raise ValueError('Unknown orientation')


def field_error(h_test, h_true, w, fit_amplitude=False):
    """Relative full-sphere RMS error, plus fitted real source gain."""
    gain = np.sum(w * h_test * h_true) / np.sum(w * h_test ** 2) if fit_amplitude else 1.
    err = np.sqrt(np.sum(w * (gain * h_test - h_true) ** 2) / np.sum(w * h_true ** 2))
    return float(err), float(gain)


def scalp_basis(head, source_radius, directions, lmax=256, h=None):
    """Scalp V per A m for dipoles along z (radial) and x (tangential).

    Source is on +z. Directions must be unit vectors, one per row.
    Uses Legendre and derivative recurrences, including both poles.
    """
    if not 0 <= source_radius < head.radii[0]:
        raise ValueError('Source must be strictly inside brain')
    dirs = np.asarray(directions, dtype=float)
    if dirs.ndim != 2 or dirs.shape[1] != 3 or not np.allclose(np.linalg.norm(dirs, axis=1), 1, rtol=0, atol=1e-12):
        raise ValueError('Unit directions required')
    h = transfer(head, lmax) if h is None else np.asarray(h)
    lmax = len(h)
    u = dirs[:, 2]
    p0, p1 = np.ones(len(u)), u.copy()
    d0, d1 = np.zeros(len(u)), np.ones(len(u))
    vr, vt = np.zeros(len(u)), np.zeros(len(u))
    q = 1.
    for n in range(1, lmax + 1):
        vr += h[n-1] * n * q * p1
        vt += h[n-1] * q * dirs[:, 0] * d1
        p0, p1 = p1, ((2*n+1)*u*p1 - n*p0)/(n+1)
        d0, d1 = d1, ((2*n+1)*(p0 + u*d1) - n*d0)/(n+1)
        q *= source_radius / head.radius
    factor = 1 / (4 * np.pi * head.sigma[0] * head.radius ** 2)
    return factor * np.column_stack((vr, vt))


def pair_potential(head, source, sink, directions, lmax=256, current=1., h=None):
    """Exact finite source-sink pair on scalp; V for current in A."""
    h = transfer(head, lmax) if h is None else np.asarray(h)
    lmax = len(h)
    dirs = np.asarray(directions)
    out = np.zeros(len(dirs))
    for pos, sign in [(np.asarray(source), 1), (np.asarray(sink), -1)]:
        rad = np.linalg.norm(pos)
        if rad >= head.radii[0]:
            raise ValueError('Pair must lie inside brain')
        if rad == 0:
            continue  # n=0 cancels with the other pole
        u = dirs @ (pos / rad)
        p0, p1 = np.ones(len(u)), u
        q = rad / head.radius
        for n in range(1, lmax + 1):
            out += sign * h[n-1] * q * p1
            p0, p1 = p1, ((2*n+1)*u*p1 - n*p0)/(n+1)
            q *= rad / head.radius
    return current * out / (4 * np.pi * head.sigma[0] * head.radius)


def scalp_radius_factor(head, radius, lmax):
    """Continue the outermost-shell voltage to a radius within that shell."""
    inner = head.radii[-2] if len(head.radii) > 1 else 0
    if not inner < radius <= head.radius:
        raise ValueError('Evaluation radius must be within outermost shell')
    n = np.arange(1, lmax + 1, dtype=float)
    x = radius / head.radius
    return ((n + 1) * x ** n + n * x ** (-n - 1)) / (2 * n + 1)


def dipole_potential(head, source, moment, directions, lmax=256, h=None):
    """Arbitrary point dipole on scalp. Source in m, moment in A m."""
    source, moment = np.asarray(source, float), np.asarray(moment, float)
    rad = np.linalg.norm(source)
    z = source / rad if rad else np.array([0., 0., 1.])
    pr = moment @ z
    tang = moment - pr * z
    pt = np.linalg.norm(tang)
    if pt:
        x = tang / pt
    else:
        axis = np.eye(3)[np.argmin(np.abs(z))]
        x = np.cross(z, axis)
        x /= np.linalg.norm(x)
    y = np.cross(z, x)
    dirs = np.asarray(directions) @ np.column_stack((x, y, z))
    basis = scalp_basis(head, rad, dirs, lmax, h)
    return basis[:, 0] * pr + basis[:, 1] * pt
