"""Two-mode obstruction to any scalar skull fit on the stated interval.

This is an algebraic reduction, evaluated in double precision. It is not
an outward-rounded interval-arithmetic computation.
"""
import numpy as np
from scipy.optimize import brentq


def rational_three(n, sigma=None):
    """H_n=C/(a*sigma+b+c/sigma) for the specified three-layer head.

    Return coefficients and the maximum point sqrt(c/a), or H if supplied.
    Brain/scalp sigma=.33; skull occupies .080<r<.085; outer radius=.090.
    """
    n=np.asarray(n,dtype=float)
    outer=(.085/.090)
    u=(n+1)/(2*n+1)*outer**n
    w=n/(2*n+1)*outer**(-n-1)
    v=u+w
    s=.33*(n*u-(n+1)*w)
    x=.080/.085
    p,q=x**n,x**(-n-1)
    a=-n*(n+1)*v*(p-q)/(2*n+1)
    b=(.33*n*v*((n+1)*p+n*q)-s*(n*p+(n+1)*q))/(2*n+1)
    c=.33*n*s*(p-q)/(2*n+1)
    C=(2*n+1)*.33*(.090/.080)**(n+1)
    if sigma is not None:
        return C/(a*sigma+b+c/sigma)
    return a,b,c,C,np.sqrt(c/a)


def obstruction(true_h):
    lo,hi=1e-5,.1
    epsilon=.14
    critical={str(n):float(rational_three(n)[-1]) for n in [4,20]}
    assert min(critical.values()) > hi
    # dH/dsigma has sign c-a*sigma^2, hence H increases on [lo,hi].
    lower4=brentq(lambda s:rational_three(4,s)/true_h[3]-(1-epsilon),lo,hi,xtol=1e-16)
    upper20=brentq(lambda s:rational_three(20,s)/true_h[19]-(1+epsilon),lo,hi,xtol=1e-16)
    assert lower4>upper20+1e-10
    return {'error_threshold':epsilon,'sigma_interval':[lo,hi],
        'mode4_min_required_sigma':float(lower4),'mode20_max_allowed_sigma':float(upper20),
        'disjoint_gap_S_per_m':float(lower4-upper20),'monotonicity_critical_sigma':critical,
        'conclusion':'No scalar skull conductivity in this interval gives <=14% error in both modes 4 and 20.',
        'arithmetic':'Algebraic monotonicity and floating-point root brackets; no directed rounding'}
