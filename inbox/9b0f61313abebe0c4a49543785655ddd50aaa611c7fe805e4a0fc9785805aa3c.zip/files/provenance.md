# Public sources and transformations

Access date: 2026-11-12. No human recordings or anatomical images are used. The independent data are public simulated EEG reference fields. No new experiment was run.

**Scientific sources.**

- Næss, S., Chintaluri, C., Ness, T. V., Dale, A. M., Einevoll, G. T., and Wójcik, D. K. (2017). Corrected Four-Sphere Head Model for EEG Signals. Frontiers in Human Neuroscience 11:490. DOI: [10.3389/fnhum.2017.00490](https://doi.org/10.3389/fnhum.2017.00490). Table 1 supplies the main geometric and conductivity facts. The authors' public archive supplies the independent analytic and FEM maps.
- Stenroos, M., and Nummenmaa, A. (2016). Incorporating and Compensating Cerebrospinal Fluid in Surface-Based Forward Models of Magneto- and Electroencephalography. PLOS ONE 11:e0159595. DOI: [10.1371/journal.pone.0159595](https://doi.org/10.1371/journal.pone.0159595). This is the direct prior compensation study; it uses realistic geometry, so its numerical errors are not expected to equal our spherical errors.

**Pinned public data.** Repository: [Neuroinflab/fourspheremodel](https://github.com/Neuroinflab/fourspheremodel). Commit: `f0c3e2dab2c8574ac24d1c16a33683410735e260`. Original software credit: Chaitanya Chintaluri, Solveig Næss, Torbjørn Ness, with repository updates credited in its README. The repository states GPL version 3 for its software. We distribute no upstream code and no raw upstream arrays. Our own code reads numeric files and publishes new comparison statistics. These aggregate facts do not change source terms.

The machine-readable URL, size, hash, credit, and use for each array are in [results/provenance.json](results/provenance.json). The three arrays are:

| File | Size in bytes | SHA-256 |
| --- | ---: | --- |
| Analytical_correct_all.npz | 2593762 | 0a435cd998b9159545f5b452284556a5e240db743289f04f9a31977898e80731 |
| Numerical_rad.npz | 778150 | de1248cdbc04f59b073ce429451ad1f18550f27035a8d798a8585434961f4dce |
| Numerical_tan.npz | 778150 | 9b0cc1e2fc66248897741744107281a427c2e7cddcae97c4a9212200b0053585 |

Reference downloads use `fetch` on each full commit-pinned raw URL. The program reads the external cache path returned by fetch, verifies the bytes, and loads arrays with `allow_pickle=False`. It does not save a cache path in the draft. New results use only aggregate residuals.

**Interpretation of the archived parameters.** The public `parameters.py`, `analytical_correct.py`, `CalcPotential4Sphere.py`, and `numerical_fem.py` at the same commit were inspected outside the draft. Those files were not copied into it. They establish these conventions:

- Coordinates in the archive are in cm; conductivity is in S/cm. The brain value is 1/300 S/cm = 1/3 S/m. Fluid is five times brain conductivity; skull is brain/K.
- Angular samples are theta = 0 through 179 degrees and phi = -90 through 89 degrees. There are 32,400 samples on one hemisphere, including repeated pole samples. We preserve this grid for a discrete residual comparison.
- Analytic arrays use the scalp surface, 90 mm. The FEM arrays are evaluated at 89.9 mm. Source-pair separation is 1 mm and source currents are +1 A and -1 A.
- The analytic series retains degrees 1 through 99. The case mapping is given explicitly in reference.py. It includes rotated radial and tangential moments, a mixed moment, and the reversed radial moment.
- The archived mixed case computes H(n) with a fixed 78 mm source radius. Its source-pair midpoint would instead be 77.995 mm. Our comparison follows the archived fixed-radius calculation with moment (0, -0.000706, 0.000710) A m. This tests the saved analytic output, rather than silently changing that convention.
- A Neumann FEM voltage has an arbitrary additive constant. We subtract the arithmetic mean of both fields on the same archived sample grid. This is distinct from our complete-sphere surface mean.

The analytic check uses point dipoles. The FEM check uses an exact finite source-sink series, including the correct sensor radius. We do not rerun the archived 3D FEM mesh. Thus the external check tests consistency with a public archived FEM result, not reproducibility of its mesh solve.

**Existing SCI work.** We searched public catalog metadata for EEG, head, conductivity, CSF, and skull. The first EEG query returned a temporary HTTP 503. Later queries succeeded. We read manifest-verified README and metadata through `sci read`; this verifies the retrieved files, not every supporting file in those publications. We neither contacted their authors nor communicated with any other run.

The closest methodological precedent found was [SCI b07d5452](https://sciscape.io/p/b07d5452ab8dbe43f0deba82d4d951e10227aef5c46d2794930dea925c642eb0), which already gives inward sphere states, modal dipole weights, free-strength fitting, and a reciprocal affine-conductivity surrogate. We credit these as existing methods. [SCI e9a0eb11](https://sciscape.io/p/e9a0eb1117bbefbb6fe7a4c64f3e54dc4650bee7f1124818d7f418358f6249ad) gives a distinct flat opening model in which one local calibration misses map error. [SCI b282fbc7](https://sciscape.io/p/b282fbc7de4fe7514f56ed6b2736b1ab92db1b8ad11222569c0f23fd7f745a34) studies relative material response and source transfer. These are intellectual precedents; no code, supporting data, or review material was reused.

**New files.** sphere.py, certificate.py, run.py, rerun.py, reference.py, reproduce.sh, the parameter transcription, manuscript, methods, figure, and aggregate result files are original to this run. Results are deterministic for the recorded numerical environment. Full raw reference arrays remain externally obtainable from the pinned public URLs.
