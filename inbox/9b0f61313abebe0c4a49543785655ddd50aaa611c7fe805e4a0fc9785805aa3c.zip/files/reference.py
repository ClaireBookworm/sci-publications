"""Read pinned external reference arrays; retain only new aggregate results.

Original data and GPL source stay in the external fetch cache. They are
not included or relicensed in this SCI draft. No third-party code is run.
"""
import hashlib
import subprocess
import time
from pathlib import Path
import numpy as np
from sphere import Head, transfer, scalp_radius_factor, pair_potential, dipole_potential

COMMIT='f0c3e2dab2c8574ac24d1c16a33683410735e260'
BASE=f'https://raw.githubusercontent.com/Neuroinflab/fourspheremodel/{COMMIT}/'
DATA={
 'Analytical_correct_all.npz':('0a435cd998b9159545f5b452284556a5e240db743289f04f9a31977898e80731',2593762),
 'Numerical_rad.npz':('de1248cdbc04f59b073ce429451ad1f18550f27035a8d798a8585434961f4dce',778150),
 'Numerical_tan.npz':('9b0cc1e2fc66248897741744107281a427c2e7cddcae97c4a9212200b0053585',778150)}


def external_check(out):
    from run import write_csv
    arrays={}; provenance=[]
    for name,(digest,size) in DATA.items():
        url=BASE+'results/'+name
        cp=subprocess.run(['fetch',url],check=True,capture_output=True,text=True,timeout=60)
        path=Path(cp.stdout.strip())
        raw=path.read_bytes()
        assert hashlib.sha256(raw).hexdigest()==digest and len(raw)==size, 'Changed reference data'
        with np.load(path,allow_pickle=False) as z:
            arrays[name]={k:z[k] for k in z.files}
        provenance.append({'name':name,'url':url,'sha256':digest,'bytes':size,
            'use':'Independent numeric comparison only; original arrays are not redistributed',
            'credit':'Naess et al. (2017), doi:10.3389/fnhum.2017.00490; Neuroinflab/fourspheremodel authors',
            'upstream_license':'Repository states GPL-3.0; this package contains no upstream code or raw arrays'})
    theta,phi=np.mgrid[0:180,-90:90]
    theta,phi=np.deg2rad(theta.ravel()),np.deg2rad(phi.ravel())
    dirs=np.column_stack((np.sin(theta)*np.cos(phi),np.sin(theta)*np.sin(phi),np.cos(theta)))
    h=Head((.079,.080,.085,.090),(1/3,5/3,1/60,1/3))
    # The archived analytic script fixes rz=7.8 cm for its H(n), including
    # mixed case arr_2; p in that case is (0,-0.0706,0.071) A cm.
    cases=[(0,[0,0,.078],[0,0,.001]),(1,[0,0,.078],[0,-.001,0]),
           (2,[0,0,.078],[0,-.000706,.00071]),(3,[0,0,.078],[-.001,0,0]),
           (4,[0,0,.078],[0,-.001,0]),(5,[0,.078,0],[.001,0,0]),
           (6,[.078,0,0],[0,-.001,0]),(7,[.078,0,0],[.001,0,0]),
           (8,[0,.078,0],[0,.001,0]),(9,[0,0,.078],[0,0,-.001])]
    rows=[]
    for i,src,mom in cases:
        pred=dipole_potential(h,src,mom,dirs,99)
        ref=arrays['Analytical_correct_all.npz'][f'arr_{i}']
        err=float(np.linalg.norm(pred-ref)/np.linalg.norm(ref))
        rows.append({'reference':'archived_analytic','case':f'arr_{i}','k':20,'relative_rms_error':err,
                     'gauge_offset_removed_V':0.,'point_pair_difference':0.})
    # FEM used finite point-source pairs and sensors 0.1 mm below scalp.
    # Subtract the discrete mean on these 32400 samples to fix its gauge.
    for orient,name,src,snk in [
       ('radial','Numerical_rad.npz',[0,0,.0785],[0,0,.0775]),
       ('tangential','Numerical_tan.npz',[0,-.0005,.078],[0,.0005,.078])]:
        for k in [20,40,80]:
            h=Head((.079,.080,.085,.090),(1/3,5/3,1/(3*k),1/3))
            H=transfer(h,256)*scalp_radius_factor(h,.0899,256)
            pred=pair_potential(h,src,snk,dirs,h=H)
            point=dipole_potential(h,(np.array(src)+snk)/2,np.array(src)-snk,dirs,h=H)
            pred-=pred.mean(); point-=point.mean()
            ref=arrays[name][f'fem_{k}']
            offset=float(np.mean(ref)); ref=ref-offset
            err=float(np.linalg.norm(pred-ref)/np.linalg.norm(pred))
            pairerr=float(np.linalg.norm(point-pred)/np.linalg.norm(pred))
            rows.append({'reference':'archived_fem','case':orient,'k':k,'relative_rms_error':err,
                         'gauge_offset_removed_V':offset,'point_pair_difference':pairerr})
    write_csv(out/'external_comparison.csv',rows)
    a=max(r['relative_rms_error'] for r in rows if r['reference']=='archived_analytic')
    f=max(r['relative_rms_error'] for r in rows if r['reference']=='archived_fem')
    assert a<1e-7, f'Independent analytic check failed: {a}'
    assert f<.005, f'Archived FEM discrepancy exceeds assigned 0.5% check: {f}'
    return {'analytic_cases':10,'fem_cases':6,'sensors_per_case':32400,
            'analytic_max_relative_rms':a,'fem_max_relative_rms':f,
            'fem_gauge':'Discrete mean over the original hemisphere sampling; not a surface integral',
            'fem_comparator':'Exact finite source-sink pair, not point-dipole approximation',
            'mixed_analytic_case':'Uses fixed .078 m radius in upstream H(n); pair midpoint .077995 m is not used by that archived script'},provenance
