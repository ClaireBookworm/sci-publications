#!/opt/sci/bin/python
"""Recompute the complete offline benchmark; optional public-data check.

Usage: /opt/sci/bin/python files/run.py --out /tmp/eeg-reproduce
Add --external to fetch and check the pinned public reference data.
"""
import os
# Set before importing numerical libraries. No GPU is used.
for name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[name] = '1'
os.environ['MPLBACKEND'] = 'Agg'
import argparse
import csv
import hashlib
import json
from pathlib import Path
import resource
import sys
sys.dont_write_bytecode = True
import time
import numpy as np
import scipy
from scipy.optimize import brentq, minimize_scalar
from numpy.polynomial.legendre import leggauss
from certificate import rational_three, obstruction
from sphere import (Head, transfer, transfer_boundary_system, weights, field_error,
                    scalp_basis, dipole_potential, pair_potential, scalp_radius_factor)

HERE = Path(__file__).resolve().parent
PARAM = json.loads((HERE / 'parameters.json').read_text())
L = PARAM['designed_sensitivity_grid']['lmax']
TOL = dict(boundary_system=1e-9, homogeneous=1e-12, collapse=1e-12,
           series=1e-6, spatial_quadrature=1e-10, pair_derivative=1e-7,
           archived_analytic=1e-7, archived_fem=0.005)


def four(thickness=.001, k=40., csf=1.65):
    if thickness == 0:
        return three(.33 / k)
    return Head((.080-thickness, .080, .085, .090), (.33, csf, .33/k, .33))


def three(sigma):
    return Head((.080, .085, .090), (.33, float(sigma), .33))


def center_fit(h):
    h1 = transfer(h, 1)[0]
    return brentq(lambda x: transfer(three(x), 1)[0]-h1, 1e-5, .1,
                  xtol=1e-15, rtol=1e-14)


def fit(htrue, w, free=False):
    obj = lambda x: field_error(transfer(three(np.exp(x)), len(htrue)), htrue, w, free)[0]
    bounds = (np.log(1e-5), np.log(.1))
    # A grid guards against an unobserved second minimum before local refinement.
    grid = np.linspace(*bounds, 129)
    val = np.array([obj(x) for x in grid])
    ix = int(np.argmin(val))
    a, b = grid[max(ix-1, 0)], grid[min(ix+1, len(grid)-1)]
    sol = minimize_scalar(obj, method='bounded', bounds=(a,b), options={'xatol':1e-11})
    center = brentq(lambda ss:transfer(three(ss),1)[0]-htrue[0],1e-5,.1,xtol=1e-15,rtol=1e-14)
    candidates = [(obj(x), x) for x in [sol.x, bounds[0], bounds[1], np.log(center)]]
    err, x = min(candidates)
    sigma = float(np.exp(x))
    _, gain = field_error(transfer(three(sigma), len(htrue)), htrue, w, free)
    return sigma, float(err), gain


def write_csv(path, rows):
    with path.open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def numerical_checks():
    checks = {}
    checks['boundary_system_max_relative'] = max(
        float(np.max(np.abs(transfer(h,80)/transfer_boundary_system(h,80)-1)))
        for h in [four(t,k) for t in [.0001,.001,.005] for k in [20,40,80]])
    n = np.arange(1,L+1)
    checks['homogeneous_max_relative'] = max(float(np.max(np.abs(transfer(h,L)/((2*n+1)/n)-1)))
        for h in [Head((.09,),(.33,)),Head((.079,.080,.085,.090),(.33,)*4)])
    checks['rational_three_max_relative'] = max(float(np.max(np.abs(rational_three(n,ss)/transfer(three(ss),L)-1))) for ss in [1e-5,.005,.1])
    checks['equal_csf_brain_max_relative'] = float(np.max(np.abs(transfer(four(csf=.33))/transfer(three(.33/40))-1)))
    checks['zero_csf_limit_max_relative'] = float(np.max(np.abs(transfer(four(1e-12))/transfer(three(.33/40))-1)))
    checks['zero_csf_exact_max_relative'] = float(np.max(np.abs(transfer(four(0))/transfer(three(.33/40))-1)))
    conv=[]
    for t in [.0001,.001,.005]:
        for k in [20,40,80]:
            h=four(t,k); H=transfer(h,512)
            for o in ['radial','tangential']:
                w=weights(h.radii[0]-.0005,.09,512,o)
                den=np.sum(w*H*H)
                conv.append({'thickness_m':t,'k':k,'orientation':o,
                    'tail_after_64':float(np.sqrt(np.sum(w[64:]*H[64:]**2)/den)),
                    'tail_after_128':float(np.sqrt(np.sum(w[128:]*H[128:]**2)/den)),
                    'tail_after_256':float(np.sqrt(np.sum(w[256:]*H[256:]**2)/den))})
    checks['series_tail_256_max_relative']=max(x['tail_after_256'] for x in conv)
    # A separate spatial integral checks the complete derivative and norm formula.
    z, wq=leggauss(160)
    dirs=np.column_stack((np.sqrt(1-z*z),np.zeros(len(z)),z))
    h=four(); H=transfer(h,128); sig=center_fit(h); H3=transfer(three(sig),128)
    true=scalp_basis(h,.0785,dirs,128,H)
    test=scalp_basis(h,.0785,dirs,128,H3)
    quad=[]
    for j,o in enumerate(['radial','tangential']):
        # Azimuthal factor 1/2 cancels for tangential relative errors.
        spatial=np.sqrt(np.sum(wq*(true[:,j]-test[:,j])**2)/np.sum(wq*true[:,j]**2))
        spectral=field_error(H3,H,weights(.0785,.09,128,o))[0]
        quad.append(abs(float(spatial)-spectral))
    checks['spatial_quadrature_max_absolute_error']=max(quad)
    # A finite source-sink difference independently checks both dipole components.
    pair_errors=[]
    for j in range(2):
        axis=np.eye(3)[[2,0][j]]; src=np.array([0,0,.078]); sep=1e-6
        p=pair_potential(h,src+sep/2*axis,src-sep/2*axis,dirs)/sep
        direct=scalp_basis(h,.078,dirs)[:,j]
        pair_errors.append(float(np.linalg.norm(p-direct)/np.linalg.norm(direct)))
    checks['pair_derivative_max_relative']=max(pair_errors)
    # Deliberate out-of-domain call: sources outside brain must be rejected.
    try:
        scalp_basis(h,.080,dirs)
    except ValueError:
        checks['outside_brain_rejected']=True
    else:
        checks['outside_brain_rejected']=False
    assert checks['rational_three_max_relative'] < 1e-12
    assert checks['boundary_system_max_relative'] < TOL['boundary_system']
    assert checks['homogeneous_max_relative'] < TOL['homogeneous']
    assert checks['equal_csf_brain_max_relative'] < TOL['collapse']
    assert checks['zero_csf_exact_max_relative'] < TOL['collapse']
    assert checks['zero_csf_limit_max_relative'] < 1e-6
    assert checks['series_tail_256_max_relative'] < TOL['series']
    assert checks['spatial_quadrature_max_absolute_error'] < TOL['spatial_quadrature']
    assert checks['pair_derivative_max_relative'] < TOL['pair_derivative']
    assert checks['outside_brain_rejected']
    return checks,conv


def experiment():
    grid=PARAM['designed_sensitivity_grid']
    rows=[]; modes=[]
    for t in grid['csf_thickness_m']:
        for k in grid['brain_to_skull_ratios']:
            h=four(t,k); H=transfer(h); sc=center_fit(h); Hc=transfer(three(sc)); Hu=transfer(three(.33/k))
            for deg in range(1,41):
                modes.append(dict(thickness_m=t,k=k,degree=deg,true_transfer=float(H[deg-1]),
                    unmodified_transfer=float(Hu[deg-1]),center_fit_transfer=float(Hc[deg-1]),
                    center_fit_relative_error=float(Hc[deg-1]/H[deg-1]-1),
                    center_fit_sigma=sc,exact_spectral_filter=float(H[deg-1]/Hc[deg-1])))
            sd, _, _ = fit(H,weights(.04,.09,L,'radial'))
            Hd=transfer(three(sd))
            # Exact center is separate; seven surface depths and one fixed deep radius.
            sites=[('center',0.),('fixed_40mm',.04)] + [(f'depth_{d*1000:g}mm',h.radii[0]-d) for d in grid['depth_below_brain_surface_m']]
            for label,r in sites:
                for o in grid['source_orientations']:
                    w=weights(r,.09,L,o)
                    best,e,gain=fit(H,w)
                    if r == 0:
                        free, ef, gf = sc, field_error(Hc,H,w,True)[0], field_error(Hc,H,w,True)[1]
                    else:
                        free,ef,gf=fit(H,w,True)
                    err=field_error(Hc,H,w)[0]
                    rows.append(dict(thickness_m=t,k=k,site=label,source_radius_m=r,orientation=o,
                        true_skull_sigma=.33/k,center_fit_sigma=sc,center_fit_ratio=sc/(.33/k),
                        unmodified_error=field_error(Hu,H,w)[0],center_fit_error=err,
                        deep_fit_sigma=sd,deep_fit_error=field_error(Hd,H,w)[0],
                        source_fit_sigma=best,source_fit_error=e,
                        free_amplitude_sigma=free,free_amplitude_gain=gf,free_amplitude_error=ef,
                        skull_identifiable_with_free_gain=(r != 0)))
    # Independent modes matter for arbitrary distributed sources.
    h=four(); H=transfer(h,20)
    objective=lambda x:np.max(np.abs(transfer(three(np.exp(x)),20)/H-1))
    gg=np.linspace(np.log(1e-5),np.log(.1),1001); ii=np.argmin([objective(x) for x in gg])
    sol=minimize_scalar(objective,bounds=(gg[max(ii-1,0)],gg[min(ii+1,len(gg)-1)]),method='bounded',options={'xatol':1e-12})
    certificate={'degree_range':[1,20], 'sigma_search_bounds':[1e-5,.1],
        'grid_points':1001,'minimax_sigma':float(np.exp(sol.x)),
        'minimax_max_modal_error':float(sol.fun),
        'center_fit_max_modal_error':float(np.max(np.abs(transfer(three(center_fit(h)),20)/H-1))),
        'meaning':'Maximum modal error is the exact relative L2 operator norm in the retained surface-harmonic space. The fitted minimax value is a numerical optimum on the stated interval, not an interval-arithmetic global proof.'}
    # A whole-dipole norm depends on mode energy, so a modal bound can be loose.
    spectral=transfer(h)/transfer(three(center_fit(h)))
    certificate['two_mode_obstruction']=obstruction(H)
    certificate['exact_filter_max_roundoff_relative']=float(np.max(np.abs(spectral*transfer(three(center_fit(h)))/transfer(h)-1)))
    return rows,modes,certificate


def plot(out,rows,modes):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axs=plt.subplots(1,3,figsize=(13,3.7),constrained_layout=True)
    for k in [20,40,80]:
        rr=[x for x in modes if x['thickness_m']==.001 and x['k']==k]
        axs[0].plot([x['degree'] for x in rr],[100*x['center_fit_relative_error'] for x in rr],label=f'K={k}')
    axs[0].axhline(0,color='0.5',lw=.7); axs[0].set(xlabel='Spatial degree',ylabel='Modal voltage error (%)',title='1 mm CSF; fit at the center'); axs[0].legend()
    for k in [20,40,80]:
        rr=[x for x in rows if x['thickness_m']==.001 and x['k']==k and x['orientation']=='radial' and x['site'].startswith('depth_')]
        rr=sorted(rr,key=lambda x:x['source_radius_m'])
        axs[1].plot([1000*(.079-x['source_radius_m']) for x in rr],[100*x['center_fit_error'] for x in rr],'-o',ms=3,label=f'K={k}')
    axs[1].invert_xaxis(); axs[1].set(xlabel='Depth below brain surface (mm)',ylabel='Whole-field RMS error (%)',title='Radial source; same center fit'); axs[1].legend()
    for key,label in [('unmodified_error','Unmodified skull'),('center_fit_error','Fit at center'),('source_fit_error','Fit for this source'),('free_amplitude_error','Fit skull and source gain')]:
        rr=[x for x in rows if x['k']==40 and x['orientation']=='radial' and x['site']=='depth_0.5mm']
        axs[2].plot([1000*x['thickness_m'] for x in rr],[100*x[key] for x in rr],'-o',ms=3,label=label)
    axs[2].set(xlabel='CSF thickness (mm)',ylabel='Whole-field RMS error (%)',title='K=40; source 0.5 mm below brain'); axs[2].legend(fontsize=7)
    fig.savefig(out/'summary.png',dpi=160); plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=Path('/tmp/eeg-reproduce'))
    parser.add_argument('--external',action='store_true',help='use fetch to check pinned public data')
    args=parser.parse_args(); args.out.mkdir(parents=True,exist_ok=True)
    start=time.perf_counter(); cpu=time.process_time()
    checks,conv=numerical_checks(); rows,modes,certificate=experiment()
    write_csv(args.out/'source_errors.csv',rows); write_csv(args.out/'modes.csv',modes); write_csv(args.out/'convergence.csv',conv)
    report={'method':'Concentric isotropic resistive EEG; continuous complete scalp; average reference',
        'parameters':PARAM,'tolerances':TOL,'numerical_checks':checks,'modal_certificate':certificate,
        'source_rows':len(rows),'mode_rows':len(modes)}
    if args.external:
        from reference import external_check
        ext,provenance=external_check(args.out)
        report['external_checks']=ext
        (args.out/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
    plot(args.out,rows,modes)
    report['resources']={'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,
        'peak_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
        'thread_limit':1,'gpu_used':False}
    report['dependencies']={'python':sys.version.split()[0],'numpy':np.__version__,'scipy':scipy.__version__}
    import matplotlib
    report['dependencies']['matplotlib']=matplotlib.__version__
    report['source_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [HERE/'sphere.py',HERE/'run.py',HERE/'reference.py',HERE/'certificate.py',HERE/'rerun.py',HERE/'parameters.json']}
    (args.out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':'PASS','source_rows':len(rows),'mode_rows':len(modes),
        'checks':checks,'certificate':certificate,'resources':report['resources']},indent=2))


if __name__=='__main__':
    main()
