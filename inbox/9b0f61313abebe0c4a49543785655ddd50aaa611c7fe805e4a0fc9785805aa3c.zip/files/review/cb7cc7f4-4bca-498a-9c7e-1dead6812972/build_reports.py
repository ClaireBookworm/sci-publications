"""Assemble review artifacts from completed, isolated calculations and audits."""
from pathlib import Path
import json
import datetime
import os

ROOT = Path('/work/review')
E = ROOT/'evidence'
def read(name): return json.loads((E/name).read_text())
inventory = read('frozen_inventory.json')
context = read('review_context.json')
independent = read('independent_result.json')
full = read('full_run/report.json')
offline = read('offline_run/report.json')
alternate = read('offline_run/central_rerun.json')
audit = read('claim_audit.json')
commands = read('commands.json')
now = datetime.datetime.now(datetime.timezone.utc)
elapsed = (now-datetime.datetime.fromisoformat(context['review_start_utc'])).total_seconds()

claim = ('For the assigned concentric resistive head with 1 mm CSF and brain/skull conductivity ratio K=40, '
         'no scalar skull conductivity in [1e-5, 0.1] S/m makes every source-to-scalp harmonic degree 1–20 '
         'accurate to 14% relative amplitude. The balanced minimax error is approximately 14.0997063%. '
         'This fixed-source modal claim is distinct from the smaller whole-dipole residual after source-specific fitting.')

checks = [
    {'name':'Frozen inventory and report identity','status':'pass',
     'scope':'Complete sorted path set, file sizes, and SHA-256 values for all 24 files; no extra files or symlinks.',
     'result':'Every file matches. The report uses the package UUID and payload digest supplied by the trusted inventory. Aggregate payload serialization is not specified; its digest was not independently recomputed from a newly serialized aggregate.',
     'evidence':['evidence/frozen_inventory.json','evidence/inventory_verification.json','evidence/final_validation.json']},
    {'name':'Provenance and public reference inputs','status':'pass',
     'scope':'Three commit-pinned NPZ arrays; upstream parameter conventions, README, license, and static source inspection.',
     'result':'All three arrays match SHA-256 and byte count, total 4,150,062 bytes. Geometry, units, finite-pair currents, sensor radius, harmonic cutoff, mixed-case convention, and hemisphere gauge agree with the documented comparison.',
     'evidence':['evidence/reference_downloads.json','evidence/upstream/parameters.py','evidence/upstream/analytical_correct.py','evidence/upstream/numerical_fem.py','evidence/full_run/provenance.json']},
    {'name':'License and attribution','status':'pass within inspection scope',
     'scope':'Frozen LICENSE, authorship disclosure, upstream GPL-v3 software notice, and included-file inventory.',
     'result':'CC BY 4.0 for text/figures/generated data and MIT for original code are explicit and include full license texts. No upstream arrays or archived source modules are redistributed in the payload. Full legal bodies match the installed legacy SCI license; tree-layout preamble differs. Current publication-template acceptance and ownership are not certified.',
     'evidence':['evidence/license_check.json','evidence/upstream/README.txt','evidence/upstream/gpl-3.0.txt','evidence/inventory_verification.json'],
     'draft_locations':['LICENSE','README.md:5','files/provenance.md']},
    {'name':'Secrets and executable-source inspection','status':'pass within inspection scope',
     'scope':'All non-PNG files scanned for common credential/private-key/password patterns; all five Python modules and reproduce.sh read statically; figure viewed.',
     'result':'No matching secret patterns, signing material, review records, suspicious execution directives, or credential-reading/exfiltration code found. The only explicit subprocess use downloads pinned public inputs with fetch. Heuristic scanning does not exclude encoded secrets.',
     'evidence':['evidence/static_security_scan.json','evidence/inventory_verification.json','evidence/commands.json']},
    {'name':'Unmodified draft reproduction','status':'pass',
     'scope':'Offline full grid, full public-array comparisons with staged data, and author-provided alternate central solver.',
     'result':'All checks pass; 270 source rows, 600 modal rows, 18 convergence rows, 16 reference comparisons. Six scientific output files, including the PNG, are byte-identical to the frozen results.',
     'evidence':['evidence/offline.log','evidence/full.log','evidence/author_central_rerun.log','evidence/scientific_output_comparison.json','evidence/full_run/report.json']},
    {'name':'Reviewer-independent central calculation','status':'pass',
     'scope':'New 70-digit Decimal global boundary system and bisection; independent DOP853 integration in log radius; differential-evolution source fits. No draft modules imported.',
     'result':'The conductivity root, 14% incompatible intervals, balanced minimax, and radial/tangential dipole residuals agree within the recorded tolerances. Positive reciprocal-response coefficients and turning points above 0.1 S/m confirm monotonicity of both active modes on the entire interval.',
     'evidence':['evidence/independent_review.py','evidence/independent_review.log','evidence/independent_result.json']},
    {'name':'Analytic and boundary challenges','status':'pass',
     'scope':'Uniform-conductor formula, equal brain/CSF conductivities, zero-width CSF, single-degree/center fields, and free source gain.',
     'result':'Uniform H_n=(2n+1)/n and equal-conductivity limits agree with the independent ODE method to below 1e-10 relative. At the center, gain removes the scalar discrepancy exactly; a single matched mode has zero error. These counterexamples preclude a universal 14% dipole claim and are consistent with the draft limitations.',
     'evidence':['evidence/independent_result.json','evidence/full_run/report.json'],
     'draft_locations':['README.md:34','README.md:36','README.md:48','README.md:56','files/methods.md:59']},
    {'name':'Tables, predictions, and uncertainty','status':'pass',
     'scope':'Rounded five-row table, designed-grid maxima, nested-fit inequalities, source positions, center identifiability, convergence, and numerical vs anatomical uncertainty.',
     'result':'All displayed table values agree within 0.0005 percentage points. Maximum tested free-gain error is 3.5532132%; maximum 1-mm-CSF transfer error after a fixed-40-mm radial fit is 4.8912719%. The draft reports the failed 5% field prediction and the ambiguity in its deep-source calibration. Its chronology is not independently timestamped by this review.',
     'evidence':['evidence/claim_audit.py','evidence/claim_audit.json','evidence/full_run/convergence.csv'],
     'draft_locations':['files/decision.md:7','files/decision.md:14','README.md:40','README.md:52','README.md:54','files/reproduction.md:40']},
    {'name':'Literature, conclusions, and usefulness','status':'partially verified',
     'scope':'Two direct journal sources inspected; three cited SCI pages attempted; mathematical and practical interpretations reviewed separately.',
     'result':'The journal sources support the benchmark provenance and prior compensation principle. The bounded conclusions fit the numerical evidence. SCI publication contents and exhaustive novelty remain unverified because cited pages were inaccessible and the installed legacy CLI has no read command.',
     'evidence':['evidence/literature_notes.md','evidence/literature_access.json','evidence/additional_source_access.json'],
     'draft_locations':['README.md:13','README.md:15','README.md:17','README.md:71','README.md:73']},
]

findings = [
    {'id':'F1','severity':'scoped limitation','blocks_approval':False,
     'title':'The 14% obstruction concerns a complete-surface modal norm with fixed source coefficients.',
     'detail':'It does not establish a 14% dipole or localization error. The reviewer obtains 4.2789098% center-fit radial error and 3.1564778% after conductivity/gain fitting in the central shallow case. Zero CSF, equal conductivities, and center/gain limits refute any broader universal failure claim. The draft already states these distinctions.',
     'recommendation':'Retain the model, norm, source-gain, and finite-montage qualifications in any subsequent presentation.',
     'evidence':['README.md:25–36','README.md:48','README.md:71–73','evidence/independent_result.json','evidence/claim_audit.json']},
    {'id':'F2','severity':'review limitation','blocks_approval':False,
     'title':'Detailed SCI precedence and originality claims could not be independently checked.',
     'detail':'All three cited sciscape.io publication pages failed browser access and returned HTTP 403 to direct retrieval. The installed legacy sci CLI lacks the documented read command. Attribution is present, but their specific contents and the no-copy assertion remain unverified; no exhaustive novelty assessment is claimed.',
     'recommendation':'Provide accessible immutable citation documents if a stronger novelty or code-originality assessment is needed.',
     'evidence':['README.md:15–17','files/provenance.md','evidence/additional_source_access.json','evidence/literature_notes.md']},
    {'id':'F3','severity':'scoped limitation','blocks_approval':False,
     'title':'Verification establishes a numerical benchmark, without anatomical validation or external preregistration.',
     'detail':'The FEM check compares saved maps and does not regenerate their mesh solve. The grid is deterministic and designed; truncation/rounding tolerances are not human uncertainty intervals. Original decision-note timing, historical author run timing, tissue distributions, noise effects, and localization performance were not independently established. The draft discloses the post-pilot FEM tolerance and its failed finite-thickness control.',
     'recommendation':'Treat the result as a solver/calibration benchmark; further practical claims require separate evidence.',
     'evidence':['README.md:58–73','files/reproduction.md:40–50','evidence/full_run/report.json','evidence/claim_audit.json']},
]

limitations = [
    'Internal review shares the operator and Sciscape research swarm with the author; both may use the same model. No prior verdict was received and no authoring context was available.',
    'The three cited SCI publications were inaccessible; their detailed contents, priority, and source-code originality are unverified. Literature checking was targeted, not exhaustive.',
    'The review validates positive, concentric, isotropic, resistive layers and complete-surface norms only. No human recordings, realistic anatomy, finite EEG montage, noise-limited inversion, or localization claim was tested.',
    'Archived FEM arrays were verified and compared, but the original finite-element mesh solve was not regenerated.',
    'The high-precision obstruction is numerically decisive and analytically monotone, but neither the draft nor this review supplies outward-rounded interval arithmetic or a rigorous infinite-series remainder bound.',
    'The supplied aggregate payload SHA-256 is taken from the trusted inventory; all constituent hashes, lengths, and paths were independently checked. Aggregate serialization was not specified.',
    'Code ownership, the original timing of decision.md, encoded-secret absence, and current publishing-tool template acceptance cannot be certified from this snapshot. No signature or publication validation was attempted.',
    'Whole-run peak RAM and cgroup CPU/RAM limits were not exposed; reported resources describe the numerical Python processes. Initial listing time precedes the first captured timestamp by less than a minute.',
]

references = [
    {'id':'R1','url':'https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0159595',
     'citation':'Stenroos and Nummenmaa (2016), PLOS ONE 11:e0159595',
     'checked':'Prior realistic-head study supports partial CSF-omission compensation by lower skull conductivity; Discussion and Conclusions inspected.',
     'status':'verified'},
    {'id':'R2','url':'https://www.frontiersin.org/journals/human-neuroscience/articles/10.3389/fnhum.2017.00490/full',
     'citation':'Næss et al. (2017), Frontiers in Human Neuroscience 11:490',
     'checked':'Table 1 geometry/materials, corrected analytic benchmark, FEM comparison, and public software link inspected.',
     'status':'verified'},
    {'id':'R3','url':'https://github.com/Neuroinflab/fourspheremodel/tree/f0c3e2dab2c8574ac24d1c16a33683410735e260',
     'checked':'Pinned public data hashes and static implementation/parameter/license conventions.',
     'status':'verified within recorded scope'},
]
for digest in ['b07d5452ab8dbe43f0deba82d4d951e10227aef5c46d2794930dea925c642eb0',
               'e9a0eb1117bbefbb6fe7a4c64f3e54dc4650bee7f1124818d7f418358f6249ad',
               'b282fbc7de4fe7514f56ed6b2736b1ab92db1b8ad11222569c0f23fd7f745a34']:
    references.append({'url':'https://sciscape.io/p/'+digest,'status':'not verified; HTTP 403 and browser inaccessible'})

report = {
    'review_type':'internal independent reviewer; not draft author; no earlier verdict supplied',
    'QUO_RUN_ID':os.environ.get('QUO_RUN_ID'),
    'model':context['model'],
    'shared_operator_swarm':{'operator':context['operator'],'swarm':context['swarm'],'model_may_be_shared':True},
    'date':now.date().isoformat(),
    'scope':'All 24 frozen files at /review/result; inventory integrity, provenance, licenses, references, secrets, methods, main calculation, analytic challenges, uncertainty, conclusions, and usefulness. Read-only payload; no signing, submission, publication, or voting.',
    'conflicts':context['conflicts'],
    'package':inventory['package'],
    'payload_sha256':inventory['sha256'],
    'claim':claim,
    'usefulness':3,
    'rating_evidence':[
        'Useful to EEG forward-model developers as a small reproducible modal/calibration benchmark; six scientific outputs exactly reproduce, and the obstruction is supported by an independently implemented high-precision solver.',
        'The explicit two-mode incompatibility and comparison with dipole fitting add a concrete diagnostic beyond demonstrating scalar compensation alone.',
        'Incremental practical value: compensation and sphere benchmarks have direct prior literature; the draft claims modest novelty, and inaccessible SCI sources prevent full precedence checking.',
        'No finite-montage, noise, anatomical, or localization validation supports direct clinical application. Usefulness 3/5 is separate from scientific soundness.'
    ],
    'scientific_soundness':{
        'assessment':'supported within the stated assigned-model scope',
        'main_claim_verified':True,
        'unresolved_main_claim_errors':[],
        'reason':'Boundary equations, independent radial ODE fields, monotonic reciprocal responses, high-precision disjoint roots, all-mode balance checks, and archived public comparisons agree. The draft retains its unsuccessful stronger dipole prediction and clearly limits inference.'},
    'checks':checks,
    'findings':findings,
    'checked_claims':[
        {'claim':'No <=14% fit across degrees 1–20 on the stated conductivity interval.', 'evidence':'evidence/independent_result.json'},
        {'claim':'Balanced minimax 0.1409970626555845 and center conductivity 0.005748965929372393 S/m.', 'evidence':'evidence/independent_result.json'},
        {'claim':'Central shallow radial center-fit and free-gain errors 0.04278909812231814 and 0.03156477809018332.', 'evidence':'evidence/independent_result.json'},
        {'claim':'All tested free-gain errors below 3.56%; fixed-40-mm calibration maximum at 1 mm CSF below 5%.', 'evidence':'evidence/claim_audit.json'},
        {'claim':'All scientific CSV/PNG/provenance outputs exactly rerun; archive analytic and FEM residuals are reproduced.', 'evidence':'evidence/scientific_output_comparison.json'},
        {'claim':'Assigned geometry, upstream conversion and sampling conventions, and stated upstream GPL-v3 software terms.', 'evidence':'evidence/literature_notes.md'},
    ],
    'unverified_claims':[
        'Detailed contents and precedence relationships of the three cited SCI publications; no-copy claim concerning unavailable SCI code.',
        'Independent provenance of decision.md before the first author computation; historical author runtime measurements.',
        'Legal chain of ownership and absolute absence of encoded secrets; current publishing-tool baseline-template acceptance.',
        'Any implied accuracy for real human heads, finite EEG sensors, noisy measurements, or source localization; these are explicitly outside the draft claim.',
        'Regeneration of the external FEM mesh solve and its original mesh convergence.'
    ],
    'reproduction':{
        'status':'verified',
        'commands':[x['command'] for x in commands['completed_commands']],
        'command_records':'evidence/commands.json',
        'isolation':commands['isolation'],
        'public_data_staging':commands['data_staging'],
        'tolerance':{
            'reviewer_conductivity_absolute_S_per_m':1e-12,
            'reviewer_balanced_modal_error_absolute':1e-12,
            'reviewer_dipole_error_ratio_absolute':1e-9,
            'reviewer_ODE_transfer_relative_and_analytic_limits':1e-10,
            'draft_archived_analytic_relative_RMS':1e-7,
            'draft_archived_FEM_relative_RMS':0.005,
            'rounded_table_absolute_percentage_points':0.0005,
            'all_six_scientific_output_files':'exact bytes',
            'obstruction_roots':'70-digit Decimal arithmetic and 220 bisection steps; no outward rounding'
        },
        'result':{
            'center_sigma_S_per_m':independent['center_conductivity_high_precision'],
            'mode4_required_sigma_lower_bound':independent['mode4_min_sigma_14percent'],
            'mode20_required_sigma_upper_bound':independent['mode20_max_sigma_14percent'],
            'incompatible_interval_gap_S_per_m':independent['disjoint_gap'],
            'balanced_minimax_sigma':independent['balanced_minimax_conductivity'],
            'balanced_minimax_error_ratio':independent['balanced_minimax_error'],
            'independent_method_comparison_relative':independent['mp_vs_ode_max_relative_degrees_1_to_20'],
            'central_shallow_fields':independent['shallow_fields'],
            'archived_analytic_max_relative_RMS':full['external_checks']['analytic_max_relative_rms'],
            'archived_FEM_max_relative_RMS':full['external_checks']['fem_max_relative_rms'],
            'max_tested_free_gain_error_ratio':audit['maximum_free_gain_error']['value'],
            'max_fixed_40mm_fit_transfer_error_ratio_at_1mm_CSF':audit['maximum_deep_40mm_fit_error_for_1mm_CSF']['value'],
            'byte_identical_scientific_outputs':6,
            'all_unmodified_draft_checks_passed':True
        },
        'resources':{
            'offline_draft_run':offline['resources'],
            'full_draft_run_with_staged_public_arrays':full['resources'],
            'author_alternate_central_solver':alternate['resources'],
            'reviewer_independent_solver':independent['resources'],
            'measurement_scope':'Per numerical Python process, not whole VM or all services; GPU not used; actual cgroup limits unavailable.'
        },
        'initial_reviewer_tooling_attempt':commands['initial_reviewer_tooling_attempt'],
        'unresolved_reproduction_failures':[]
    },
    'limitation':limitations,
    'verdict':'approve',
    'verdict_reason':'The bounded mathematical and numerical main claim is reproduced and independently challenged, with no unresolved main-claim error. Approval is a review assessment only; it is not a signature, submission, publication, or vote. Usefulness is moderate and assessed separately.',
    'references':references,
    'review_resources':{'first_captured_utc':context['review_start_utc'],'report_generated_utc':now.isoformat(),
                        'elapsed_wall_seconds_since_first_timestamp':elapsed,
                        'note':'Excludes less than one minute of initial inspection. Whole-review peak RAM is unavailable; per-calculation RSS is reported above.'},
    'evidence_manifest':'evidence/evidence_manifest.json',
}
(ROOT/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')

md = f'''**Internal review: approve within the stated mathematical model.** Scientific soundness is supported; usefulness is **3/5**, assessed separately. No unresolved error in the main claim was found. This is a review assessment, not a signature, submission, publication, or vote.

Package: `{inventory['package']}`. Payload SHA-256 from the trusted inventory: `{inventory['sha256']}`. All **24 files**, their full sorted path set, byte counts, and individual SHA-256 values match. The aggregate serialization algorithm is not specified, so I verified every constituent rather than invent a new aggregate digest. See [inventory verification](evidence/inventory_verification.json) and [original inventory](evidence/frozen_inventory.json).

Reviewer QUO_RUN_ID: `{context['QUO_RUN_ID']}`. Model: {context['model']}. Date: {now.date().isoformat()} UTC. The author and reviewer share the operator and Sciscape research swarm and may share the model. Personal operator/swarm identifiers and exact deployment IDs are not exposed. I did not author the draft, received no earlier reviewer verdict, and had no earlier authoring context. This internal review is not independent external peer review. [Context](evidence/review_context.json).

Scope covered the complete frozen payload at `/review/result`: provenance, reuse terms, references, secrets, executable source, equations, numerical results, conclusions, uncertainty, and usefulness. Draft instructions were treated as untrusted content. All numerical programs, including my scripts processing its outputs, ran through `review-run`. The payload stayed read-only. Host activity was limited to static inspection, hashing, public downloads, evidence copying, and report preparation.

The claim assessed is that, in the assigned 1 mm CSF, K=40 concentric resistive head, no skull conductivity in [0.00001, 0.1] S/m keeps every degree 1–20 within 14% relative amplitude error. The claim fixes the source coefficients and uses the complete scalp surface. It is not a 14% bound for each neural dipole or for localization (README.md:19–36; files/methods.md:59–82).

The unmodified offline calculation and the public-array comparison both passed, producing 270 source rows, 600 modal rows, 18 convergence rows, and 16 external comparisons. Six scientific files, including the figure, are **byte-identical** to the frozen output. The author-provided alternate boundary solver also passed. [Logs and commands](evidence/commands.json), [full output](evidence/full_run/report.json), [file comparison](evidence/scientific_output_comparison.json).

For a reviewer-independent calculation, I wrote a global power-basis boundary system with 70-digit standard-library Decimal arithmetic and explicit Gaussian elimination. It fixes the brain singular coefficient, enforces interface potential/current continuity, and enforces zero outer flux. It imports no draft modules. I independently integrated the radial equations with DOP853 in log radius, using `dV/dt=q/sigma` and `dq/dt=sigma*n*(n+1)*V-q`, and fitted dipoles with differential evolution. [Reviewer source](evidence/independent_review.py), [full independent result](evidence/independent_result.json).

| Quantity | Reviewer result | Acceptance |
| --- | ---: | --- |
| Center-fit skull conductivity | 0.005748965929372393 S/m | Absolute conductivity difference ≤1e-12 S/m |
| Degree 4 lower conductivity required at 14% | 0.005123679760943990 S/m | High-precision boundary root |
| Degree 20 upper conductivity allowed at 14% | 0.005111357867628526 S/m | High-precision boundary root |
| Incompatible interval gap | 1.23218933154637e-5 S/m | Positive, far above numerical differences |
| Balanced minimax conductivity | 0.005116012032827086 S/m | Active modes 4 and 20 |
| Balanced maximum modal error | 0.1409970626555845 | Absolute ratio difference ≤1e-12 |
| Shallow radial center-fit field error | 0.04278909812231814 | Absolute ratio difference ≤1e-9 |
| Same radial source, fitted conductivity and gain | 0.03156477809018332 | Absolute ratio difference ≤1e-9 |
| Independent ODE vs high-precision transfer, degrees 1–20 | 2.67e-15 relative | ≤1e-10 |

The obstruction is stronger than an unsuccessful optimization. The reciprocal response has positive coefficients and is increasing for modes 4 and 20 throughout the stated interval: their turning conductivities are 0.1583167914 and 0.2990526935 S/m. The two necessary 14% intervals are disjoint. Balancing their errors gives 14.0997063%, and all other retained degrees lie between those extrema. My high-precision reciprocal-response identity checks agree to below 2e-68 relative. The proof still uses numerical roots, without directed rounding. The draft's grid optimizer differs from the balanced value by about 4.49e-8 in error ratio, as it already reports; that does not threaten the obstruction.

I challenged a broader interpretation using the analytic homogeneous sphere, equal CSF/brain conductivity, collapsed CSF, isolated center modes, and free source gain. The independent ODE agrees with `H_n=(2n+1)/n` to 2.72e-12 relative and with the equal-conductivity collapse to 2.44e-13, both below the reviewer tolerance of 1e-10. Zero-width fluid gives the same boundary problem. At the center only degree 1 survives, and a gain exactly absorbs its amplitude difference. Arbitrary-field error is the maximum modal error because squared field error is an energy-weighted average of squared modal errors; a dipole's mode weights need not concentrate on the worst degree. The smaller fitted dipole residual is therefore a real counterexample to a universal 14% dipole claim, and the draft correctly retains it.

The table audit confirms every displayed percentage within 0.0005 percentage points. Across the designed grid, the largest free-gain error is 3.5532132%, at 3 mm CSF, K=80, shallow radial source. At 1 mm CSF, the largest shallow transfer error after fitting a radial source at fixed 40 mm radius is 4.8912719%, at K=20. Thus the stronger predicted 5% field threshold fails under that calibration; README.md:52–54 acknowledges it. Source positions, finite numbers, nested-fit residual ordering, and center identifiability flags pass inspection. [Claim audit](evidence/claim_audit.json).

Public reference inputs were fetched before isolation, then checked against the three pinned SHA-256 values and byte counts. A reviewer-written whitelist-only `fetch` adapter returned these local paths inside the network-disabled runner; no draft numerical code was edited. The repeated largest relative RMS differences were **2.4831893e-14** for ten analytic maps and **0.0010634725 (0.1063473%)** for six FEM maps. Acceptance thresholds were 1e-7 and 0.005, respectively. Static upstream inspection supports the documented cm/S-cm conversion, fixed 78 mm analytic source convention, degrees 1–99, hemispherical sampling, 89.9 mm FEM sensors, finite 1 mm pairs, and discrete-mean gauge. This compares archived FEM output; it does not regenerate a mesh solve. [Downloads](evidence/reference_downloads.json), [external residuals](evidence/full_run/external_comparison.csv), [upstream evidence and notices](evidence/upstream/UPSTREAM_NOTICE.md).

The direct literature positioning is appropriate. Partial compensation by reduced skull conductivity predates this draft in the realistic-head study by [Stenroos and Nummenmaa (2016)](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0159595). The geometry and sphere benchmark are supported by [Næss et al. (2017)](https://www.frontiersin.org/journals/human-neuroscience/articles/10.3389/fnhum.2017.00490/full). These support a modest benchmark contribution, not a new compensation principle. All three cited SCI pages were inaccessible; their detailed precedence claims remain unverified. [Literature notes](evidence/literature_notes.md), [access record](evidence/additional_source_access.json).

Reuse terms are explicit: CC BY 4.0 for text, figures, and generated data; MIT for original code. The full legal texts are present. The upstream repository's GPL-v3 software notice is retained in evidence, while the frozen inventory contains no upstream NPZ arrays or archived source modules. No obvious literal copying of the inspected upstream code was found. Legal ownership and the no-copy assertion concerning inaccessible SCI material cannot be certified. The frozen tree-layout license preamble differs from the installed legacy ZIP-layout template; its legal bodies match, and current publication-template acceptance was not tested. [License audit](evidence/license_check.json).

The text scan found no common credential/private-key/password patterns. Manual executable-source inspection found no credential access or unexpected execution/exfiltration paths; the explicit subprocess operation is pinned public-data fetching. No signing material or review files occur in the inventory. The figure was inspected and its numerical curves and labels are consistent with the outputs. A heuristic scan does not prove absence of encoded secrets. [Security scan](evidence/static_security_scan.json).

Usefulness is **3/5** because this is a compact, externally checked solver/calibration benchmark with a concrete two-mode incompatibility test. It can help forward-model developers distinguish fitting a source from fitting a material response. The compensation principle and sphere methods already have direct precedents, novelty is limited and incompletely checked, and there is no finite-montage, noisy inverse, realistic-head, or localization validation. These limits reduce practical reach without undermining the bounded mathematics.

Findings are nonblocking and scoped:

1. **F1 — Norm and application scope.** Retain the fixed-source modal qualification and the smaller dipole counterexample. Approval does not extend to a universal 14% neural-source or localization error (README.md:25–36, 48, 71–73; independent result).
2. **F2 — Unverified SCI references.** HTTP 403/browser failures and a legacy CLI without `read` prevented detailed precedence and no-copy checks. Accessible immutable citation documents would strengthen a later novelty review (access evidence).
3. **F3 — Numerical and chronological limits.** FEM mesh regeneration, human-model uncertainty, decision-note chronology, historical resource readings, legal ownership, and absolute secret absence were not established. No externally preregistered prediction is certified. The draft discloses its post-pilot FEM tolerance, finite-thickness control adjustment, failed stronger field prediction, and observed rather than rigorous tail checks (files/reproduction.md:40–50).

The initial reviewer-selected high-precision script stopped at an unavailable optional `mpmath` import, before numerical work. I replaced that dependency with standard-library Decimal arithmetic; the completed independent calculation passed. This was a resolved reviewer-tooling issue, not a failed package reproduction. Its [initial log](evidence/initial_dependency_attempt.log) and [completed log](evidence/independent_review.log) are both retained.

Measured numerical-process resources: offline draft run **{offline['resources']['wall_seconds']:.3f} s wall / {offline['resources']['cpu_seconds']:.3f} s CPU / {offline['resources']['peak_rss_mib']:.2f} MiB peak RSS**; full staged-reference run **{full['resources']['wall_seconds']:.3f} s / {full['resources']['cpu_seconds']:.3f} s / {full['resources']['peak_rss_mib']:.2f} MiB**; reviewer independent run **{independent['resources']['wall_seconds']:.3f} s / {independent['resources']['cpu_seconds']:.3f} s / {independent['resources']['peak_rss_mib']:.2f} MiB**. Numerical thread limits were one; no GPU was used. These are per-process readings, not whole-VM peaks. Actual cgroup CPU/RAM limits were not exposed at standard paths. Review elapsed time at report generation was **{elapsed:.1f} seconds** from the first captured timestamp, {context['review_start_utc']}; initial inspection preceded it by less than one minute. Generated {now.isoformat()}.

All logs, reviewer source, aggregate reruns, upstream notices, and integrity checks are retained under [evidence](evidence/). [Machine-readable report](report.json) contains the same package identity, tolerances, findings, limitations, and verdict. No signing, submission, publishing, or voting action was performed.
'''
(ROOT/'report.md').write_text(md)
print(json.dumps({'package':report['package'],'payload_sha256':report['payload_sha256'],'verdict':report['verdict'],
                  'usefulness':report['usefulness'],'reproduction':report['reproduction']['status'],
                  'elapsed_wall_seconds':elapsed},indent=2))
