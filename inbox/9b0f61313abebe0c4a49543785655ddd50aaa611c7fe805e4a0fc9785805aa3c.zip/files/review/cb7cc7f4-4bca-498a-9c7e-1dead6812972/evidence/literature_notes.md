Primary literature and provenance checked on 2026-11-12.

[Stenroos and Nummenmaa (2016)](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0159595), Discussion and Conclusions: realistic boundary-element models support partial CSF-omission compensation by reducing skull conductivity, approximately twofold. This is direct prior art, not a competing spherical numerical target.

[Næss et al. (2017)](https://www.frontiersin.org/journals/human-neuroscience/articles/10.3389/fnhum.2017.00490/full), Table 1 and sections 2.3–2.4: the draft transcribes the published geometry and materials correctly; the paper supplies a corrected analytic sphere benchmark, a FEM comparison, and the public GPL-v3 software link.

Reviewer inspected the commit-pinned repository parameters.py, analytical_correct.py, CalcPotential4Sphere.py, numerical_fem.py, README.txt, and gpl-3.0.txt statically. parameters.py lines 3–15 establish cm and S/cm units; lines 28–40 establish the hemispherical grid and 89.9 mm FEM sensors; lines 42–55 establish finite pairs. numerical_fem.py lines 35–43 use +1 and -1 point currents. analytical_correct.py lines 176–188 establish fixed source radius and degrees 1–99. These match the draft's comparison conventions. All downloaded source hashes and URLs are retained.

The three cited SCI publication pages returned HTTP 403 in direct retrieval and were inaccessible via the browser. The installed legacy sci CLI lacks a read command. Their detailed contents, precedence claims, and the assertion that no SCI code was copied remain unverified. Access failures are in additional_source_access.json; they do not invalidate the independently reproduced mathematical result.

Full article HTML was inspected but is not redistributed in this attachment. literature_access.json records successful primary-page retrievals, timestamps, and hashes; short notes above identify the sections supporting the review. This was a targeted check of direct references, not an exhaustive novelty search.
