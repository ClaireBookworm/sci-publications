"""Reviewer audit of aggregate CSV claims; run only under review-run."""
import json, csv, math, sys, resource, time
from pathlib import Path
start=time.perf_counter()
root=Path('/review/result/files/results')
with (root/'source_errors.csv').open() as f:
    rows=list(csv.DictReader(f))
with (root/'modes.csv').open() as f:
    modes=list(csv.DictReader(f))
with (root/'convergence.csv').open() as f:
    conv=list(csv.DictReader(f))
def number(row, key): return float(row[key])
def select(t, k, site='depth_0.5mm', o='radial'):
    return next(r for r in rows if number(r,'thickness_m')==t and int(r['k'])==k and r['site']==site and r['orientation']==o)
def maxrow(seq,key):
    row=max(seq,key=lambda r:number(r,key))
    return {'value':number(row,key),'configuration':{k:row[k] for k in ['thickness_m','k','site','orientation'] if k in row}}
table=[]
targets=[(.001,20,[20.242,9.819,3.175,2.997]),(.001,40,[17.938,4.279,3.157,3.156]),(.001,80,[15.872,3.263,3.215,3.051]),(.003,40,[42.429,9.041,4.616,3.392]),(.005,40,[61.518,12.413,6.879,2.644])]
for t,k,expected in targets:
    row=select(t,k)
    calculated=[100*number(row,key) for key in ['unmodified_error','center_fit_error','source_fit_error','free_amplitude_error']]
    differences=[abs(a-b) for a,b in zip(calculated,expected)]
    assert max(differences)<=.0005
    table.append({'thickness_m':t,'k':k,'percent_errors':calculated,'max_difference_from_rounded_table_percent':max(differences)})
violations=[]
for i,row in enumerate(rows,2):
    for key,value in row.items():
        if key not in ['site','orientation','skull_identifiable_with_free_gain'] and not math.isfinite(float(value)):
            violations.append({'line':i,'issue':'nonfinite '+key})
    assert number(row,'source_radius_m')<.080-number(row,'thickness_m')
    assert number(row,'source_radius_m')>=0
    assert number(row,'source_fit_error')<=number(row,'center_fit_error')+1e-9
    assert number(row,'free_amplitude_error')<=number(row,'source_fit_error')+1e-9
    assert (row['skull_identifiable_with_free_gain']=='False') == (number(row,'source_radius_m')==0)
assert len(rows)==270 and len(modes)==600 and len(conv)==18 and not violations
free_max=maxrow(rows,'free_amplitude_error')
deep_1mm=maxrow([r for r in rows if number(r,'thickness_m')==.001 and r['site'].startswith('depth_')],'deep_fit_error')
assert free_max['value']<.0356
assert abs(100*deep_1mm['value']-4.891)<.0005
result={'status':'verified','source_rows':len(rows),'modal_rows':len(modes),'convergence_rows':len(conv),
        'table_checks':table,'maximum_free_gain_error':free_max,'maximum_deep_40mm_fit_error_for_1mm_CSF':deep_1mm,
        'maximum_center_fit_error_1mm_CSF_by_K':{str(k):maxrow([r for r in rows if number(r,'thickness_m')==.001 and int(r['k'])==k],'center_fit_error') for k in [20,40,80]},
        'center_fit_ratios_1mm_CSF':{str(k):number(select(.001,k),'center_fit_ratio') for k in [20,40,80]},
        'structural_checks':'All rows finite, sources in brain, nested fits obey residual ordering within 1e-9, and center identifiability flags are correct.',
        'resources':{'wall_seconds':time.perf_counter()-start,'peak_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024}}
Path('/work/reproduction/claim_audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
