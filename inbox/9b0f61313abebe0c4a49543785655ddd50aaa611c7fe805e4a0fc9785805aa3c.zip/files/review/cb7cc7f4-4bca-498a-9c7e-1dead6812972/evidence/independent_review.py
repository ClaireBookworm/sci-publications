"""Reviewer implementation. Does not import or execute any draft module.

Solves for global coefficients A*rho**n+B*rho**(-n-1) at 70 decimal
digits for the obstruction; independently integrates the radial ODE
for whole-dipole fits. All numerical work must run under review-run.
"""
import os
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[key] = "1"
import sys
sys.dont_write_bytecode = True
import json
import time
import resource
from pathlib import Path
import csv
from decimal import Decimal, getcontext
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq, differential_evolution

START = time.perf_counter()
CPU = time.process_time()
getcontext().prec = 70
ROOT = Path('/work/reproduction')

def dec(x):
    return Decimal(str(x))

def linear_solve(matrix, rhs):
    """Partial-pivot Gaussian elimination in Decimal arithmetic."""
    a = [list(row)+[b] for row, b in zip(matrix, rhs)]
    size = len(a)
    for j in range(size):
        pivot = max(range(j, size), key=lambda k: abs(a[k][j]))
        a[j], a[pivot] = a[pivot], a[j]
        if a[j][j] == 0:
            raise ValueError('Singular matrix')
        for i in range(j+1, size):
            q = a[i][j]/a[j][j]
            for k in range(j+1, size+1):
                a[i][k] -= q*a[j][k]
            a[i][j] = dec(0)
    out = [dec(0)]*size
    for j in range(size-1, -1, -1):
        out[j] = (a[j][-1]-sum(a[j][k]*out[k] for k in range(j+1, size)))/a[j][j]
    return out

def root_decimal(function, bounds):
    lo, hi = map(dec, bounds)
    flo, fhi = function(lo), function(hi)
    assert flo*fhi < 0
    for _ in range(220):
        mid = (lo+hi)/2
        fm = function(mid)
        if fm == 0:
            return mid
        if flo*fm < 0:
            hi = mid
        else:
            lo, flo = mid, fm
    return (lo+hi)/2


def global_mp(n, radii, conductivity):
    """Global dimensionless basis; brain singular coefficient B_0=1."""
    rr = [dec(x) for x in radii]
    ss = [dec(x) for x in conductivity]
    m = len(rr)
    mat = [[dec(0)]*(2*m-1) for _ in range(2*m-1)]
    rhs = [dec(0)]*(2*m-1)
    # Unknowns A_0,A_1,B_1,...,A_(m-1),B_(m-1).
    def ia(j): return 0 if j == 0 else 2*j-1
    def ib(j): return 2*j
    for j in range(m-1):
        x = rr[j]/rr[-1]
        v, w = x**n, x**(-n-1)
        row = 2*j
        mat[row][ia(j)] = v
        mat[row+1][ia(j)] = ss[j]*n*v
        if j == 0:
            rhs[row] = -w
            rhs[row+1] = ss[j]*(n+1)*w
        else:
            mat[row][ib(j)] = w
            mat[row+1][ib(j)] = -ss[j]*(n+1)*w
        mat[row][ia(j+1)] = -v
        mat[row][ib(j+1)] = -w
        mat[row+1][ia(j+1)] = -ss[j+1]*n*v
        mat[row+1][ib(j+1)] = ss[j+1]*(n+1)*w
    if m == 1:
        mat[0][0], rhs[0] = dec(n), dec(n+1)
    else:
        mat[2*m-2][ia(m-1)] = dec(n)
        mat[2*m-2][ib(m-1)] = dec(-(n+1))
    sol = linear_solve(mat, rhs)
    return sol[0]+1 if m == 1 else sol[ia(m-1)]+sol[ib(m-1)]


R3 = ['.080', '.085', '.090']
R4 = ['.079', '.080', '.085', '.090']
S4 = ['.33', '1.65', '.00825', '.33']


def h3_mp(n, s):
    return global_mp(n, R3, ['.33', str(s), '.33'])


H_MP = [global_mp(n, R4, S4) for n in range(1, 21)]
center = root_decimal(lambda s: h3_mp(1, s)-H_MP[0], ('.005', '.006'))
lower = root_decimal(lambda s: h3_mp(4, s)/H_MP[3]-dec('.86'), ('.005', '.006'))
upper = root_decimal(lambda s: h3_mp(20, s)/H_MP[19]-dec('1.14'), ('.005', '.006'))
balanced = root_decimal(lambda s: h3_mp(4, s)/H_MP[3]+h3_mp(20, s)/H_MP[19]-2, ('.005', '.006'))
modal = [h3_mp(n, balanced)/H_MP[n-1]-1 for n in range(1, 21)]

# Independently recover reciprocal response coefficients from three global
# solves, then verify the identity at additional conductivities. The shell's
# 2x2 transfer is linear in s and 1/s, so this form follows analytically.
rational = {}
for n in [4, 20]:
    samples = [dec('.002'), dec('.01'), dec('.05')]
    mat = [[s, dec(1), 1/s] for s in samples]
    coef = linear_solve(mat, [1/h3_mp(n, s) for s in samples])
    residuals = []
    for s in map(dec, ['.00001', '.001', '.003', '.02', '.07', '.1']):
        pred = 1/(coef[0]*s+coef[1]+coef[2]/s)
        residuals.append(abs(pred/h3_mp(n, s)-1))
    rational[str(n)] = {
        'positive_inverse_response_coefficients': all(x > 0 for x in coef),
        'turning_conductivity': str((coef[2]/coef[0]).sqrt()),
        'max_relative_identity_residual': str(max(residuals)),
        'increasing_on_search_interval': (coef[2]/coef[0]).sqrt() > dec('.1'),
    }


def ode_transfer(radii, sigma, lmax=256):
    """Integrate t=log(r), dV/dt=q/sigma, dq/dt=sigma*n(n+1)V-q."""
    n = np.arange(1, lmax+1, dtype=float)
    state = np.concatenate((np.ones(lmax), np.zeros(lmax)))
    for j in range(len(radii)-1, 0, -1):
        s = sigma[j]
        def rhs(t, y):
            return np.concatenate((y[lmax:]/s, s*n*(n+1)*y[:lmax]-y[lmax:]))
        sol = solve_ivp(rhs, (0., np.log(radii[j-1]/radii[j])), state,
                        method='DOP853', rtol=2.5e-13, atol=1e-14)
        if not sol.success:
            raise RuntimeError(sol.message)
        state = sol.y[:, -1]
    singular = (n*state[:lmax]-state[lmax:]/sigma[0])/(2*n+1)
    return (radii[-1]/radii[0])**(n+1)/singular


H = ode_transfer([.079, .080, .085, .090], [.33, 1.65, .00825, .33])
def h3(s): return ode_transfer([.080, .085, .090], [.33, float(s), .33])

mp_ode = float(np.max(np.abs(H[:20]/np.array([float(v) for v in H_MP])-1)))
center_ode = brentq(lambda s: h3(s)[0]-H[0], .004, .007, xtol=1e-15)
G = h3(center_ode)
n = np.arange(1, len(H)+1, dtype=float)
rho = .0785/.090
fields = {}
for orientation in ['radial', 'tangential']:
    shape = n*n if orientation == 'radial' else n*(n+1)/2
    weight = shape*rho**(2*n-2)/(2*n+1)
    def error(sigma, gain_free=False):
        g = h3(sigma)
        gain = np.dot(weight*g, H)/np.dot(weight*g, g) if gain_free else 1.
        return float(np.sqrt(np.dot(weight, (gain*g-H)**2)/np.dot(weight, H*H))), float(gain)
    center_error = error(center_ode)[0]
    fitted = {}
    # A different optimizer from the author's grid + bounded search.
    for gain_free in [False, True]:
        res = differential_evolution(lambda x: error(np.exp(x[0]), gain_free)[0],
                                     [(np.log(1e-5), np.log(.1))], seed=412,
                                     popsize=8, maxiter=80, tol=1e-10, polish=True,
                                     updating='immediate')
        s = float(np.exp(res.x[0]))
        e, gain = error(s, gain_free)
        fitted['free_gain' if gain_free else 'known_gain'] = {'sigma': s, 'error': e, 'gain': gain}
    fields[orientation] = {'center_error': center_error, 'fits': fitted}

# Analytic and physical limits challenge any broad irreducible-error claim.
homogeneous = ode_transfer([.079, .080, .085, .090], [.33]*4)
equal = ode_transfer([.079, .080, .085, .090], [.33, .33, .00825, .33])
same_three = h3(.00825)
limits = {
    'homogeneous_max_relative': float(np.max(np.abs(homogeneous/((2*n+1)/n)-1))),
    'equal_csf_brain_max_relative': float(np.max(np.abs(equal/same_three-1))),
    'zero_csf': 'Collapsing the zero-width fluid interval gives the identical three-layer boundary problem.',
    'single_mode_center_fit_relative_error': float(abs(h3_mp(1, center)/H_MP[0]-1)),
    'center_free_gain': 'Only degree one survives at d=0: selecting gain H_1/G_1 makes the field exact for any positive skull conductivity.',
}

# Compare independently obtained values to frozen numbers, not merely to pass
# flags or a freshly rerun author's computation.
with Path('/review/result/files/results/source_errors.csv').open() as f:
    frozen = list(csv.DictReader(f))
comparison = []
for orientation in fields:
    row = next(x for x in frozen if float(x['thickness_m']) == .001 and int(x['k']) == 40
               and x['site'] == 'depth_0.5mm' and x['orientation'] == orientation)
    comparison.append({'metric': orientation+'_center_error', 'absolute_difference': abs(fields[orientation]['center_error']-float(row['center_fit_error'])), 'tolerance': 1e-9})
    for key, column in [('known_gain', 'source_fit_error'), ('free_gain', 'free_amplitude_error')]:
        comparison.append({'metric': orientation+'_'+key+'_error', 'absolute_difference': abs(fields[orientation]['fits'][key]['error']-float(row[column])), 'tolerance': 1e-9})
comparison.append({'metric':'center_conductivity', 'absolute_difference':abs(float(center)-float(row['center_fit_sigma'])), 'tolerance':1e-12})
minimax = max(abs(x) for x in modal)
comparison.append({'metric':'balanced_minimax_error', 'absolute_difference':abs(float(minimax)-.14099706265558487), 'tolerance':1e-12})
assert lower > upper
assert all(v['increasing_on_search_interval'] and v['positive_inverse_response_coefficients'] for v in rational.values())
assert all(x['absolute_difference'] <= x['tolerance'] for x in comparison)
assert mp_ode < 1e-10
assert limits['homogeneous_max_relative'] < 1e-10
assert limits['equal_csf_brain_max_relative'] < 1e-10
assert fields['radial']['fits']['free_gain']['error'] < .0356
result = {
    'status':'verified',
    'method':'Reviewer-written 70-decimal global power-basis boundary system, independent log-radius ODE integration (DOP853), and differential-evolution dipole fits. No draft modules imported.',
    'center_conductivity_high_precision':str(center),
    'mode4_min_sigma_14percent':str(lower),
    'mode20_max_sigma_14percent':str(upper),
    'disjoint_gap':str(lower-upper),
    'balanced_minimax_conductivity':str(balanced),
    'balanced_minimax_error':str(minimax),
    'all20_signed_modal_errors_at_balance':[float(x) for x in modal],
    'rational_monotonicity_checks':rational,
    'mp_vs_ode_max_relative_degrees_1_to_20':mp_ode,
    'center_conductivity_ode':center_ode,
    'shallow_fields':fields,
    'analytic_boundary_challenges':limits,
    'frozen_value_comparisons':comparison,
    'resources':{'wall_seconds':time.perf_counter()-START,'cpu_seconds':time.process_time()-CPU,
                 'peak_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
                 'harmonic_cutoff':len(H),'decimal_digits':getcontext().prec,'numerical_threads':1},
}
(ROOT/'independent_result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
