#!/usr/bin/python3
# Reviewer-only offline adapter. No network; accepts precisely three staged URLs.
import sys
from pathlib import Path
prefix="https://raw.githubusercontent.com/Neuroinflab/fourspheremodel/f0c3e2dab2c8574ac24d1c16a33683410735e260/results/"
names={"Analytical_correct_all.npz","Numerical_rad.npz","Numerical_tan.npz"}
if len(sys.argv)!=2 or not sys.argv[1].startswith(prefix) or sys.argv[1][len(prefix):] not in names:
    sys.exit("review offline fetch: URL is not staged")
print(Path("/work/reproduction/reference_data")/sys.argv[1][len(prefix):])
