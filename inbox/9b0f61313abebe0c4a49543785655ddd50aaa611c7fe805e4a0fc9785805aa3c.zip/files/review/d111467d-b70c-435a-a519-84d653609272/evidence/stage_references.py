"""Reviewer-authored: retrieve bytes only; execute no downloaded code."""
import hashlib, json, shutil, subprocess, time
from pathlib import Path

commit = 'f0c3e2dab2c8574ac24d1c16a33683410735e260'
base = f'https://raw.githubusercontent.com/Neuroinflab/fourspheremodel/{commit}/'
data = {
 'results/Analytical_correct_all.npz': ('0a435cd998b9159545f5b452284556a5e240db743289f04f9a31977898e80731',2593762),
 'results/Numerical_rad.npz': ('de1248cdbc04f59b073ce429451ad1f18550f27035a8d798a8585434961f4dce',778150),
 'results/Numerical_tan.npz': ('9b0cc1e2fc66248897741744107281a427c2e7cddcae97c4a9212200b0053585',778150),
 'README.txt': None, 'parameters.py': None, 'analytical_correct.py': None,
 'CalcPotential4Sphere.py': None, 'numerical_fem.py': None, 'gpl-3.0.txt': None,
}
out = Path('/work/reproduction/reference-data')
out.mkdir(exist_ok=True, parents=True)
rows=[]
for rel, expected in data.items():
 start=time.perf_counter()
 cp=subprocess.run(['/opt/tools/fetch',base+rel],capture_output=True,text=True,timeout=60)
 record={'relative_path':rel,'url':base+rel,'returncode':cp.returncode,'elapsed_seconds':time.perf_counter()-start}
 if cp.returncode:
  record['error']=cp.stderr.strip()
 else:
  p=Path(cp.stdout.strip()); raw=p.read_bytes(); digest=hashlib.sha256(raw).hexdigest()
  record.update(sha256=digest,bytes=len(raw),local_name=Path(rel).name)
  if expected:
   record['matches_draft_pin']=(digest,len(raw))==expected
   assert record['matches_draft_pin'], record
  shutil.copyfile(p,out/Path(rel).name)
 rows.append(record)
 print(json.dumps(record),flush=True)
Path('/work/review/evidence/reference_downloads.json').write_text(json.dumps(rows,indent=2)+'\n')
