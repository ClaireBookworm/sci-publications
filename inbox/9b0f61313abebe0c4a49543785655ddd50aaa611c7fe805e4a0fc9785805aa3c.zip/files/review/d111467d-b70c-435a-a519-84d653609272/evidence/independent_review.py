"""Reviewer-authored calculation. Does not import any draft source code.

Global monomial coefficients, high precision algebra, and direct spatial
quadrature provide a check on the draft's inward recurrence and modal sums.
"""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ[key]='1'
import json,time,resource,csv
from pathlib import Path
import numpy as np
import scipy
from decimal import Decimal as D, getcontext
from scipy.optimize import brentq, minimize_scalar
from scipy.special import eval_legendre, roots_legendre

START=time.perf_counter(); CPU=time.process_time(); getcontext().prec=65
R4=['.079','.080','.085','.090']; S4=['.33','1.65','.00825','.33']
R3=['.080','.085','.090']

def solve_decimal(M,b):
    M=[row[:] + [value] for row,value in zip(M,b)]
    size=len(b)
    for col in range(size):
        pivot=max(range(col,size),key=lambda r:abs(M[r][col]))
        M[col],M[pivot]=M[pivot],M[col]
        for row in range(col+1,size):
            factor=M[row][col]/M[col][col]
            for k in range(col,size+1): M[row][k]-=factor*M[col][k]
    answer=[D(0)]*size
    for row in reversed(range(size)):
        answer[row]=(M[row][-1]-sum(M[row][k]*answer[k] for k in range(row+1,size)))/M[row][row]
    return answer

def high(n,radii,sigmas):
    # f_j(x)=A_j*x**n+B_j*x**(-n-1), x=r/R.
    # Fix singular brain coefficient B_0=1. Solve all 2m coefficients.
    rr=list(map(D,radii)); ss=list(map(D,sigmas)); m=len(rr)
    M=[[D(0)]*(2*m) for _ in range(2*m)]; b=[D(0)]*(2*m); M[0][1]=D(1); b[0]=D(1)
    for j in range(m-1):
        x=rr[j]/rr[-1]; reg=x**n; sing=x**(-n-1)
        for k,sgn in [(j,1),(j+1,-1)]:
            M[1+2*j][2*k]=sgn*reg
            M[1+2*j][2*k+1]=sgn*sing
            M[2+2*j][2*k]=sgn*ss[k]*n*reg
            M[2+2*j][2*k+1]=-sgn*ss[k]*(n+1)*sing
    M[-1][2*m-2]=D(n); M[-1][2*m-1]=D(-(n+1))
    v=solve_decimal(M,b)
    return v[-2]+v[-1]

def floating(radii,sigmas,L=256):
    rr=np.asarray(radii,float); ss=np.asarray(sigmas,float); m=len(rr)
    nn=np.arange(1,L+1,dtype=float)
    M=np.zeros((L,2*m,2*m)); b=np.zeros((L,2*m))
    M[:,0,1]=1; b[:,0]=1
    for j in range(m-1):
        x=rr[j]/rr[-1]; reg=x**nn; sing=x**(-nn-1)
        for k,sgn in [(j,1),(j+1,-1)]:
            M[:,1+2*j,2*k]=sgn*reg
            M[:,1+2*j,2*k+1]=sgn*sing
            M[:,2+2*j,2*k]=sgn*ss[k]*nn*reg
            M[:,2+2*j,2*k+1]=-sgn*ss[k]*(nn+1)*sing
    M[:,-1,-2]=nn; M[:,-1,-1]=-(nn+1)
    row=np.max(np.abs(M),axis=2)
    v=np.linalg.solve(M/row[:,:,None],(b/row)[:,:,None])[:,:,0]
    return v[:,-2]+v[:,-1]

def h3(s,L=256): return floating(R3,[.33,s,.33],L)
def bisect_mp(fun,lo,hi):
    lo=D(lo); hi=D(hi); flo=fun(lo)
    assert flo*fun(hi)<0
    for _ in range(190):
        mid=(lo+hi)/2; fmid=fun(mid)
        if flo*fmid>0: lo=mid; flo=fmid
        else: hi=mid
    return (lo+hi)/2

def asstr(x): return format(x,'.57g')
truth_mp={n:high(n,R4,S4) for n in range(1,21)}
center_mp=bisect_mp(lambda s:high(1,R3,['.33',s,'.33'])-truth_mp[1],'.00001','.1')
lower=bisect_mp(lambda s:high(4,R3,['.33',s,'.33'])/truth_mp[4]-D('.86'),'.00001','.1')
upper=bisect_mp(lambda s:high(20,R3,['.33',s,'.33'])/truth_mp[20]-D('1.14'),'.00001','.1')
balance=bisect_mp(lambda s:sum(high(n,R3,['.33',s,'.33'])/truth_mp[n]-1 for n in [4,20]),'.004','.006')
errors=[high(n,R3,['.33',balance,'.33'])/truth_mp[n]-1 for n in range(1,21)]
modal=max(abs(x) for x in errors)
# Independently interpolate 1/H=a*s+b+c/s and test at extra points.
monotonic={}
for n in [4,20]:
    samples=list(map(D,['.001','.01','.1']))
    a,b,c=solve_decimal([[s,D(1),1/s] for s in samples],
                     [1/high(n,R3,['.33',s,'.33']) for s in samples])
    residual=max(abs((a*s+b+c/s)*high(n,R3,['.33',s,'.33'])-1)
                 for s in map(D,['.003','.02','.08']))
    assert min(a,b,c)>0 and (c/a).sqrt()>D('.1') and residual<D('1e-60')
    monotonic[str(n)]={'a':asstr(a),'b':asstr(b),'c':asstr(c),'turning_sigma':asstr((c/a).sqrt()),'extra_point_relative_residual':asstr(residual)}

L=256; ns=np.arange(1,L+1); mu,q=roots_legendre(400)
polys=np.column_stack([eval_legendre(int(n),mu) for n in ns])
prev=np.column_stack([eval_legendre(int(n-1),mu) for n in ns])
rho=.0785/.09
rad=polys*(ns*rho**(ns-1))[None,:]
tan=(prev-mu[:,None]*polys)/np.sqrt(1-mu[:,None]**2)*(ns*rho**(ns-1))[None,:]
true=floating(R4,S4,L)
center=brentq(lambda s:h3(s,1)[0]-true[0],1e-5,.1,xtol=1e-15)

fields=[]
for ori,B in [('radial',rad),('tangential',tan)]:
    vr=B@true; norm=np.dot(q,vr*vr)
    def error(s,free=False):
        vt=B@h3(s,L)
        gain=np.dot(q,vt*vr)/np.dot(q,vt*vt) if free else 1.
        return float(np.sqrt(np.dot(q,(gain*vt-vr)**2)/norm)),float(gain)
    def fitted(free):
        grid=np.linspace(np.log(1e-5),np.log(.1),201)
        idx=np.argmin([error(np.exp(x),free)[0] for x in grid])
        sol=minimize_scalar(lambda x:error(np.exp(x),free)[0],bounds=(grid[max(0,idx-1)],grid[min(200,idx+1)]),method='bounded',options={'xatol':1e-13})
        s=float(np.exp(sol.x)); e,g=error(s,free)
        return {'sigma':s,'relative_rms':e,'gain':g}
    fields.append({'orientation':ori,'center_fit_error':error(center)[0],
                   'source_fit':fitted(False),'source_and_gain_fit':fitted(True)})

collapse=float(np.max(np.abs(floating(['.08','.08','.085','.09'],S4)/h3(.00825)-1)))
equal=float(np.max(np.abs(floating(R4,['.33','.33','.00825','.33'])/h3(.00825)-1)))
homogeneous=float(np.max(np.abs(floating(R4,['.33']*4)/(2*ns+1)*ns-1)))
assert max(collapse,equal,homogeneous)<1e-11
# Compare against the frozen grid only after completing independent calculations.
with open('/review/result/files/results/source_errors.csv') as f: saved=list(csv.DictReader(f))
for r in fields:
    old=next(x for x in saved if x['site']=='depth_0.5mm' and float(x['thickness_m'])==.001 and int(x['k'])==40 and x['orientation']==r['orientation'])
    r['center_error_abs_difference_from_frozen']=abs(r['center_fit_error']-float(old['center_fit_error']))
    r['free_error_abs_difference_from_frozen']=abs(r['source_and_gain_fit']['relative_rms']-float(old['free_amplitude_error']))
    assert r['center_error_abs_difference_from_frozen']<1e-9
    assert r['free_error_abs_difference_from_frozen']<1e-9
assert abs(center-float(center_mp))<1e-12
assert abs(float(modal)-.140997062655585)<1e-8
assert lower>upper
report={'status':'verified','method':'Reviewer global monomial continuity solve; 65-digit arithmetic; independent 400-node Gauss-Legendre spatial integral and 201-point fit bracketing. No draft code imports.',
 'tolerance':{'center_sigma_abs_S_per_m':1e-12,'field_error_abs':1e-9,'modal_minimax_abs':1e-8,'boundary_relative':1e-11},
 'center_sigma_65_digits':asstr(center_mp),'mode4_lower_sigma':asstr(lower),'mode20_upper_sigma':asstr(upper),'gap_S_per_m':asstr(lower-upper),
 'balanced_sigma':asstr(balance),'minimax_error':asstr(modal),'balanced_modal_errors':[asstr(x) for x in errors],
 'monotonicity':monotonic,'central_fields':fields,
 'boundary_cases':{'zero_thickness_relative':collapse,'equal_csf_brain_relative':equal,'homogeneous_relative':homogeneous},
 'challenge':'A pure high-degree pattern attains the modal bound, whereas a shallow point dipole has much smaller full-field error; free source gain further lowers it. Exact collapse and equal-conductivity controls remove the discrepancy.',
 'resources':{'elapsed_seconds':time.perf_counter()-START,'cpu_seconds':time.process_time()-CPU,'peak_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024},
 'dependencies':{'numpy':np.__version__,'scipy':scipy.__version__,'high_precision':'Python decimal, 65 decimal digits'}}
Path('/work/reproduction/independent_result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
