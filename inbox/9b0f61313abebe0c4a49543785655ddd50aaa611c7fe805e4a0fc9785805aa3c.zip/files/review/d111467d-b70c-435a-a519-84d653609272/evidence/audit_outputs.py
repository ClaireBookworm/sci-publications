"""Reviewer-authored audit of saved tables and exact output identities."""
from pathlib import Path
import csv,json,hashlib,time,resource
start=time.perf_counter()
root=Path('/review/result/files/results'); rerun=Path('/work/reproduction/full')
comparisons=[]
for name in ['source_errors.csv','modes.csv','convergence.csv','external_comparison.csv','provenance.json','summary.png']:
    old=(root/name).read_bytes(); new=(rerun/name).read_bytes()
    comparisons.append({'file':name,'byte_identical':old==new,'frozen_sha256':hashlib.sha256(old).hexdigest(),'rerun_sha256':hashlib.sha256(new).hexdigest()})
    assert old==new
with (rerun/'source_errors.csv').open() as f: rows=list(csv.DictReader(f))
maxfree=max(rows,key=lambda x:float(x['free_amplitude_error']))
deep=[r for r in rows if float(r['thickness_m'])==.001]
maxdeep=max(deep,key=lambda x:float(x['deep_fit_error']))
maxcenter=max(deep,key=lambda x:float(x['center_fit_error']))
report={'status':'verified','output_comparison':comparisons,'source_rows':len(rows),
    'maximum_tested_free_gain_error':float(maxfree['free_amplitude_error']),
    'maximum_tested_free_gain_case':{k:maxfree[k] for k in ['thickness_m','k','site','orientation']},
    'one_mm_max_deep_fit_error':float(maxdeep['deep_fit_error']),
    'one_mm_max_center_fit_error':float(maxcenter['center_fit_error']),
    'center_free_gain_rows_unidentifiable':all(r['skull_identifiable_with_free_gain']=='False' for r in rows if r['site']=='center'),
    'resources':{'elapsed_seconds':time.perf_counter()-start,'peak_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024}}
Path('/work/reproduction/output_audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
