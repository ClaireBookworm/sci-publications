#!/usr/bin/python3
"""Reviewer cache adapter: serve only the three exact pinned public URLs."""
import hashlib,sys
from pathlib import Path
base='https://raw.githubusercontent.com/Neuroinflab/fourspheremodel/f0c3e2dab2c8574ac24d1c16a33683410735e260/results/'
pins={
 'Analytical_correct_all.npz':'0a435cd998b9159545f5b452284556a5e240db743289f04f9a31977898e80731',
 'Numerical_rad.npz':'de1248cdbc04f59b073ce429451ad1f18550f27035a8d798a8585434961f4dce',
 'Numerical_tan.npz':'9b0cc1e2fc66248897741744107281a427c2e7cddcae97c4a9212200b0053585'}
assert len(sys.argv)==2
name=sys.argv[1].removeprefix(base)
assert name in pins and sys.argv[1]==base+name
p=Path('/work/reproduction/reference-data')/name
assert hashlib.sha256(p.read_bytes()).hexdigest()==pins[name]
print(p)
